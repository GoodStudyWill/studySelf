//
//  FJSDateHelper.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/16.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FJSDateHelper : NSObject

+ (NSDate *)firstDayOfMonth:(NSDate *)date;

+ (NSDate *)lastDayOfMonth:(NSDate *)date;

@end
