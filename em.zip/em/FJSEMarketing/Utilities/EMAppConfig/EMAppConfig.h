//
//  EMAppConfig.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

// SS_ENV 0、生产  1、测试SS.stg1  2、测试SS.stg2 3、测试SS.stg3 4、测试SS.stg4 5、测试SS.stg5
#define SS_ENV 1

FOUNDATION_EXPORT NSString * const kAESKey;
FOUNDATION_EXPORT NSString * const kRSAPublicKey;

@interface EMAppConfig : NSObject
//环境切换
@property (nonatomic, strong, readonly) NSNumber *ssEnv;
//服务器地址
@property (nonatomic, copy, readonly) NSString *baseURL;
//强升地址
@property (nonatomic, copy, readonly) NSString *versionURL;

//房按揭2期地址
@property (nonatomic, copy, readonly) NSString *mtgURL;

//环境
@property (nonatomic, copy, readonly) NSString *userAgentSSEnv;

//天眼APPKey
@property (nonatomic, copy, readonly) NSString *talkingDataAppKey;

@property (nonatomic, weak) UIViewController *currentTopViewController;

+ (EMAppConfig *)sharedInstance;

- (void)initNetworkConfig;

/**
 切换环境
 0、生产  1、测试SS.stg1  2、测试SS.stg2
 
 @param ssEnv 环境
 */
- (void)changeSSEnvironment:(NSInteger)ssEnv;

- (NSString *)completeH5URLForPath:(NSString *)path;

@end
