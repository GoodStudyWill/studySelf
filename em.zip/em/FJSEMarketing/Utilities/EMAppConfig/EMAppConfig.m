//
//  EMAppConfig.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>
#import "EMAppConfig.h"
#import "NSString+FJSBase64.h"
#import "EMUserManager.h"

NSString * const kAESKey = @"^O'*P#!&/@%Mg*T$";
NSString * const kRSAPublicKey = @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCeabYScyccBwY6ieOcVkz/8RwQZSRQxpaVf+rIv3/k9+yxxBtKeK9F8yP3JDTZCr2mYXNlgdBU0OfX6472JrrQaHx5HF6pEjcVUzX34QsfoD+Z4e4zczktg1DEhVo2B7S3p7Rn9VPTTDfVB4s3x0sSge3goqRm1gwJCLaCZqeK+QIDAQAB";

@interface EMAppConfig ()

@property (nonatomic, strong)   NSNumber *ssEnv;
@property (nonatomic, copy)     NSString *baseURL;
@property (nonatomic, copy)     NSString *versionURL;
@property (nonatomic, copy)     NSString *userAgentSSEnv;
@property (nonatomic, copy)     NSString *htmlBaseURL;
@property (nonatomic, copy)     NSString *talkingDataAppKey;

@property (nonatomic, copy)     NSString *mtgURL;

@end

@implementation EMAppConfig

#pragma mark - Shared instance
+ (EMAppConfig *)sharedInstance
{
    static EMAppConfig *appConfig;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        appConfig = [[EMAppConfig alloc] init];
        [appConfig reset];
    });
    return appConfig;
}

#pragma mark - Init network config
- (void)initNetworkConfig
{
    FJSNetworkConfig *config = [FJSNetworkConfig sharedConfig];
    config.requestEncryptType = FJSRequestEncryptTypePart;
    [config setBaseUrl:self.baseURL];
    [config setAESKey:[kAESKey fjs_base64EncodedString] encryptedAESKey:@""];
    
    //设置公共入参
    config.commonRequestArgument = [@{@"networkType"     : [FJSSystemInfo netWorkType] ?: @"",
                                      @"deviceId"        : [FJSSystemInfo deviceID] ?: @"",
                                      @"deviceType"      : [FJSSystemInfo deviceModel] ?: @"",
                                      @"deviceSVN"       : [FJSSystemInfo osInfo] ?: @"",
                                      @"nativeType"      : @"IOS",
                                      @"versionId"       : [FJSSystemInfo bundleVersion] ?: @"",
                                      @"versionDate"     : kAppVersionDate,
                                      @"versionDesc"     : @"123456787654",
                                      @"token"           : [EMUserManager sharedInstance].token ?: @"",
                                      } mutableCopy];
    FJSLog(@"%@", config.commonRequestArgument);
    
    //设置删除返回的NSNull值
    config.removesKeysWithNullValues = YES;
}

#pragma mark - Set environment
- (void)changeSSEnvironment:(NSInteger)ssEnv
{
    //如果当前环境是生产环境，不允许更改；如果想改成生产环境，也不允许更改
    if (ssEnv == 0 || ssEnv == 0) {
        return;
    }
    _ssEnv = [NSNumber numberWithInteger:ssEnv];
    [[NSUserDefaults standardUserDefaults] setObject:_ssEnv forKey:@"ss_env"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self reset];
}

- (void)reset
{
    NSInteger ssEnvNum = [self.ssEnv integerValue];
    
    switch (ssEnvNum) {
        case 0:
        {
            //生产
            self.baseURL = @"https://papc-gs.pingan.com.cn/opmgt/";
            self.versionURL = @"https://fang.pingan.com.cn/opmgt/prd/h5/up_json/upgrade.json";
            self.htmlBaseURL = @"https://fang.pingan.com.cn/opmgt/prd/h5/online/em/";
            self.userAgentSSEnv = @"prd";
            
            self.mtgURL = @"https://papc-gs.pingan.com.cn/mtg2/";
            
            self.talkingDataAppKey = @"0ACF3B4EAE95473E894984443D2C0A84";
        }
            break;
            
        case 1:
        case 2:
        case 3:
        case 4:
        {
            // stg1, stg2, stg3, stg4
            self.baseURL = [NSString stringWithFormat:@"https://test-papc-gs.pingan.com.cn:8843/stg%ld/opmgt/", ssEnvNum];
            self.versionURL = [NSString stringWithFormat:@"https://fang-test.pingan.com.cn:20443/opmgt/stg%ld/h5/up_json/upgrade.json", ssEnvNum];
            self.userAgentSSEnv = [NSString stringWithFormat:@"stg%ld", ssEnvNum];
            self.htmlBaseURL = [NSString stringWithFormat:@"https://fang-test.pingan.com.cn:20443/opmgt/stg%ld/h5/online/em/", ssEnvNum];
            
            self.mtgURL = [NSString stringWithFormat:@"https://test-papc-gs.pingan.com.cn:8843/stg%ld/mtg2/", ssEnvNum];
            
            self.talkingDataAppKey = @"8961A4E5F1964744A49240029ACB37C6";
        }
            break;
        
        case 5:
        {
            //生产
            self.baseURL = @"https://202.69.30.113/opmgt/";
            self.versionURL = @"https://fang.pingan.com.cn/opmgt/prd_bk/h5/up_json/upgrade.json";
            self.htmlBaseURL = @"https://fang.pingan.com.cn/opmgt/prd_bk/h5/online/em/";
            self.userAgentSSEnv = @"prd_bk";
            
            self.talkingDataAppKey = @"0ACF3B4EAE95473E894984443D2C0A84";
        }
        break;
            
        default:
            break;
    }
}

#pragma mark - H5 URL
- (NSString *)completeH5URLForPath:(NSString *)path
{
    NSString *baseUrl = self.htmlBaseURL;
//    baseUrl = @"http://10.180.228.24:8899/";
    return [NSString stringWithFormat:@"%@%@", baseUrl, path];
}

#pragma mark - Setter & Getter
- (NSNumber *)ssEnv{
    if (!SS_ENV) {
        return @(SS_ENV);
    }
    if (_ssEnv) {
        return _ssEnv;
    }
    NSNumber *ssEnv = [[NSUserDefaults standardUserDefaults] objectForKey:@"ss_env"];
    if (ssEnv) {
        _ssEnv = ssEnv;
    }else{
        _ssEnv = @(SS_ENV);
    }
    return _ssEnv;
}

@end
