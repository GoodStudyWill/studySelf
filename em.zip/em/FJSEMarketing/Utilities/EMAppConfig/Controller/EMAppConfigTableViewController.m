//
//  EMAppConfigTableViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/24.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSSystemInfo/FJSSystemInfo.h>
#import "EMAppConfigTableViewController.h"
#import "EMNotificationCenter.h"

@interface EMAppConfigTableViewController ()

@property (nonatomic,strong) NSArray *dataArr;

@end

@implementation EMAppConfigTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"APP信息";
    [self loadNewData];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = NO;
    self.navigationController.navigationBar.barTintColor = UIColorFromHex(0x00a0ea);
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBarHidden = YES;
}

- (void)loadNewData
{
    NSString* userPhoneName = [[UIDevice currentDevice] name];
    
    NSString* phoneVersion = [[UIDevice currentDevice] systemVersion];
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *appCurName = [infoDictionary objectForKey:@"CFBundleDisplayName"];
    NSString *appCurVersion = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    
    NSString *httpHead = [[EMAppConfig sharedInstance].baseURL hasPrefix:@"https"] ? @"https": @"http";
    NSString *env = [EMAppConfig sharedInstance].userAgentSSEnv;
    
    NSArray *baseInfoArr = @[
                             @{@"设备名称:":userPhoneName?:@""},
                             @{@"手机系统版本:":phoneVersion?:@""},
                             @{@"手机信息:":[FJSSystemInfo osInfo]?:@""},
                             @{@"当前应用名称:":appCurName?:@""},
                             @{@"当前应用版本:":appCurVersion?:@""},
                             @{@"请求头信息:":httpHead?:@""},
                             @{@"环境:":env?:@""},
                             @{@"DeviceToken":[EMNotificationCenter sharedInstance].deviceToken?:@""},
                             ];
    
    self.dataArr = baseInfoArr;
    [self.tableView reloadData];
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:@"reuseIdentifier"];
    
    NSDictionary *dic = self.dataArr[indexPath.row];
    cell.textLabel.text = dic.allKeys.firstObject;
    cell.detailTextLabel.text = dic.allValues.firstObject;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}

@end
