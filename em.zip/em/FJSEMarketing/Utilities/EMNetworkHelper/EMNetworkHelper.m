//
//  EMNetworkHelper.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/10/3.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMNetworkHelper.h"
#import "FJSAlertView.h"
#import "EMUserManager.h"
#import "EMNotificationCenter.h"
#import "EMGesturePasswordViewController.h"
#import "EMLoginViewController.h"
#import "UIApplication+FJSExtension.h"

@implementation EMNetworkHelper

+ (void)tokenTimeOutWithMessage:(NSString *)msg
{
    FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:@"提示" detail:msg buttonTitle:@"确定" completionBlock:^{
        if ([[EMUserManager sharedInstance] isGestureLogin]) {
            EMGesturePasswordViewController *gestureViewController = [[EMGesturePasswordViewController alloc] initWithMode:EMGesterePasswordModeVerification];;
            UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:gestureViewController];
            [[UIApplication fjs_currentViewController] presentViewController:navigationController animated:NO completion:^{
                [[EMNotificationCenter sharedInstance] clearNotifications];
                [EMUserManager sharedInstance].login = NO;
            }];
        } else {
            EMLoginViewController *loginViewController = [[EMLoginViewController alloc] initWithNibName:@"EMLoginViewController" bundle:nil];
            UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:loginViewController];
            [[UIApplication fjs_currentViewController] presentViewController:navigationController animated:NO completion:^{
                [[EMUserManager sharedInstance] clearInformation];
            }];
        }
    }];
    [alertView show];
}

@end
