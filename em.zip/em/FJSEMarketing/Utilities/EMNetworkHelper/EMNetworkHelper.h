//
//  EMNetworkHelper.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/10/3.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EMNetworkHelper : NSObject

+ (void)tokenTimeOutWithMessage:(NSString *)msg;

@end
