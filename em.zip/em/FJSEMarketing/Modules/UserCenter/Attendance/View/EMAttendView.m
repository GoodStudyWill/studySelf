//
//  EMAttendView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/26.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMAttendView.h"
#import "EMAttendanceModel.h"

@interface EMAttendView ()

@property (nonatomic, strong) UIImageView *iconImageView;
@property (nonatomic, strong) UILabel *dateLabel;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UILabel *locationLabel;

@end

@implementation EMAttendView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initUI];
    }
    return self;
}

- (void)initUI
{
    self.iconImageView = [[UIImageView alloc] initWithFrame:CGRectMake(15, 17, 7, 7)];
    self.iconImageView.contentMode = UIViewContentModeScaleAspectFit;
    [self addSubview:self.iconImageView];
    
    self.dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(35, 0, 112, 42)];
    self.dateLabel.font = [UIFont systemFontOfSize:14];
    self.dateLabel.textColor = UIColorFromHex(0x666666);
    self.dateLabel.text = @"2017年7月24日";
    [self addSubview:self.dateLabel];
    
    self.timeLabel = [[UILabel alloc] initWithFrame:CGRectMake(153, 0, 90, 42)];
    self.timeLabel.font = [UIFont systemFontOfSize:14];
    self.timeLabel.textColor = UIColorFromHex(0x666666);
    self.timeLabel.text = @"20:06:33";
    [self addSubview:self.timeLabel];
    
    self.locationLabel = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 126 - 15, 0, 126, 42)];
    self.locationLabel.font = [UIFont systemFontOfSize:14];
    self.locationLabel.textColor = UIColorFromHex(0x666666);
    self.locationLabel.text = @"龙华中路200号";
    self.locationLabel.textAlignment = NSTextAlignmentRight;
    [self addSubview:self.locationLabel];
    
    [self.locationLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self).with.offset(-15);
        make.left.equalTo(self.timeLabel.mas_right);
        make.height.equalTo(@42);
        make.centerY.equalTo(self);
    }];
}

- (void)setModel:(EMAttendanceModel *)model
{
    NSString *imageName = @"icon_onduty";
    _model = model;
    switch (_model.status) {
        case EMAttendanceStatusSickLeave:
        case EMAttendanceStatusAnnualLeave:
        case EMAttendanceStatusCasualLeave:
        case EMAttendanceStatusOther:
        {
            self.dateLabel.textColor = UIColorFromHex(0xffa32c);
            self.timeLabel.textColor = UIColorFromHex(0xffa32c);
            self.locationLabel.textColor = UIColorFromHex(0xffa32c);
            
            self.locationLabel.text = [self leaveStrFromStatus:_model.status];
            
            imageName = @"icon_leave";
        }
            break;
            
        case EMAttendanceStatusOnDuty:
        case EMAttendanceStatusOffDuty:
        case EMAttendanceStatusGoingToWork:
        {
            self.dateLabel.textColor = UIColorFromHex(0x666666);
            self.timeLabel.textColor = UIColorFromHex(0x666666);
            self.locationLabel.textColor = UIColorFromHex(0x666666);
            self.locationLabel.text = _model.attendAddr;
            
            imageName = _model.status == EMAttendanceStatusOnDuty ? @"icon_onduty" : @"icon_offduty";
        }
            break;
            
        case EMAttendanceStatusError:
            break;
    }
    
    self.dateLabel.text = _model.attendDate;
    self.timeLabel.text = _model.attendTime;
    
    self.iconImageView.image = [UIImage imageNamed:imageName];
}

- (NSString *)leaveStrFromStatus:(EMAttendanceStatus)status
{
    if (status == EMAttendanceStatusAnnualLeave) {
        return @"年休假";
    }
    else if (status == EMAttendanceStatusCasualLeave) {
        return @"事假";
    }
    else if (status == EMAttendanceStatusSickLeave) {
        return @"病假";
    }
    else if (status == EMAttendanceStatusOther) {
        return @"其他";
    }
    return @"";
}


@end
