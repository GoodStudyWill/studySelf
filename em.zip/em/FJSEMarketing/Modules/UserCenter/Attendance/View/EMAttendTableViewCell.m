//
//  EMAttendTableViewCell.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/26.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMAttendTableViewCell.h"
#import "EMAttendView.h"
#import "EMAttendanceModel.h"
#import "EMAttendanceCellFrame.h"

@implementation EMAttendTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setCellFrame:(EMAttendanceCellFrame *)cellFrame
{
    _cellFrame = cellFrame;
    
    CGFloat cellHeight = _cellFrame.cellHeight;
    for (NSInteger i = 0; i < _cellFrame.attendanceArray.count; i++) {
        EMAttendView *attendView = [[EMAttendView alloc] initWithFrame:CGRectMake(0, cellHeight-42*(i+1)-6, SCREEN_WIDTH, 42)];
        EMAttendanceModel *model = _cellFrame.attendanceArray[i];
        attendView.model = model;
        [self addSubview:attendView];
    }
}

@end
