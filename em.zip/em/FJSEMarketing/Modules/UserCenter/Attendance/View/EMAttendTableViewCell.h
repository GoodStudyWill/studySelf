//
//  EMAttendTableViewCell.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/26.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@class EMAttendanceCellFrame;

@interface EMAttendTableViewCell : UITableViewCell

@property (nonatomic, strong) EMAttendanceCellFrame *cellFrame;

@end
