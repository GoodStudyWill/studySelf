//
//  EMAttendView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/26.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@class EMAttendanceModel;

@interface EMAttendView : UIView

@property (nonatomic, strong) EMAttendanceModel *model;

@end
