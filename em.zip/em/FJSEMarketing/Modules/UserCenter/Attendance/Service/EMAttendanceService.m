//
//  EMAttendanceService.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <AMapLocationKit/AMapLocationKit.h>
#import "EMAttendanceService.h"
#import "EMUploadAttendApi.h"
#import "EMGetAttendanceApi.h"
#import "EMQueryAttendStatusApi.h"
#import "EMAttendanceModel.h"
#import "EMAttendanceCellFrame.h"

@interface EMAttendanceService ()<FJSRequestDelegate>

@property (nonatomic, copy) NSString *endDate;
@property (nonatomic, copy) NSString *formattedAddress;

@property (nonatomic, strong) NSMutableArray *attendances;

//去重字典
@property (nonatomic, strong) NSMutableDictionary *attendDateDic;

@property (nonatomic, assign) NSInteger refreshFlag;

@end

@implementation EMAttendanceService

- (instancetype)init
{
    self = [super init];
    if (self) {
        _endDate = @"";
        _attendances = [NSMutableArray array];
        _attendDateDic = [NSMutableDictionary dictionary];
    }
    return self;
}

#pragma mark - SubmitAttendanceInformation
- (void)submitAttendanceInformationWithLocation:(CLLocation *)location
                                      reGeocode:(AMapLocationReGeocode *)reGeocode
                                         status:(EMAttendanceStatus)status
{
    NSString *latitude = [NSString stringWithFormat:@"%f",  location.coordinate.latitude];
    NSString *longitude = [NSString stringWithFormat:@"%f",  location.coordinate.longitude];
    NSString *attendanceStatus = [NSString stringWithFormat:@"%lu", status];
    NSString *city = reGeocode.city;
    
    self.formattedAddress = reGeocode.formattedAddress;
    NSArray *addressArray = [self.formattedAddress componentsSeparatedByString:city];
    NSString *address = addressArray.lastObject;
    
    EMUploadAttendApi *api = [[EMUploadAttendApi alloc] initWithCity:city
                                                            latitude:latitude
                                                           longitude:longitude
                                                             address:address
                                                              status:attendanceStatus];
    api.delegate = self;
    [api start];
}

- (void)handleSubmitAttendance:(NSDictionary *)data
{
    EMAttendanceStatus status = [data[@"attendStatus"] integerValue];
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:submitAttendanceSuccess:status:)]) {
        [self.delegate service:self submitAttendanceSuccess:self.formattedAddress status:status];
    }
}

#pragma mark - GetAttendanceStatus
- (void)getAttendStatus
{
    EMQueryAttendStatusApi *api = [[EMQueryAttendStatusApi alloc] init];
    api.delegate = self;
    [api start];
}

- (void)handleAttendStatus:(NSDictionary *)data
{
    EMAttendanceStatus status = [data[@"attendStatus"] integerValue];
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:attendanceStatus:)]) {
        [self.delegate service:self attendanceStatus:status];
    }
}

#pragma mark - GetAttendanceList
- (void)getAttendanceList
{
    EMGetAttendanceApi *api = [[EMGetAttendanceApi alloc] initWithEndDate:_endDate];
    api.delegate = self;
    [api start];
}

- (void)refreshAttendanceList
{
    self.refreshFlag = 1;
    _endDate = @"";
    [self getAttendanceList];
}

- (void)handleAttendanceListData:(NSArray *)data
{
    if (self.refreshFlag == 1) {
        self.refreshFlag = 0;
        [self.attendances removeAllObjects];
        [self.attendDateDic removeAllObjects];
    }
    
    NSDictionary *lastAttendDic = data.lastObject;
    _endDate = lastAttendDic[@"attendDate"] ?: @"";
    for (NSDictionary *attendDic in data) {
        NSString *originAttendDate = attendDic[@"attendDate"];
        if ([self hasDate:originAttendDate]) {
            continue;
        }
        
        NSString *attendDate = [self transformDateString:originAttendDate];
        NSArray *attendList = attendDic[@"attendList"];
        
        NSMutableArray *attendArray = [NSMutableArray array];
        for (NSDictionary *oneTimeDic in attendList) {
            EMAttendanceModel *model = [[EMAttendanceModel alloc] init];
            model.attendDate = attendDate;
            model.attendAddr = oneTimeDic[@"attendAddr"];
            model.attendTime = oneTimeDic[@"attendTime"];
            model.status = [oneTimeDic[@"attendStatus"] integerValue];
            [attendArray addObject:model];
        }
        
        NSArray *reverseAttendArray = [[attendArray reverseObjectEnumerator] allObjects];
        EMAttendanceCellFrame *cellFrame = [[EMAttendanceCellFrame alloc] init];
        cellFrame.attendanceArray = reverseAttendArray;
        if (![self.attendances containsObject:cellFrame]) {
            [self.attendances addObject:cellFrame];
        }
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:attendanceData:)]) {
        [self.delegate service:self attendanceData:self.attendances];
    }
}

- (NSString *)transformDateString:(NSString *)dateStr{
    NSArray *dateArray = [dateStr componentsSeparatedByString:@"-"];
    if (dateArray.count == 3) {
        NSString *str = [NSString stringWithFormat:@"%@年%@月%@日", dateArray[0], dateArray[1], dateArray[2]];
        return str;
    }
    return @"";
}

//去重
- (BOOL)hasDate:(NSString *)date
{
    NSString *str = self.attendDateDic[date];
    if (!str) {
        [self.attendDateDic setObject:date forKey:date];
        return NO;
    }
    return YES;
}

#pragma mark - FJSRequestDelegate
- (void)handleApiRequestDidSuccess:(__kindof FJSBaseApi*)request
{
    FJSLog(@"Api class => %@", request.class);
    FJSLog(@"response => %@", request.responseString);
    FJSLog(@"responseObject => %@", request.responseObject);
    if (request.class == [EMGetAttendanceApi class]) {
        NSArray *data = request.responseJSONObject[@"data"];
        [self handleAttendanceListData:data];
    }
    else if (request.class == [EMUploadAttendApi class]) {
        NSDictionary *data = request.responseJSONObject[@"data"];
        [self handleSubmitAttendance:data];
    }
    else if (request.class == [EMQueryAttendStatusApi class]) {
        NSDictionary *data = request.responseJSONObject[@"data"];
        [self handleAttendStatus:data];
    }
}

- (void)handleApiRequestDidFail:(__kindof FJSBaseApi *)request
{
    FJSLog(@"Api class => %@", request.class);
    FJSLog(@"response => %@", request.responseString);
    FJSLog(@"responseObject => %@", request.responseObject);
}

@end
