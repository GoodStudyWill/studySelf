//
//  EMAttendanceService.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMBaseService.h"

@class EMAttendanceService;
@class CLLocation;
@class AMapLocationReGeocode;

@protocol EMAttendanceServiceDelegate <NSObject>

/**
 提交考勤数据回调

 @param service service
 @param address 打卡地址
 */
- (void)service:(EMAttendanceService *)service submitAttendanceSuccess:(NSString *)address status:(EMAttendanceStatus)status;

/**
 查询考勤状态回调

 @param service service
 @param status 考勤状态
 */
- (void)service:(EMAttendanceService *)service attendanceStatus:(EMAttendanceStatus)status;

/**
 查询历史考勤数据回调

 @param service service
 @param attendances 历史考勤数据
 */
- (void)service:(EMAttendanceService *)service attendanceData:(NSArray *)attendances;

@end

@interface EMAttendanceService : EMBaseService

@property (nonatomic, weak) id<EMAttendanceServiceDelegate> delegate;

/**
 提交考勤数据

 @param location 地理位置
 @param reGeocode 逆地理信息
 @param status 考勤类型
 */
- (void)submitAttendanceInformationWithLocation:(CLLocation *)location
                                      reGeocode:(AMapLocationReGeocode *)reGeocode
                                         status:(EMAttendanceStatus)status;

/**
 查询考勤状态
 */
- (void)getAttendStatus;

/**
 查询考勤历史数据
 */
- (void)getAttendanceList;

- (void)refreshAttendanceList;

@end
