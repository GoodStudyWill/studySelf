
//
//  EMQueryAttendStatusApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/26.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMQueryAttendStatusApi.h"

@implementation EMQueryAttendStatusApi

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"attend/queryAttendStatus.do";
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
