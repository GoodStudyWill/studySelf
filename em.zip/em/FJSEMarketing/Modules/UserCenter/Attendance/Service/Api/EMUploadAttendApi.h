//
//  EMUploadAttendApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>

@interface EMUploadAttendApi : FJSApi

/**
 初始化
 
 @param city 打卡城市
 @param latitude 打卡地址纬度
 @param longitude 打卡地址经度
 @param address 打卡地址
 @param status 打卡类型，101上班，102下班
 @return 对象
 */
- (instancetype)initWithCity:(NSString *)city
                    latitude:(NSString *)latitude
                   longitude:(NSString *)longitude
                     address:(NSString *)address
                      status:(NSString *)status;

@end
