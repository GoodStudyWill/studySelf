//
//  EMGetAttendanceApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMGetAttendanceApi.h"

@interface EMGetAttendanceApi ()

@property (nonatomic, copy) NSString *endDate;

@end

@implementation EMGetAttendanceApi

- (instancetype)initWithEndDate:(NSString *)endDate
{
    self = [super init];
    if (self) {
        _endDate = endDate ?: @"";
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"attend/getAttends.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{@"endDate" : _endDate};
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
