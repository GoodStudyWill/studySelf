//
//  EMUploadAttendApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMUploadAttendApi.h"

@interface EMUploadAttendApi ()

@property (nonatomic, copy) NSString *city;
@property (nonatomic, copy) NSString *latitude;
@property (nonatomic, copy) NSString *longitude;
@property (nonatomic, copy) NSString *address;
@property (nonatomic, copy) NSString *status;

@end

@implementation EMUploadAttendApi

- (instancetype)initWithCity:(NSString *)city
                    latitude:(NSString *)latitude
                   longitude:(NSString *)longitude
                     address:(NSString *)address
                      status:(NSString *)status
{
    self = [super init];
    if (self) {
        _city = city;
        _latitude = latitude;
        _longitude = longitude;
        _address = address;
        _status = status;
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"attend/uploadAttend.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{@"attendCity"       : _city      ?: @"",
                            @"checkLatitude"    : _latitude  ?: @"",
                            @"checkLongitude"   : _longitude ?: @"",
                            @"attendAddr"       : _address   ?: @"",
                            @"attendStatus"     : _status    ?: @"",
                            };
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
