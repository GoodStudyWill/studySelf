//
//  EMGetAttendanceApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>

@interface EMGetAttendanceApi : FJSApi

/**
 初始化

 @param endDate 查询截止日期，没值默认5天数据
 @return 对象
 */
- (instancetype)initWithEndDate:(NSString *)endDate;

@end
