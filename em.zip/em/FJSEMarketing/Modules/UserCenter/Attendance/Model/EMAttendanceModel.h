//
//  EMAttendanceModel.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EMAttendanceModel : NSObject

//考勤日期
@property (nonatomic, copy) NSString *attendDate;
//打卡地址
@property (nonatomic, copy) NSString *attendAddr;
//打卡时间
@property (nonatomic, copy) NSString *attendTime;
//打卡类型
@property (nonatomic, assign) EMAttendanceStatus status;

@end
