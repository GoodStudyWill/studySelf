//
//  EMAttendanceCellFrame.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/26.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EMAttendanceCellFrame : NSObject

@property (nonatomic, strong) NSArray *attendanceArray;
@property (nonatomic, assign) CGFloat cellHeight;

@end
