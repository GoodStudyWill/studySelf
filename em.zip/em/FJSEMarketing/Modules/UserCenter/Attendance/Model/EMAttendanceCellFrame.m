//
//  EMAttendanceCellFrame.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/26.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMAttendanceCellFrame.h"

@implementation EMAttendanceCellFrame

- (void)setAttendanceArray:(NSArray *)attendanceArray
{
    _attendanceArray = attendanceArray;
    
    _cellHeight = 42 * attendanceArray.count + 6 + 6;
}

@end
