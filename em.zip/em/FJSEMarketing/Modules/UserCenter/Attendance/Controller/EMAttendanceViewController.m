//
//  EMAttendanceViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <AMapLocationKit/AMapLocationKit.h>
#import <MAMapKit/MAMapKit.h>
#import "EMAttendanceViewController.h"
#import "NSDate+FJSExtension.h"
#import "EMAttendanceService.h"
#import "EMUserManager.h"
#import "EMAttendanceCellFrame.h"
#import "EMAttendTableViewCell.h"
#import "FJSWebViewController.h"
#import "FJSActivityIndicatorView.h"
#import "FJSAlertView.h"

static NSInteger const kLocationTimeout = 10;
static NSInteger const kReGeocodeTimeout = 5;

@interface EMAttendanceViewController ()<AMapLocationManagerDelegate, EMAttendanceServiceDelegate, UIScrollViewDelegate, UITableViewDataSource, UITableViewDelegate, MAMapViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *locationLabel;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIView *toolBar;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) MAMapView *mapView;

@property (nonatomic, strong) UIButton *leaveButton;    //请假按钮
@property (nonatomic, strong) UIButton *dutyButton;     //考勤按钮

@property (nonatomic, strong) NSTimer *timer;

@property (nonatomic, strong) AMapLocationManager *locationManager;
@property (nonatomic, copy) AMapLocatingCompletionBlock completionBlock;
@property (nonatomic, copy) AMapLocatingCompletionBlock locationBlock;

@property (nonatomic, strong) EMAttendanceService *service;

@property (nonatomic, assign) EMAttendanceStatus status;

@property (nonatomic, copy) NSArray *attendances;

@property (nonatomic, assign) NSInteger refreshTag;

@property (nonatomic, strong) FJSActivityIndicatorView *upIndicator;

@end

@implementation EMAttendanceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.trackName = @"我的考勤";
    self.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    [self.view addSubview:self.mapView];
    
    [self configLocationManager];
    [self initCompleteBlock];
    [self initLocationBlock];
    [self layoutConstraints];
    [self getAttendanceStatus];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleDefault;
    self.navigationController.navigationBarHidden = YES;

    [self.service refreshAttendanceList];
    [self locAction];
    
    FJSLog(@"location = %d", [self isLocationServiceOpen]);
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    self.navigationController.navigationBarHidden = NO;
    
    [self.timer invalidate];
    self.timer = nil;
    
    [self cleanUpAction];
}

- (BOOL)isLocationServiceOpen {
    if ([ CLLocationManager authorizationStatus] == kCLAuthorizationStatusDenied) {
        return NO;
    }
    
    return YES;
}

#pragma mark - UI
- (void)layoutConstraints
{
    self.tableView.separatorColor = UIColorFromHex(0xdddddd);
    self.tableView.separatorInset = UIEdgeInsetsMake(0,0, 0, 0);
    
    [self.leaveButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.toolBar.mas_centerY);
        make.left.equalTo(@15);
        make.right.equalTo(self.dutyButton.mas_left).with.offset(-15);
        make.height.equalTo(@41);
        make.width.equalTo(self.dutyButton.mas_width);
    }];
    
    [self.dutyButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.toolBar.mas_centerY);
        make.right.equalTo(self.toolBar.mas_right).with.offset(-15);
        make.right.equalTo(self.leaveButton.mas_right).with.offset(15);
        make.height.equalTo(@41);
        make.width.equalTo(self.leaveButton.mas_width);
    }];
}

- (void)changeDutyButtonStatus:(EMAttendanceStatus)status
{
    NSString *title = nil;
    UIColor *titleColor = nil;
    UIColor *backgroundColor = nil;
    UIColor *borderColor = nil;
    switch (status) {
        case EMAttendanceStatusGoingToWork:
        case EMAttendanceStatusSickLeave:
        case EMAttendanceStatusAnnualLeave:
        case EMAttendanceStatusCasualLeave:
        case EMAttendanceStatusOther:
        {
            title = @"我已上班";
            titleColor = [UIColor whiteColor];
            backgroundColor = UIColorFromHex(0x00a0ea);
            borderColor = UIColorFromHex(0x00a0ea);
        }
            break;
            
        case EMAttendanceStatusOnDuty:
        {
            title = @"我已下班";
            titleColor = UIColorFromHex(0x00a0ea);
            backgroundColor = [UIColor whiteColor];
            borderColor = UIColorFromHex(0x00a0ea);
        }
            break;
            
        case EMAttendanceStatusOffDuty:
        case EMAttendanceStatusError:
        {
            title = @"我已上班";
            titleColor = [UIColor whiteColor];
            backgroundColor = UIColorFromHex(0xdddddd);
            borderColor = UIColorFromHex(0xdddddd);
            self.dutyButton.enabled = NO;
        }
            break;
    }
    
    
    [_dutyButton setTitle:title forState:UIControlStateNormal];
    [_dutyButton setTitleColor:titleColor forState:UIControlStateNormal];
    [_dutyButton setBackgroundColor:backgroundColor];
    _dutyButton.layer.borderColor = borderColor.CGColor;
}

#pragma mark - Time
- (void)updateTime
{
    NSString *timeStr = [NSDate fjs_todayInFormat:@"HH:mm:ss"];
    NSString *dateStr = [NSDate fjs_todayInFormat:@"YYYY年M月d日"];
    NSString *weekStr = [NSDate fjs_weekDayOfToday];
    
    self.timeLabel.text = timeStr;
    self.dateLabel.text = [NSString stringWithFormat:@"%@ %@", dateStr, weekStr];
}

#pragma mark - Attendance
- (void)getAttendanceStatus
{
    [self.service getAttendStatus];
    [EMHudManager showLoadingWithText:nil inView:self.view];
}

#pragma mark - Action
- (IBAction)handleBackAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)handleLeaveButtonAction:(UIButton *)sender
{
    FJSWebViewController *webViewController = [[FJSWebViewController alloc] initWithUrlString:kEMHtmlURLAttendLeave];
    [webViewController showLeftBarButtonItemWithImage:@"icon_back"];
    [self.navigationController pushViewController:webViewController animated:YES];
}

- (void)handleDutyButtonAction:(UIButton *)sender
{
    if ([self isLocationServiceOpen]) {
        self.dutyButton.enabled = NO;
        [self reGeocodeAction];
        [EMHudManager showLoadingWithText:nil inView:self.view];
    } else {
        FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeFailed title:@"定位失败" detail:@"请点击<确定>按钮前往系统设置打开定位" leftTitle:@"取消" rightTitle:@"确定" leftButtonBlock:nil rightButtonBlock:^{
            NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
            if ([[UIApplication sharedApplication] canOpenURL:url]) {
                [[UIApplication sharedApplication] openURL:url];
            }
        }];
        [alertView show];
    }
    
}

#pragma mark - Location
- (void)configLocationManager
{
    self.locationManager = [[AMapLocationManager alloc] init];
    [self.locationManager setDelegate:self];
    
    //设置期望定位精度
    [self.locationManager setDesiredAccuracy:kCLLocationAccuracyHundredMeters];
    
    //设置不允许系统暂停定位
    [self.locationManager setPausesLocationUpdatesAutomatically:NO];
    
    //设置允许在后台定位
    [self.locationManager setAllowsBackgroundLocationUpdates:NO];
    
    //设置定位超时时间
    [self.locationManager setLocationTimeout:kLocationTimeout];
    
    //设置逆地理超时时间
    [self.locationManager setReGeocodeTimeout:kReGeocodeTimeout];
}

- (void)cleanUpAction
{
    //停止定位
    [self.locationManager stopUpdatingLocation];
    [self.locationManager setDelegate:nil];
    
    self.completionBlock = nil;
}

- (void)reGeocodeAction
{
    //进行单次带逆地理定位请求
    [self.locationManager requestLocationWithReGeocode:YES completionBlock:self.completionBlock];
}

- (void)locAction
{
    //进行单次定位请求
    [self.locationManager requestLocationWithReGeocode:YES completionBlock:self.locationBlock];
}

- (void)initCompleteBlock
{
    __weak EMAttendanceViewController *weakSelf = self;
    self.completionBlock = ^(CLLocation *location, AMapLocationReGeocode *regeocode, NSError *error)
    {
        if (error != nil && error.code == AMapLocationErrorLocateFailed)
        {
            //定位错误：此时location和regeocode没有返回值，不进行annotation的添加
            FJSLog(@"定位错误:{%ld - %@};", (long)error.code, error.localizedDescription);
            FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:@"提示" detail:@"未获取到定位信息" buttonTitle:@"确定" completionBlock:nil];
            [alertView show];
            weakSelf.dutyButton.enabled = YES;
            [EMHudManager hideLoadingForView:weakSelf.view];
            return;
        }
        else if (error != nil
                 && (error.code == AMapLocationErrorReGeocodeFailed
                     || error.code == AMapLocationErrorTimeOut
                     || error.code == AMapLocationErrorCannotFindHost
                     || error.code == AMapLocationErrorBadURL
                     || error.code == AMapLocationErrorNotConnectedToInternet
                     || error.code == AMapLocationErrorCannotConnectToHost))
        {
            //逆地理错误：在带逆地理的单次定位中，逆地理过程可能发生错误，此时location有返回值，regeocode无返回值，进行annotation的添加
            FJSLog(@"逆地理错误:{%ld - %@};", (long)error.code, error.localizedDescription);
            FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:@"提示" detail:@"未获取到定位信息" buttonTitle:@"确定" completionBlock:nil];
            [alertView show];
            weakSelf.dutyButton.enabled = YES;
            [EMHudManager hideLoadingForView:weakSelf.view];
            return;
        }
        else if (error != nil && error.code == AMapLocationErrorRiskOfFakeLocation)
        {
            //存在虚拟定位的风险：此时location和regeocode没有返回值，不进行annotation的添加
            FJSLog(@"存在虚拟定位的风险:{%ld - %@};", (long)error.code, error.localizedDescription);
            FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:@"提示" detail:@"未获取到定位信息" buttonTitle:@"确定" completionBlock:nil];
            [alertView show];
            weakSelf.dutyButton.enabled = YES;
            [EMHudManager hideLoadingForView:weakSelf.view];
            return;
        }
        else
        {
            //没有错误：location有返回值，regeocode是否有返回值取决于是否进行逆地理操作，进行annotation的添加
        }
        
        //提交考勤数据
        if (regeocode)
        {
            FJSLog(@"%@", [NSString stringWithFormat:@"lat:%f;lon:%f \n accuracy:%.2fm", location.coordinate.latitude, location.coordinate.longitude, location.horizontalAccuracy]);
            FJSLog(@"%@", [NSString stringWithFormat:@"%@ \n %@-%@-%.2fm", regeocode.formattedAddress,regeocode.citycode, regeocode.adcode, location.horizontalAccuracy]);
            [weakSelf.service submitAttendanceInformationWithLocation:location reGeocode:regeocode status:weakSelf.status];
        }
    };
}

- (void)initLocationBlock
{
    __weak EMAttendanceViewController *weakSelf = self;
    self.locationBlock = ^(CLLocation *location, AMapLocationReGeocode *regeocode, NSError *error)
    {
        if (regeocode)
        {
            weakSelf.locationLabel.text = regeocode.formattedAddress;
        }
    };
}

#pragma mark - EMAttendanceServiceDelegate
- (void)service:(EMAttendanceService *)service attendanceStatus:(EMAttendanceStatus)status
{
    [EMHudManager hideLoadingForView:self.view];
    
    self.status = status;
    [self changeDutyButtonStatus:status];
}

- (void)service:(EMAttendanceService *)service submitAttendanceSuccess:(NSString *)address status:(EMAttendanceStatus)status;
{
    [EMHudManager hideLoadingForView:self.view];
    [self.service refreshAttendanceList];
    self.locationLabel.text = address;
    NSString *title = @"上班打卡成功";
    EMHUDShowType type = EMHUDShowTypeSuccess;
    if (status == EMAttendanceStatusOffDuty) {
        title = @"下班打卡成功，不可再进行下班操作";
    }
    else if (status == EMAttendanceStatusError) {
        title = @"打卡异常";
        type = EMHUDShowTypeFailed;
    }
    [EMHudManager showHudWithTitle:title detail:nil type:type completionBlock:nil];
    
    self.status = status;
    
    self.dutyButton.enabled = YES;
    [self changeDutyButtonStatus:status];
}

- (void)service:(EMAttendanceService *)service attendanceData:(NSArray *)attendances
{
    if (_refreshTag == 1) {
        //上拉刷新结束
        [self.upIndicator changeStatus:self.attendances.count != attendances.count];
        [self.upIndicator stopAnimating];
    }
    self.attendances = attendances;
    [self.tableView reloadData];
    
    CGRect upFrame = CGRectZero;
    if (self.tableView.contentSize.height < self.tableView.height) {
        upFrame = CGRectMake(0, 20 + self.tableView.height, SCREEN_WIDTH-20, 30);
    } else {
        upFrame = CGRectMake(0, 20 + self.tableView.contentSize.height, SCREEN_WIDTH-20, 30);
    }
    self.upIndicator.frame = upFrame;
    _refreshTag = 0;
}

#pragma mark - MAMapViewDelegate
- (void)mapView:(MAMapView *)mapView didAddAnnotationViews:(NSArray *)views
{
    MAAnnotationView *view = views[0];
    
    // 放到该方法中用以保证userlocation的annotationView已经添加到地图上了。
    if ([view.annotation isKindOfClass:[MAUserLocation class]])
    {
        MAUserLocationRepresentation *pre = [[MAUserLocationRepresentation alloc] init];
        pre.fillColor = [UIColorFromHex(0x00a0ea) colorWithAlphaComponent:0.3];
        pre.strokeColor = [UIColor colorWithRed:0.1 green:0.1 blue:0.9 alpha:1.0];
        pre.image = [UIImage imageNamed:@"userPosition"];
        pre.lineWidth = 0;
        
        [self.mapView updateUserLocationRepresentation:pre];
        
        view.calloutOffset = CGPointMake(0, 0);
        view.canShowCallout = NO;
    }
}

- (void)mapView:(MAMapView *)mapView didUpdateUserLocation:(MAUserLocation *)userLocation updatingLocation:(BOOL)updatingLocation
{
    if (updatingLocation) {
        [self locAction];
    }
    
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    EMAttendanceCellFrame *cellFrame = self.attendances[indexPath.row];
    return cellFrame.cellHeight;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.attendances.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //考勤没有复用的必要
    EMAttendTableViewCell *cell = [[[NSBundle mainBundle] loadNibNamed:@"EMAttendTableViewCell" owner:nil options:nil] lastObject];
    
    cell.cellFrame = self.attendances[indexPath.row];
    
    return cell;
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.contentOffset.y + scrollView.bounds.size.height > scrollView.contentSize.height) {
        _refreshTag = 1;
        [self.upIndicator startAnimating];
    }
}

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView
{
    if (_refreshTag == 1) {
        [self.service getAttendanceList];
    }
}

#pragma mark - Getter & setter
- (NSTimer *)timer
{
    if (!_timer) {
        _timer = [NSTimer timerWithTimeInterval:1.0 target:self selector:@selector(updateTime) userInfo:nil repeats:YES];
    }
    return _timer;
}

- (EMAttendanceService *)service
{
    if (!_service) {
        _service = [[EMAttendanceService alloc] init];
        _service.delegate = self;
    }
    return _service;
}

- (UIButton *)leaveButton
{
    if (!_leaveButton) {
        _leaveButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_leaveButton setTitle:@"请假" forState:UIControlStateNormal];
        [_leaveButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
        [_leaveButton setBackgroundColor:[UIColor whiteColor]];
        _leaveButton.titleLabel.font = [UIFont systemFontOfSize:16];
        _leaveButton.layer.masksToBounds = YES;
        _leaveButton.layer.cornerRadius = 2;
        _leaveButton.layer.borderWidth = 1;
        _leaveButton.layer.borderColor = UIColorFromHex(0x00a0ea).CGColor;
        [_leaveButton addTarget:self action:@selector(handleLeaveButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.toolBar addSubview:_leaveButton];
    }
    return _leaveButton;
}

- (UIButton *)dutyButton
{
    if (!_dutyButton) {
        _dutyButton = [UIButton buttonWithType:UIButtonTypeCustom];
        _dutyButton.titleLabel.font = [UIFont systemFontOfSize:16];
        _dutyButton.layer.masksToBounds = YES;
        _dutyButton.layer.cornerRadius = 2;
        _dutyButton.layer.borderWidth = 1;
        _dutyButton.layer.borderColor = UIColorFromHex(0x00a0ea).CGColor;
        [_dutyButton addTarget:self action:@selector(handleDutyButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.toolBar addSubview:_dutyButton];
    }
    return _dutyButton;
}

- (FJSActivityIndicatorView *)upIndicator
{
    if (!_upIndicator) {
        _upIndicator = [[FJSActivityIndicatorView alloc] initWithFrame:CGRectMake(0, 20 + self.tableView.contentSize.height, SCREEN_WIDTH-20, 30) style:FJSActivityIndicatorViewStyleUp];
        [self.tableView addSubview:_upIndicator];
    }
    return _upIndicator;
}

- (MAMapView *)mapView
{
    if (!_mapView) {
        CGRect frame = CGRectMake(0, 269, SCREEN_WIDTH, 190);
        frame.size.height = self.tableView.y - 269;
        _mapView = [[MAMapView alloc] initWithFrame:frame];
        _mapView.userInteractionEnabled = NO;
        _mapView.delegate = self;
        _mapView.showsUserLocation = YES;
        _mapView.userTrackingMode = MAUserTrackingModeFollow;
        _mapView.showsScale = NO;
        _mapView.showsCompass = NO;
        _mapView.zoomEnabled = NO;
        
        [_mapView setZoomLevel:16.5 animated:YES];
    }
    return _mapView;
}

@end
