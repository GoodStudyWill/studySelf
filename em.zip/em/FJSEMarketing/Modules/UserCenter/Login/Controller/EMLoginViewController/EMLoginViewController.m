//
//  EMLoginViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMLoginViewController.h"
#import "EMLoginView.h"
#import "EMQueryTicketApi.h"
#import "EMLoginApi.h"
#import "EMUserManager.h"
#import "EMGesturePasswordViewController.h"
#import "EMTabBarController.h"
#import "FJSAlertView.h"
#import "EMLoginService.h"
#import <FJSSystemInfo/FJSSystemInfo.h>
#import "EMNotificationCenter.h"
#import "EMAppConfigTableViewController.h"

static NSString * const kTipTitleHint = @"提示";
static NSString * const kTipTitleValidateFailed = @"验证失败";

static NSString * const kTipForgetPassword = @"请登录公司内网，在UM用户管理中修改密码。";
static NSString * const kTipWrongPassword = @"用户名或密码错误，若连续输入错误5次，UM账号将被锁定。";
static NSString * const kTipAccountLocked = @"UM账号已被锁定，请登录公司内网解锁。";

@interface EMLoginViewController ()<EMLoginViewDelegate, EMLoginServiceDelegate>

@property (nonatomic, strong) EMLoginService *service;

@property (nonatomic, strong) EMLoginView *loginView;

@end

@implementation EMLoginViewController

#pragma mark - Life cycle
- (void)viewDidLoad
{
    [super viewDidLoad];
//    self.trackName = @"账号密码登录";
    self.loginView = [[EMLoginView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
    self.loginView.delegate = self;
    [self.view addSubview:self.loginView];
    
    [[EMNotificationCenter sharedInstance] clearNotifications];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = YES;
    
    [self.service getVersionConfigForce:YES success:nil failure:nil];
}

#pragma mark - EMLoginViewDelegate
- (void)handleLoginActionWithAccount:(NSString *)account password:(NSString *)password
{
    [self.view endEditing:YES];
    [EMHudManager showLoadingWithText:nil inView:self.view];
    [self.service loginWithAccount:account password:password loginType:EMLoginTypePassword];
}

- (void)handleTapLoginHeaderBackground
{
    EMAppConfigTableViewController *controller = [[EMAppConfigTableViewController alloc] init];
    [self.navigationController pushViewController:controller animated:YES];
}

#pragma mark - EMLoginServiceDelegate
- (void)loginSuccess:(BOOL)gotoGesture
{
    [self.loginView clearPassword];
    [EMHudManager hideLoadingForView:self.view];
    if (gotoGesture) {
        EMGesturePasswordViewController *gesturePasswordVC = [[EMGesturePasswordViewController alloc] initWithMode:EMGesterePasswordModeInitting];
        [self.navigationController pushViewController:gesturePasswordVC animated:YES];
    } else {
        EMTabBarController *tabBarController = [[EMTabBarController alloc] init];
        [self presentViewController:tabBarController animated:YES completion:^{
            
        }];
    }
}

- (void)loginFailed:(NSString *)flag message:(NSString *)msg
{
    [EMHudManager hideLoadingForView:self.view];
    
    //获取强升失败
    if ([flag isEqualToString:kEMLoginServiceGetVersionFailedFlag]) {
        return;
    }
    
    FJSAlertViewType type = FJSAlertViewTypeWarning;
    NSString *title = @"提示";
    NSString *detail = msg;
    if ([flag isEqualToString:@"0001"]) {
        //未开通系统权限
        title = @"登录失败";
        type = FJSAlertViewTypeFailed;
    }
    else if ([flag isEqualToString:@"0002"]) {
        //密码错误
        title = @"验证失败";
        type = FJSAlertViewTypeFailed;
    }
    else if ([flag isEqualToString:@"0003"]) {
        //UM账号被锁定
        type = FJSAlertViewTypeFailed;
        detail = @"UM账号已被锁定，请登陆公司内网在UM用户管理选择“忘记UM密码”";
    }
    
    FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:type title:title detail:detail buttonTitle:@"确定" completionBlock:nil];
    [alertView show];
}

#pragma mark - Setter & getter
- (EMLoginService *)service
{
    if (!_service) {
        _service = [[EMLoginService alloc] init];
        _service.delegate = self;
    }
    return _service;
}



@end
