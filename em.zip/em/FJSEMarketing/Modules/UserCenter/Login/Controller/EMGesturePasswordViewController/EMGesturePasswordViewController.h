//
//  EMGesturePasswordViewController.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/17.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, EMGesterePasswordMode) {
    EMGesterePasswordModeInitting,              //登录设置手势密码
    EMGesterePasswordModeSetting,               //设置手势密码
    EMGesterePasswordModeVerification,          //验证手势密码
};

@interface EMGesturePasswordViewController : UIViewController

- (instancetype)initWithMode:(EMGesterePasswordMode)mode;

@end
