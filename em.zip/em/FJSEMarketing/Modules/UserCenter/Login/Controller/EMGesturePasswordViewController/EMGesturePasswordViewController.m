//
//  EMGesturePasswordViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/17.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMGesturePasswordViewController.h"
#import "EMUserManager.h"
#import "EMLoginViewController.h"
#import "EMTabBarController.h"
#import "EMLoginService.h"
#import "EMMyAccountViewController.h"
#import "FJSAlertView.h"
#import "UIBarButtonItem+FJSUIKit.h"

//按钮的数量
static NSInteger const kPassWordNumber = 9;
//列数
static NSInteger const kVerticalNumber = 3;
//行数
static NSInteger const kHorizontalNumber = 3;
//按钮宽高
static CGFloat const kBtnWidth = 32.0;

static NSInteger const kTag = 10000;

static NSUInteger const kLeastPointNum = 5;

//错误次数
static NSUInteger const kErrorTimes = 5;

@interface EMGesturePasswordViewController ()<EMLoginServiceDelegate>

//初始化的按钮
@property (nonatomic, strong) NSMutableArray *nomalPasswords;
//手势描绘的按钮数组
@property (nonatomic, strong) NSMutableArray *addPasswords;
//移动过程中的路径
@property (nonatomic, assign) CGPoint endPoint;
//密码正确或者常规绘画时的颜色
@property (nonatomic, strong) UIColor *rightLineColor;
//密码错误时的颜色
@property (nonatomic, strong) UIColor *errorLineColor;
//画线用的view
@property (nonatomic, strong) UIImageView *drawLineImageView;
//是否手势完成
@property (nonatomic, assign) BOOL drawPasswordOver;
//错误次数
@property (nonatomic, assign) NSUInteger errorTime;

@property (nonatomic, strong) UILabel *tipLabel;

@property (nonatomic, strong) UILabel *welcomeLabel;

@property (nonatomic, strong) UIButton *skipButton;

@property (nonatomic, strong) UIButton *elseButton;

//默认密码或者设置后的密码
@property (nonatomic, copy)   NSString *password;

@property (nonatomic, assign) EMGesterePasswordMode mode;

@property (nonatomic, strong) EMLoginService *service;

@end

@implementation EMGesturePasswordViewController

- (instancetype)initWithMode:(EMGesterePasswordMode)mode
{
    self = [super init];
    if (self) {
        self.nomalPasswords = [[NSMutableArray alloc] initWithCapacity:kPassWordNumber];
        self.drawPasswordOver = NO;
        self.mode = mode;
        self.errorTime = 0;
        
//        switch (self.mode) {
//            case EMGesterePasswordModeSetting:
//            {
//                self.trackName = @"重置手势密码";
//            }
//                break;
//                
//            case EMGesterePasswordModeInitting:
//            {
//                self.trackName = @"设置手势密码";
//            }
//                break;
//                
//            case EMGesterePasswordModeVerification:
//            {
//                self.trackName = @"手势密码登录";
//            }
//                break;
//        }
        
        self.view.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self initViews];
    [self initMode];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    BOOL isHideNavigationBar = self.mode != EMGesterePasswordModeSetting;
    self.navigationController.navigationBar.hidden = isHideNavigationBar;
    if (!isHideNavigationBar) {
        self.title = @"设置手势密码";
        self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName : [UIColor whiteColor]};
        self.navigationItem.leftBarButtonItem = [UIBarButtonItem showLeftBarButtonItemWithTitle:@"" orButtonImage:@"icon_back" target:self selector:@selector(clickLeftBarButton:)];
    }
    
    if (self.mode == EMGesterePasswordModeVerification) {
        [self.service getVersionConfigForce:YES success:nil failure:nil];
    }
}

- (void)clickLeftBarButton:(id)sender
{
    for (UIViewController *tempVC in self.navigationController.viewControllers) {
        if ([tempVC isKindOfClass:[EMMyAccountViewController class]]) {
            [self.navigationController popToViewController:tempVC animated:YES];
        }
    }
}

#pragma mark - Init
- (void)initViews
{
    self.drawLineImageView = [[UIImageView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:_drawLineImageView];
    
    [self.view addSubview:self.tipLabel];
    
    //第一个按钮的x坐标 / 按钮列向间的距离 4.0为 kVerticalNumber + 1
    CGFloat kBtnX = (SCREEN_WIDTH - (kVerticalNumber * kBtnWidth)) / 4.0;
    
    CGFloat btnY = self.mode == EMGesterePasswordModeSetting ? 120 : 180;

    //按钮横向间的间距
    CGFloat kBtnPading_Y = 70 + kBtnWidth;
    
    //此处将九宫格列为 3 * 3的格式
    for (int i = 0; i < kHorizontalNumber; i ++)
    {
        for (int j = 0; j < kVerticalNumber; j ++)
        {
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            //三种状态 分别代表默认 错误 和密码正确的时候（或者是在滑动过程中）
            [btn setImage:[UIImage imageNamed:@"icon_gesture_nor"] forState:UIControlStateNormal];
            [btn setImage:[UIImage imageNamed:@"icon_gesture_sel"] forState:UIControlStateSelected];
            [btn setImage:[UIImage imageNamed:@"icon_gesture_sel"] forState:UIControlStateHighlighted];
            //屏蔽触控事件 view 的touch事件才能接收
            btn.userInteractionEnabled = NO;
            btn.tag = kTag + i * kVerticalNumber + j + 1;
            
            [self.view addSubview:btn];
            
            [btn setFrame:CGRectMake(kBtnX *(j + 1) + j * kBtnWidth, btnY + 80 + kBtnPading_Y * i, kBtnWidth, kBtnWidth)];
            
            [self.nomalPasswords addObject:btn];
        }
    }
}

//模式设置
- (void)initMode
{
    if (self.mode == EMGesterePasswordModeVerification)
    {
        self.password = [EMUserManager sharedInstance].gestureCode;
        self.tipLabel.text = @"请输入手势密码";
        
        [self.view addSubview:self.welcomeLabel];
        [self.view addSubview:self.elseButton];
    }
    else
    {
        self.password = @"";
        self.tipLabel.text = @"请设置手势密码";
        
        if (self.mode == EMGesterePasswordModeInitting) {
            [self.view addSubview:self.skipButton];
            
            //防止出现用户设置手势密码杀掉进程重新进入
            [[EMUserManager sharedInstance] setShowLoginNextTime:YES];
            [[EMUserManager sharedInstance] setGestureCode:@""];
            [[EMUserManager sharedInstance] setGestureLogin:NO];
        } else {
            UIView *grayView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 5)];
            grayView.backgroundColor = UIColorFromHex(0xeeeeee);
            [self.view addSubview:grayView];
        }
    }
    [self cleanPassword];
}

#pragma mark - Touch event
- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if (self.drawPasswordOver)
    {
        return;
    }
    UITouch *touch = [touches anyObject];
    
    if (touch)
    {
        for (UIButton *button in self.nomalPasswords)
        {
            CGPoint point = [touch locationInView:button];
            //判断当前点击的点是否在button 的view范围内
            if ([button pointInside:point withEvent:event])
            {
                
                //此处设置画线的终点 是为了保证在点击按钮不动的时候 因为终点坐标初始为（0,0）所以线就到左上角去了
                if (self.endPoint.x == 0 && self.endPoint.y == 0)
                {
                    self.endPoint = button.center;
                }
                
                [self.addPasswords addObject:button];
                
                button.highlighted = YES;
                
                break;
            }
        }
    }
    
    self.drawLineImageView.image = [self imageWithColor:self.rightLineColor];
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if (self.drawPasswordOver)
    {
        return;
    }
    
    UITouch *touch = [touches anyObject];
    
    if (touch)
    {
        //移动过程中不断的几率当前的坐标
        self.endPoint = [touch locationInView:self.drawLineImageView];
        
        for (UIButton *button in self.nomalPasswords)
        {
            CGPoint point = [touch locationInView:button];
            if ([button pointInside:point withEvent:event])
            {
                //判断该按钮是否已经被手势划过
                BOOL haveAdd = NO;
                
                for (UIButton *btn in self.addPasswords)
                {
                    if (button == btn)
                    {
                        haveAdd = YES;
                        break;
                    }
                }
                
                if (!haveAdd)
                {
                    [self.addPasswords addObject:button];
                    
                    button.highlighted = YES;
                    
                    break;
                }
            }
        }
    }
    
    self.drawLineImageView.image = [self imageWithColor:self.rightLineColor];
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    if (self.drawPasswordOver)
    {
        return;
    }
    
    UITouch *touch = [touches anyObject];
    
    if (touch)
    {
        if (self.addPasswords.count == 0)
        {
            return;
        }
        else{
            
            //手势移动结束的时候 将最后一个按钮的中心设为终点坐标
            UIButton *btn = [self.addPasswords lastObject];
            
            self.endPoint = btn.center;
        }
    }
    
    self.drawLineImageView.image = [self imageWithColor:self.rightLineColor];
    
    self.drawPasswordOver = YES;
    
    //验证密码
    if (self.mode == EMGesterePasswordModeVerification)
    {
        [self validatePassword];
    }
    //设置密码
    else
    {
        if (self.password.length == 0)
        {
            self.password = [self getPassword];
            
            if (self.password.length < kLeastPointNum) {
                self.password = @"";
                self.tipLabel.text = [NSString stringWithFormat:@"手势密码至少连接%lu个点，请重新设置", kLeastPointNum];
                self.tipLabel.textColor = UIColorFromHex(0xff6238);
            } else {
                self.tipLabel.text = @"请再次输入手势密码";
                self.tipLabel.textColor = UIColorFromHex(0x999999);
            }
            
            [self cleanPassword];
        }
        else
        {
            NSString *nextPassword = [self getPassword];
            
            if (![self.password isEqualToString:nextPassword])
            {
                [self errorPasswordTip];
            }
            else
            {
                //下一步操作
                [EMUserManager sharedInstance].gestureCode = self.password;
                [EMUserManager sharedInstance].gestureLogin = YES;
                FJSLog(@"gesture=>%@", [EMUserManager sharedInstance].gestureCode);
                
                __weak EMGesturePasswordViewController *weakSelf = self;
                [EMHudManager showHudWithTitle:@"设置成功" detail:@"手势密码设置成功，页面将自动跳转。" type:EMHUDShowTypeSuccess completionBlock:^{
                    if (weakSelf.mode == EMGesterePasswordModeSetting) {
                        for (UIViewController *tempVC in weakSelf.navigationController.viewControllers) {
                            if ([tempVC isKindOfClass:[EMMyAccountViewController class]]) {
                                [weakSelf.navigationController popToViewController:tempVC animated:YES];
                            }
                        }
                    } else if (weakSelf.mode == EMGesterePasswordModeInitting) {
                        [weakSelf loginSuccess];
                        [[EMUserManager sharedInstance] setShowLoginNextTime:NO];
                    }
                }];
            }
        }
    }
}

#pragma mark - Action
- (void)handleSkipButtonAction
{
    [[EMUserManager sharedInstance] clearGesture];
    [self loginSuccess];
}

- (void)handleElseButtonAction
{
    [self showLogin];
}

- (void)loginSuccess
{
    [self cleanPassword];
    EMTabBarController *tabBarController = [[EMTabBarController alloc] init];
    [self presentViewController:tabBarController animated:YES completion:^{
        
    }];
}

- (void)showLogin
{
    EMLoginViewController *loginViewController = [[EMLoginViewController alloc] initWithNibName:@"EMLoginViewController" bundle:nil];
    [self.navigationController pushViewController:loginViewController animated:YES];
}

#pragma mark - Draw image
//根据颜色绘制图片
- (UIImage *)imageWithColor:(UIColor *)color{
    UIImage *image = nil;
    
    if (self.addPasswords.count > 0)
    {
        UIButton * startButton = self.addPasswords[0];
        
        UIGraphicsBeginImageContext(self.drawLineImageView.bounds.size);
        CGContextRef context = UIGraphicsGetCurrentContext();
        CGContextSetStrokeColorWithColor(context, color.CGColor);
        CGContextSetLineWidth(context, 1);
        
        CGContextMoveToPoint(context, startButton.center.x, startButton.center.y);
        
        for (UIButton *button in self.addPasswords)
        {
            CGPoint point = button.center;
            CGContextAddLineToPoint(context, point.x, point.y);
            CGContextMoveToPoint(context, point.x, point.y);
        }
        
        CGContextAddLineToPoint(context, self.endPoint.x, self.endPoint.y);
        
        CGContextStrokePath(context);
        
        image = UIGraphicsGetImageFromCurrentImageContext();
        UIGraphicsEndImageContext();
        
        return image;
    }
    
    return nil;
}

#pragma mark - Handle password
- (NSString *)getPassword
{
    NSString *resultPassword = @"";
    
    for (UIButton *btn in self.addPasswords)
    {
        resultPassword = [NSString stringWithFormat:@"%@%ld",resultPassword,btn.tag - kTag];
    }
    return resultPassword;
}

//清除信息
- (void)cleanPassword
{
    for (UIButton *btn in self.addPasswords)
    {
        btn.selected = NO;
        btn.highlighted = NO;
    }
    
    self.drawLineImageView.image = nil;
    self.drawPasswordOver = NO;
    [self.addPasswords removeAllObjects];
    self.endPoint = CGPointZero;
}

//验证密码是否正确
- (void)validatePassword
{
    NSString *password = [self getPassword];
    if (![self.password isEqualToString:password])
    {
        for (UIButton *btn in self.addPasswords)
        {
            btn.selected = YES;
            btn.highlighted = NO;
        }
        self.drawLineImageView.image = [self imageWithColor:self.errorLineColor];
        
        self.tipLabel.text = @"您输入的手势密码错误，请重新输入";
        self.tipLabel.textColor = UIColorFromHex(0xff6238);
        
        self.errorTime++;
        if (self.errorTime >= kErrorTimes) {
            //错误次数达到5次
            [self attainErrorTimes];
        }
        [self cleanPassword];
    }
    else
    {
        //验证成功
        
        [EMHudManager showLoadingWithText:nil inView:self.view];
        NSString *account = [EMUserManager sharedInstance].userID;
        NSString *password = [EMUserManager sharedInstance].securityData;
        [self.service loginWithAccount:account password:password loginType:EMLoginTypeGesture];
    }
}

//两次密码错误提示
- (void)errorPasswordTip
{
    for (UIButton *btn in self.addPasswords)
    {
        btn.selected = YES;
        btn.highlighted = NO;
    }
    self.drawLineImageView.image = [self imageWithColor:self.errorLineColor];
    
    self.password = @"";
    
    self.tipLabel.text = @"两次输入的图案不一致，请重新设置";
    self.tipLabel.textColor = UIColorFromHex(0xff6238);
    
    [self cleanPassword];
}

- (void)attainErrorTimes
{
    [[EMUserManager sharedInstance] setShowLoginNextTime:YES];
    
    __weak EMGesturePasswordViewController *weakSelf = self;
    [EMHudManager showHudWithTitle:@"验证失败" detail:@"您的手势密码已连续错误5次，将跳转至UM账户登录页面。" type:EMHUDShowTypeFailed completionBlock:^{
        [weakSelf showLogin];
    }];
}

#pragma mark - EMLoginServiceDelegate
- (void)loginSuccess:(BOOL)gotoGesture
{
    [EMHudManager hideLoadingForView:self.view];
    [self loginSuccess];
}

- (void)loginFailed:(NSString *)flag message:(NSString *)msg
{
    [EMHudManager hideLoadingForView:self.view];
    [self cleanPassword];
    
    //获取强升失败
    if ([flag isEqualToString:kEMLoginServiceGetVersionFailedFlag]) {
        return;
    }
    
    FJSAlertViewType type = FJSAlertViewTypeWarning;
    NSString *title = @"提示";
    NSString *detail = msg;
    if ([flag isEqualToString:@"0001"]) {
        //未开通系统权限
        title = @"登录失败";
        type = FJSAlertViewTypeFailed;
    }
    else if ([flag isEqualToString:@"0002"]) {
        //密码错误
        title = @"验证失败";
        type = FJSAlertViewTypeFailed;
    }
    else if ([flag isEqualToString:@"0003"]) {
        //UM账号被锁定
        type = FJSAlertViewTypeFailed;
        detail = @"UM账号已被锁定，请登陆公司内网在UM用户管理选择“忘记UM密码”";
    }
    
    FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:type title:title detail:detail buttonTitle:@"确定" completionBlock:nil];
    [alertView show];
}

#pragma mark - Setter & getter
- (void)setPassword:(NSString *)password
{
    if (_password != password)
    {
        _password = [password copy];
    }
}

- (NSMutableArray *)nomalPasswords
{
    if (!_nomalPasswords)
    {
        _nomalPasswords = [[NSMutableArray alloc] init];
    }
    return _nomalPasswords;
}

- (NSMutableArray *)addPasswords
{
    if (!_addPasswords)
    {
        _addPasswords = [[NSMutableArray alloc] init];
    }
    return _addPasswords;
}

- (UIImageView *)drawLineImageView
{
    if (!_drawLineImageView)
    {
        _drawLineImageView = [[UIImageView alloc] init];
    }
    return _drawLineImageView;
}

- (UILabel *)tipLabel
{
    if (!_tipLabel) {
        CGFloat tipY = self.mode == EMGesterePasswordModeSetting ? 100 : 160;
        _tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, tipY, SCREEN_WIDTH, 30)];
        _tipLabel.font = [UIFont systemFontOfSize:17];
        _tipLabel.textColor = UIColorFromHex(0x999999);
        _tipLabel.textAlignment = NSTextAlignmentCenter;
    }
    return _tipLabel;
}

- (UIColor *)rightLineColor
{
    if (!_rightLineColor)
    {
        _rightLineColor = UIColorFromHex(0x00a0ea);
    }
    return _rightLineColor;
}

- (UIColor *)errorLineColor
{
    if (!_errorLineColor)
    {
        _errorLineColor = UIColorFromHex(0xeb4f38);
    }
    return _errorLineColor;
}

- (UILabel *)welcomeLabel
{
    if (!_welcomeLabel) {
        _welcomeLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 75, SCREEN_WIDTH, 30)];
        _welcomeLabel.textAlignment = NSTextAlignmentCenter;
        
        NSString *name = [EMUserManager sharedInstance].userName;
        NSString *str = [NSString stringWithFormat:@"欢迎回来，%@", name];
        NSMutableAttributedString *welcomeStr = [[NSMutableAttributedString alloc] initWithString:str];
        [welcomeStr addAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:18],
                                    NSForegroundColorAttributeName : UIColorFromHex(0x666666)}
                            range:NSMakeRange(0, 4)];
        [welcomeStr addAttributes:@{NSFontAttributeName : [UIFont boldSystemFontOfSize:24],
                                    NSForegroundColorAttributeName : UIColorFromHex(0x00a0ea)}
                            range:NSMakeRange(5, str.length - 5)];
        _welcomeLabel.attributedText = welcomeStr;
    }
    return _welcomeLabel;
}

- (UIButton *)skipButton
{
    if (!_skipButton) {
        _skipButton = [[UIButton alloc] initWithFrame:CGRectMake((SCREEN_WIDTH - 50)/2, SCREEN_HEIGHT - 55 - 25, 50, 25)];
        
        NSMutableAttributedString *title = [[NSMutableAttributedString alloc] initWithString:@"跳过"];
        [title addAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:17],
                               NSForegroundColorAttributeName : UIColorFromHex(0x00a0ea),
                               NSUnderlineStyleAttributeName : @(NSUnderlineStyleSingle)}
                       range:NSMakeRange(0, title.length)];
        [_skipButton setAttributedTitle:title forState:UIControlStateNormal];
        
        [_skipButton addTarget:self action:@selector(handleSkipButtonAction) forControlEvents:UIControlEventTouchUpInside];

    }
    return _skipButton;
}

- (UIButton *)elseButton
{
    if (!_elseButton) {
        _elseButton = [[UIButton alloc] initWithFrame:CGRectMake((SCREEN_WIDTH - 130)/2, SCREEN_HEIGHT - 55 - 25, 130, 25)];
        
        NSMutableAttributedString *title = [[NSMutableAttributedString alloc] initWithString:@"其他方式登录"];
        [title addAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:17],
                               NSForegroundColorAttributeName : UIColorFromHex(0x00a0ea),
                               NSUnderlineStyleAttributeName : @(NSUnderlineStyleSingle)}
                       range:NSMakeRange(0, title.length)];
        [_elseButton setAttributedTitle:title forState:UIControlStateNormal];
        
        [_elseButton addTarget:self action:@selector(handleElseButtonAction) forControlEvents:UIControlEventTouchUpInside];
    }
    return _elseButton;
}

- (EMLoginService *)service
{
    if (!_service) {
        _service = [[EMLoginService alloc] init];
        _service.delegate = self;
    }
    return _service;
}


@end
