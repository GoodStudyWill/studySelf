//
//  EMLoginApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>
#import "EMLoginService.h"

@interface EMLoginApi : FJSApi

/**
 初始化

 @param account 账号
 @param password 密码
 @param ticket 防重校验码
 @param loginType 登录方式, 1:常规登录, 2:手势密码
 @return 对象
 */
- (instancetype)initWithAccount:(NSString *)account
                       password:(NSString *)password
                         ticket:(NSString *)ticket
                      loginType:(EMLoginType)loginType;

@end
