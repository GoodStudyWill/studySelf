//
//  EMQueryTicketApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMQueryTicketApi.h"

@implementation EMQueryTicketApi

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"user/queryTicket.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{@"queryTime" : [NSString stringWithFormat:@"%@", [NSDate date]]};
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
