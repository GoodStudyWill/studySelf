//
//  EMExitLoginApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/17.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMExitLoginApi.h"

@implementation EMExitLoginApi

- (NSString *)requestUrl
{
    return @"user/exitLogin.do";
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
