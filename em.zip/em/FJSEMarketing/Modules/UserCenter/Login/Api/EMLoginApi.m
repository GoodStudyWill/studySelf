//
//  EMLoginApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMLoginApi.h"
#import "EMNotificationCenter.h"

@interface EMLoginApi ()

@property (nonatomic, copy) NSString *account;
@property (nonatomic, copy) NSString *password;
@property (nonatomic, copy) NSString *ticket;
@property (nonatomic, copy) NSString *loginType;

@end

@implementation EMLoginApi

- (instancetype)initWithAccount:(NSString *)account
                       password:(NSString *)password
                         ticket:(NSString *)ticket
                      loginType:(EMLoginType)loginType
{
    self = [super init];
    if (self) {
        _account = account;
        _password = loginType == EMLoginTypePassword ? [password fjs_RSAEncrypt] : password;
        _loginType = [NSString stringWithFormat:@"%ld", loginType];
        
        UInt64 recordTime = [[NSDate date] timeIntervalSince1970] * 1000;
        _ticket = [NSString stringWithFormat:@"%@-%llu", ticket, recordTime];
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"user/login.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{@"ticket"       : [_ticket ?: @"" fjs_RSAEncrypt],
                            @"userId"       : [_account ?: @"" fjs_RSAEncrypt],
                            @"password"     : _password ?: @"",
                            @"loginType"    : _loginType ?: @"",
                            @"deviceToken"  : [EMNotificationCenter sharedInstance].deviceToken ?: @"",
                            };
    
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
