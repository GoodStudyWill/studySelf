//
//  EMLoginView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/14.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol EMLoginViewDelegate <NSObject>

- (void)handleLoginActionWithAccount:(NSString *)account password:(NSString *)password;

- (void)handleTapLoginHeaderBackground;

@end

@interface EMLoginView : UIView

@property (nonatomic, weak) id<EMLoginViewDelegate> delegate;

- (void)clearPassword;

@end
