//
//  EMLoginView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/14.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMLoginView.h"
#import "EMUserManager.h"
#import "FJSAlertView.h"
#import "NSString+FJSExtension.h"

typedef NS_ENUM(NSUInteger, EMLoginTipType) {
    EMLoginTipTypeNoAccount,                //没账号
    EMLoginTipTypeNoAccountAndPassword,     //没账号和密码
    EMLoginTipTypeNoPassword,               //没密码
};

@interface EMLoginView ()<UITextFieldDelegate>

@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UITextField *accountTextField;
@property (nonatomic, strong) UITextField *passwordTextField;

@property (nonatomic, strong) UIImageView *tipImageView;
@property (nonatomic, strong) UILabel *tipLabel;

@property (nonatomic, assign) CGFloat contentViewCenterY;

@end

@implementation EMLoginView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initViews];
        
        UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapAction:)];
        tapGR.numberOfTapsRequired = 1;
        [self addGestureRecognizer:tapGR];

    }
    return self;
}

- (void)initViews
{
    UIImageView *backgroundImageView = [UIImageView new];
    backgroundImageView.image = [UIImage imageNamed:@"bg_login.jpg"];
    backgroundImageView.contentMode = UIViewContentModeScaleAspectFill;
    [self addSubview:backgroundImageView];
    
    UIImageView *logoImageView = [UIImageView new];
    logoImageView.image = [UIImage imageNamed:@"logo"];
    logoImageView.contentMode = UIViewContentModeScaleAspectFit;
    logoImageView.userInteractionEnabled = YES;
    [self addSubview:logoImageView];
    
    UITapGestureRecognizer *tapBgGR = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapBackgroundAction:)];
    tapBgGR.numberOfTapsRequired = 5;
    [logoImageView addGestureRecognizer:tapBgGR];
    
    [backgroundImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self);
        make.width.equalTo(self);
        make.height.equalTo(@294);
    }];
    
    [logoImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).with.offset(68);
        make.centerX.equalTo(self.mas_centerX);
        make.width.equalTo(@240);
    }];
    
    [self initContentViews];
}

- (void)initContentViews
{
    self.contentView = [UIView new];
    self.contentView.backgroundColor = [UIColor whiteColor];
    self.contentView.layer.cornerRadius = 6;
    self.contentView.layer.shadowColor = [UIColor lightGrayColor].CGColor;
    self.contentView.layer.shadowOffset = CGSizeMake(1, 1);
    self.contentView.layer.shadowRadius = 3;
    self.contentView.layer.shadowOpacity = 0.5;
    [self addSubview:self.contentView];
    
    UIImageView *accountIcon = [UIImageView new];
    accountIcon.image = [UIImage imageNamed:@"icon_UM"];
    [self.contentView addSubview:accountIcon];
    
    UIImageView *passwordIcon = [UIImageView new];
    passwordIcon.image = [UIImage imageNamed:@"icon_key"];
    [self.contentView addSubview:passwordIcon];
    
    self.accountTextField = [UITextField new];
    self.accountTextField.font = [UIFont systemFontOfSize:15];
    self.accountTextField.text = [EMUserManager sharedInstance].userID;
    self.accountTextField.placeholder = @"请输入UM账号";
    self.accountTextField.borderStyle = UITextBorderStyleNone;
    self.accountTextField.keyboardType = UIKeyboardTypeASCIICapable;
    self.accountTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.accountTextField.returnKeyType = UIReturnKeyNext;
    [self.accountTextField addTarget:self action:@selector(handleEditingChanged:) forControlEvents:UIControlEventEditingChanged];
    self.accountTextField.delegate = self;
    [self.contentView addSubview:self.accountTextField];
    
    UIView *accountLine = [UIView new];
    accountLine.backgroundColor = UIColorFromHex(0xdddddd);
    [self.accountTextField addSubview:accountLine];
    
    self.passwordTextField = [UITextField new];
    self.passwordTextField.font = [UIFont systemFontOfSize:15];
    self.passwordTextField.placeholder = @"请输入登录密码";
    self.passwordTextField.borderStyle = UITextBorderStyleNone;
    self.passwordTextField.secureTextEntry = YES;
    self.passwordTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.passwordTextField.returnKeyType = UIReturnKeyDone;
    [self.passwordTextField addTarget:self action:@selector(handleEditingChanged:) forControlEvents:UIControlEventEditingChanged];
    self.passwordTextField.delegate = self;
    [self.contentView addSubview:self.passwordTextField];
    
    UIView *passwordLine = [UIView new];
    passwordLine.backgroundColor = UIColorFromHex(0xdddddd);
    [self.passwordTextField addSubview:passwordLine];
    
    UIButton *loginButton = [UIButton buttonWithType:UIButtonTypeCustom];
    loginButton.backgroundColor = UIColorFromHex(0x00a0ea);
    loginButton.layer.cornerRadius = 4;
    [loginButton setTitle:@"登录" forState:UIControlStateNormal];
    [loginButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    loginButton.titleLabel.font = [UIFont systemFontOfSize:18];
    [loginButton addTarget:self action:@selector(handleLoginAction) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:loginButton];
    
    self.tipImageView = [UIImageView new];
    self.tipImageView.image = [UIImage imageNamed:@"img_tip"];
    self.tipImageView.hidden = YES;
    [self.contentView addSubview:self.tipImageView];
    
    self.tipLabel = [UILabel new];
    self.tipLabel.textColor = UIColorFromHex(0x333333);
    self.tipLabel.font = [UIFont systemFontOfSize:12];
    self.tipLabel.textAlignment = NSTextAlignmentCenter;
    [self.tipImageView addSubview:self.tipLabel];
    
    UIButton *forgetButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [forgetButton setTitle:@"忘记密码?" forState:UIControlStateNormal];
    [forgetButton setTitleColor:UIColorFromHex(0x999999) forState:UIControlStateNormal];
    forgetButton.titleLabel.font = [UIFont systemFontOfSize:12];
    [forgetButton addTarget:self action:@selector(handleForgetPasswordAction) forControlEvents:UIControlEventTouchUpInside];
    [self.contentView addSubview:forgetButton];
    
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).with.offset(237);
        make.centerX.equalTo(self.mas_centerX);
        make.size.mas_equalTo(CGSizeMake(335, 363));
    }];
    
    [accountIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.contentView.mas_top).with.offset(80);
        make.left.equalTo(self.contentView.mas_left).with.offset(28);
        make.size.mas_equalTo(CGSizeMake(14, 14));
    }];
    
    [passwordIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(accountIcon.mas_bottom).with.offset(40);
        make.left.equalTo(self.contentView.mas_left).with.offset(28);
        make.size.mas_equalTo(CGSizeMake(14, 14));
    }];
    
    [self.accountTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(accountIcon.mas_centerY);
        make.left.equalTo(accountIcon.mas_right).with.offset(25);
        make.right.equalTo(self.contentView.mas_right).with.offset(-30);
    }];
    
    [accountLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.accountTextField.mas_bottom);
        make.left.equalTo(self.accountTextField);
        make.width.equalTo(self.accountTextField.mas_width);
        make.height.equalTo(@1);
    }];
    
    [self.passwordTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(passwordIcon.mas_centerY);
        make.left.equalTo(passwordIcon.mas_right).with.offset(25);
        make.right.equalTo(self.contentView.mas_right).with.offset(-30);
    }];
    
    [passwordLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.passwordTextField.mas_bottom);
        make.left.equalTo(self.passwordTextField);
        make.width.equalTo(self.passwordTextField.mas_width);
        make.height.equalTo(@1);
    }];
    
    [loginButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.passwordTextField.mas_bottom).with.offset(50);
        make.centerX.equalTo(self.contentView.mas_centerX);
        make.size.mas_equalTo(CGSizeMake(282, 44));
    }];
    
    [self.tipImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.accountTextField.mas_left);
        make.size.mas_equalTo(CGSizeMake(115, 34));
        make.centerY.equalTo(self.accountTextField.mas_top).with.offset(-18);
    }];
    
    [self.tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.tipImageView.mas_left);
        make.right.equalTo(self.tipImageView.mas_right);
        make.height.equalTo(@28);
        make.top.equalTo(self.tipImageView.mas_top);
    }];
    
    [forgetButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(loginButton.mas_bottom).with.offset(20);
        make.height.equalTo(@15);
        make.centerX.equalTo(self.contentView.mas_centerX);
    }];
    
    [self layoutIfNeeded];
    _contentViewCenterY = self.contentView.centerY;
}

#pragma mark - Clear
- (void)clearPassword
{
    self.passwordTextField.text = @"";
}

#pragma mark - Event
- (void)handleTapAction:(UITapGestureRecognizer *)gr
{
    [self endEditing:YES];
}

- (void)handleTapBackgroundAction:(UITapGestureRecognizer *)gr
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handleTapLoginHeaderBackground)]) {
        [self.delegate handleTapLoginHeaderBackground];
    }
}

- (void)handleLoginAction
{
    FJSLog(@"handleLoginAction");
    NSString *accountText = [self.accountTextField.text fjs_trimString];
    if (accountText.length == 0) {
        EMLoginTipType loginType = EMLoginTipTypeNoAccount;
        if (self.passwordTextField.text.length == 0) {
            loginType = EMLoginTipTypeNoAccountAndPassword;
        }
        [self showTip:loginType];
        return;
    }
    
    if (self.passwordTextField.text.length == 0) {
        [self showTip:EMLoginTipTypeNoPassword];
        return;
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(handleLoginActionWithAccount:password:)]) {
        [self.delegate handleLoginActionWithAccount:accountText password:self.passwordTextField.text];
    }
}

- (void)handleForgetPasswordAction
{
    FJSLog(@"handleForgetPasswordAction");
    FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:@"提示" detail:@"请登录公司内网，在UM用户管理中修改密码" buttonTitle:@"确定" completionBlock:nil];
    [alertView show];
}

- (void)handleEditingChanged:(UITextField *)textField
{
    if (textField.text.length > 0) {
        self.tipImageView.hidden = YES;
    }
}

#pragma mark - Tip
- (void)showTip:(EMLoginTipType)tipType
{
    NSString *tipStr = nil;
    CGFloat centerY = 0;
    switch (tipType) {
        case EMLoginTipTypeNoAccount:
        {
            tipStr = @"请输入账号";
            centerY = self.accountTextField.y - 18;
        }
            break;
            
        case EMLoginTipTypeNoAccountAndPassword:
        {
            tipStr = @"请输入账号及密码";
            centerY = self.accountTextField.y - 18;
        }
            break;
            
        case EMLoginTipTypeNoPassword:
        {
            tipStr = @"请输入密码";
            centerY = self.passwordTextField.y - 18;
        }
            break;
    }
    
    CGPoint center = self.tipImageView.center;
    center.y = centerY;
    self.tipImageView.center = center;
    self.tipLabel.text = tipStr;
    self.tipImageView.hidden = NO;
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    self.tipImageView.hidden = YES;
    if (self.contentView.centerY != _contentViewCenterY) {
        return;
    }
    
    CGPoint center = self.contentView.center;
    center.y -= 100;
    [UIView animateWithDuration:0.3 animations:^{
        self.contentView.center = center;
    }];
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if (self.contentView.centerY == _contentViewCenterY) {
        return;
    }
    
    CGPoint center = self.contentView.center;
    center.y = _contentViewCenterY;
    [UIView animateWithDuration:0.3 animations:^{
        self.contentView.center = center;
    }];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    if ([self.accountTextField isFirstResponder])
    {
        [self.passwordTextField becomeFirstResponder];
        if (self.accountTextField.text.length == 0) {
            [self showTip:EMLoginTipTypeNoAccount];
        }
    }else
    {
        [textField resignFirstResponder];
        [self handleLoginAction];
    }
    
    return YES;
}

@end
