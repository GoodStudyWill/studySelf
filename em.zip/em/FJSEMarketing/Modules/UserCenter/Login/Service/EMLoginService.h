//
//  EMLoginService.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/18.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSUInteger, EMLoginType) {
    EMLoginTypePassword = 1,    //用户密码登录
    EMLoginTypeGesture = 2,     //手势密码登录
};

@class EMLoginService;

FOUNDATION_EXPORT NSString * const kEMLoginServiceGetVersionFailedFlag;

@protocol EMLoginServiceDelegate <NSObject>

- (void)loginSuccess:(BOOL)gotoGesture;

- (void)loginFailed:(NSString *)flag message:(NSString *)msg;

@end

@interface EMLoginService : NSObject

@property (nonatomic, weak) id<EMLoginServiceDelegate> delegate;

+ (UINavigationController *)loginViewControllerPresent;

- (void)loginWithAccount:(NSString *)account password:(NSString *)password loginType:(EMLoginType)type;

- (void)getVersionConfigForce:(BOOL)force success:(void (^)())success failure:(void (^)())failure;

@end
