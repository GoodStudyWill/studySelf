//
//  EMLoginService.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/18.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMLoginService.h"
#import "EMLoginViewController.h"
#import "EMGesturePasswordViewController.h"
#import "EMUserManager.h"
#import "EMLoginApi.h"
#import "EMQueryTicketApi.h"
#import "EMUndoneScheduleCenter.h"
#import "EMScheduleModel.h"
#import "FJSAlertView.h"

NSString * const kEMLoginServiceGetVersionFailedFlag = @"kEMLoginServiceGetVersionFailedFlag";

@interface EMLoginService ()<FJSRequestDelegate>

@property (nonatomic, copy) NSString *account;
@property (nonatomic, copy) NSString *password;

@property (nonatomic, assign) EMLoginType loginType;
@property (nonatomic, assign) NSTimeInterval requestTime;

@end

@implementation EMLoginService

+ (UINavigationController *)loginViewControllerPresent
{
    EMUserManager *userManager = [EMUserManager sharedInstance];
    
    UIViewController *rootViewController = nil;
    NSString *isFirstLaunchAccountKey = [NSString stringWithFormat:@"isFirstLaunch_%@", userManager.userID];
    BOOL isFirstLaunchAccount = [[NSUserDefaults standardUserDefaults] boolForKey:isFirstLaunchAccountKey];
    if (!isFirstLaunchAccount) {
        //首次登录
        rootViewController = [[EMLoginViewController alloc] initWithNibName:@"EMLoginViewController" bundle:nil];
    } else {
        if ([userManager showLoginNextTime] || !userManager.isGestureLogin) {
            //如果上次输错5次密码或者没有设置手势密码登录，就展示登录界面
            rootViewController = [[EMLoginViewController alloc] initWithNibName:@"EMLoginViewController" bundle:nil];
        } else {
            rootViewController = [[EMGesturePasswordViewController alloc] initWithMode:EMGesterePasswordModeVerification];
        }
    }
    
    UINavigationController *loginNavigationController = [[UINavigationController alloc] initWithRootViewController:rootViewController];
    loginNavigationController.interactivePopGestureRecognizer.enabled = NO;
    
    return loginNavigationController;
}

#pragma mark - Api
- (void)loginWithAccount:(NSString *)account password:(NSString *)password  loginType:(EMLoginType)type
{
    _account = account;
    _password = password;
    _loginType = type;
    
    __weak EMLoginService *weakSelf = self;
    [self getVersionConfigForce:YES success:^{
        EMQueryTicketApi *ticketApi = [[EMQueryTicketApi alloc] init];
        ticketApi.delegate = weakSelf;
        [ticketApi start];
    } failure:^{
        if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(loginFailed:message:)]) {
            [weakSelf.delegate loginFailed:kEMLoginServiceGetVersionFailedFlag message:nil];
        }
    }];
}

#pragma mark - App force update
- (void)getVersionConfigForce:(BOOL)force success:(void (^)())success failure:(void (^)())failure
{
    if (!__APP_FORCE_UPDATE__) {
        if (success) {
            success();
        }
        return;
    }
    
    [EMHudManager showLoadingWithText:@"请稍后..."];
    
    NSString *versionURL = [EMAppConfig sharedInstance].versionURL;
    NSData *data = [[NSData alloc] initWithContentsOfURL:[NSURL URLWithString:versionURL]];
    
    if (!data) {
        [self getVersionError];
        if (failure) {
            failure();
        }
        return;
    }
    
    NSError *error;
    NSDictionary *responseDict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
    
    if (error) {
        FJSLog(@"Update error:%@", error);
        [self getVersionError];
        if (failure) {
            failure();
        }
        return;
    }
    
    NSString *urlStr = responseDict[@"iosUrl"];
    NSString *versionNo = responseDict[@"versionNo"];
    [self updateVersionWithURL:urlStr versionNo:versionNo force:force success:success failure:failure];
}

- (void)updateVersionWithURL:(NSString *)URL versionNo:(NSString *)versionNo force:(BOOL)force success:(void (^)())success failure:(void (^)())failure
{
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    NSString *currentVersion = [infoDictionary objectForKey:@"CFBundleShortVersionString"];
    NSDictionary *data = [[NSDictionary alloc] initWithContentsOfURL:[NSURL URLWithString:URL]];
    NSArray *arr = data[@"items"];
    if (arr.count < 1) {
        [self getVersionError];
        FJSLog(@"获取plist失败");
        [EMHudManager hideLoading];
        return;
    }
    
    NSString *newVersion = arr[0][@"metadata"][@"bundle-version"];
    if (!newVersion) {
        [self getVersionError];
        FJSLog(@"获取版本号失败");
        [EMHudManager hideLoading];
        return;
    }
    
    if ([newVersion compare:currentVersion options:NSNumericSearch] == NSOrderedDescending) {
        [self showUpdateWindowWithURL:URL force:force];

        if (failure) {
            failure();
        }
    } else {
        if (success) {
            success();
        }
    }
    
    [EMHudManager hideLoading];
}

- (void)showUpdateWindowWithURL:(NSString *)URL force:(BOOL)force
{
    if (!force) {
        [EMHudManager showText:@"App尚未更新到最新版本,请重启更新后再试"];
        return;
    }
    
    FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:@"提示" detail:@"检测到新版本，请更新新版本" buttonTitle:@"更新" completionBlock:^{
        NSString *ksUrl = @"itms-services://?action=download-manifest&url=";
        NSString *isFirstLaunchAccount = [NSString stringWithFormat:@"isFirstLaunch_%@", [EMUserManager sharedInstance].userID];
        [[NSUserDefaults standardUserDefaults] removeObjectForKey:isFirstLaunchAccount];
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",ksUrl, URL]]];
        exit(0);
    }];
    [alertView show];
}

- (void)getVersionError
{
    [EMHudManager hideLoading];
    __weak EMLoginService *weakSelf = self;
    FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeFailed title:nil detail:@"网络异常，请检查网络再试" buttonTitle:@"重试" completionBlock:^{
        [weakSelf getVersionConfigForce:YES success:nil failure:nil];
    }];
    [alertView show];
}

#pragma mark - Handle queryTicketApi
- (void)handleQueryTicketApi:(__kindof FJSBaseApi *)request
{
    NSDictionary *dataDic = request.responseJSONObject[@"data"];
    NSString *ticket = dataDic[@"ticket"];
    EMLoginApi *loginApi = [[EMLoginApi alloc] initWithAccount:self.account
                                                      password:self.password
                                                        ticket:ticket
                                                     loginType:self.loginType];
    loginApi.delegate = self;
    [loginApi start];
}

#pragma mark - Handle loginApi
- (void)handleLoginApi:(__kindof FJSBaseApi *)request
{
    NSString *flag = request.responseJSONObject[@"flag"];
    NSString *msg = request.responseJSONObject[@"msg"];
    if (![flag isEqualToString:@"11"] && ![flag isEqualToString:@"1"]) {
        //登录失败
        if (self.delegate && [self.delegate respondsToSelector:@selector(loginFailed:message:)]) {
            [self.delegate loginFailed:flag message:msg];
        }
        return;
    }
    
    //录入信息
    NSDictionary *dataDic = request.responseJSONObject[@"data"];
    EMUserManager *userManager = [EMUserManager sharedInstance];
    userManager.ticket = dataDic[@"ticket"] ?: @"";
    userManager.changeDevice = [dataDic[@"changeDevice"] isEqualToString:@"Y"] ? YES : NO;
    userManager.leader = dataDic[@"monthlyPlanApprovalLeader"] ?: @"";
    userManager.cityCode= dataDic[@"placeCode"] ?: @"";
    userManager.cityName = dataDic[@"placeName"] ?: @"";
    userManager.roleAuthorities = dataDic[@"roleAuthorities"] ?: @"";
    userManager.token = dataDic[@"token"] ?: @"";
    userManager.userGroup = dataDic[@"userGroup"] ?: @"";
    userManager.userID = dataDic[@"userId"] ?: @"";
    userManager.userName = dataDic[@"userName"] ?: @"";
    userManager.login = YES;
    
    //切换数据库
    [[FJSDatabaseManager sharedInstance] changeDBWithDirectoryName:userManager.userID];
    if (userManager.isChangeDevice) {
        //换机登录清空数据库，重新拉数据
        [EMScheduleModel clearTable];
    }
    
    [[EMUndoneScheduleCenter sharedInstance] loadData];
    
    BOOL gotoGesture = NO;
    if (_loginType == EMLoginTypePassword) {
        userManager.securityData = [self.password fjs_RSAEncrypt];
        [userManager saveAccountAndPassword];
        userManager.showLoginNextTime = NO;
        
        //判断是否首次登录
        NSString *isFirstLaunchAccountKey = [NSString stringWithFormat:@"isFirstLaunch_%@", userManager.userID];
        BOOL isFirstLaunchAccount = [[NSUserDefaults standardUserDefaults] boolForKey:isFirstLaunchAccountKey];
        if (!isFirstLaunchAccount) {
            //首次登录直接跳转设置手势密码
            [[NSUserDefaults standardUserDefaults] setBool:YES forKey:isFirstLaunchAccountKey];
            gotoGesture = YES;
            
        } else {
            [userManager loadGesture];
        }
    } else {
        userManager.gestureLogin = YES;
        [userManager loadGesture];
        [userManager saveContext];
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(loginSuccess:)]) {
        [self.delegate loginSuccess:gotoGesture];
    }
}

#pragma mark - FJSRequestDelegate
- (void)apiRequestDidSuccess:(__kindof FJSBaseApi *)request
{
    FJSLog(@"Api class => %@", request.class);
    FJSLog(@"response => %@", request.responseString);
    FJSLog(@"responseObject => %@", request.responseObject);
    if (request.class == [EMQueryTicketApi class]) {
        [self handleQueryTicketApi:request];
    } else if (request.class == [EMLoginApi class]) {
        [self handleLoginApi:request];
    }
}

- (void)apiRequestDidFail:(__kindof FJSBaseApi *)request
{
    FJSLog(@"Api class => %@", request.class);
    FJSLog(@"response => %@", request.responseString);
    FJSLog(@"responseObject => %@", request.responseObject);
}

@end
