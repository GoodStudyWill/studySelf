//
//  EMValidateViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMValidateViewController.h"
#import "EMValidateService.h"
#import "EMUserManager.h"
#import "EMGesturePasswordViewController.h"
#import "FJSAlertView.h"
#import "EMLoginViewController.h"
#import "UIBarButtonItem+FJSUIKit.h"

@interface EMValidateViewController ()<EMValidateServiceDelegate, UITextFieldDelegate>

@property (nonatomic, strong) UILabel *tipLabel;

@property (nonatomic, strong) EMValidateService *service;

@property (nonatomic, strong) UITextField *passwordTextField;

@property (nonatomic, strong) UIImageView *tipImageView;
@property (nonatomic, strong) UILabel *pwdTipLabel;

@property (nonatomic, strong) UIButton *validateButton;

@property (nonatomic, assign) BOOL showFailedAlert;

@end

@implementation EMValidateViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.trackName = @"验证UM账号";
    self.showFailedAlert = NO;
    [self initViews];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.title = @"我的账户";
    
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName : [UIColor whiteColor]};
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem showLeftBarButtonItemWithTitle:@"" orButtonImage:@"icon_back" target:self selector:@selector(clickLeftBarButton:)];
}

- (void)clickLeftBarButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)initViews
{
    [self.view addSubview:self.tipLabel];
    
    UIView *grayView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 5)];
    grayView.backgroundColor = UIColorFromHex(0xeeeeee);
    [self.view addSubview:grayView];
    
    UIImageView *accountIcon = [UIImageView new];
    accountIcon.image = [UIImage imageNamed:@"icon_UM"];
    [self.view addSubview:accountIcon];
    
    UIImageView *passwordIcon = [UIImageView new];
    passwordIcon.image = [UIImage imageNamed:@"icon_key"];
    [self.view addSubview:passwordIcon];
    
    UITextField *accountTextField = [UITextField new];
    accountTextField.font = [UIFont systemFontOfSize:15];
    accountTextField.text = [EMUserManager sharedInstance].userID;
    accountTextField.userInteractionEnabled = NO;
    [self.view addSubview:accountTextField];
    
    UIView *accountLine = [UIView new];
    accountLine.backgroundColor = UIColorFromHex(0xdddddd);
    [accountTextField addSubview:accountLine];
    
    self.passwordTextField = [UITextField new];
    self.passwordTextField.font = [UIFont systemFontOfSize:15];
    self.passwordTextField.placeholder = @"请输入登录密码";
    self.passwordTextField.borderStyle = UITextBorderStyleNone;
    self.passwordTextField.secureTextEntry = YES;
    self.passwordTextField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.passwordTextField.returnKeyType = UIReturnKeyDone;
//    [self.passwordTextField addTarget:self action:@selector(handleEditingChanged:) forControlEvents:UIControlEventEditingChanged];
    self.passwordTextField.delegate = self;
    [self.view addSubview:self.passwordTextField];
    
    UIView *passwordLine = [UIView new];
    passwordLine.backgroundColor = UIColorFromHex(0xdddddd);
    [self.passwordTextField addSubview:passwordLine];
    
    self.validateButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.validateButton.backgroundColor = UIColorFromHex(0x00a0ea);
    self.validateButton.layer.cornerRadius = 4;
    [self.validateButton setTitle:@"确认" forState:UIControlStateNormal];
    [self.validateButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.validateButton.titleLabel.font = [UIFont systemFontOfSize:18];
    [self.validateButton addTarget:self action:@selector(handleLoginAction) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.validateButton];
    
    self.tipImageView = [UIImageView new];
    self.tipImageView.image = [UIImage imageNamed:@"img_tip"];
    self.tipImageView.hidden = YES;
    [self.view addSubview:self.tipImageView];
    
    self.pwdTipLabel = [UILabel new];
    self.pwdTipLabel.text = @"请输入密码";
    self.pwdTipLabel.textColor = UIColorFromHex(0x333333);
    self.pwdTipLabel.font = [UIFont systemFontOfSize:12];
    self.pwdTipLabel.textAlignment = NSTextAlignmentCenter;
    [self.tipImageView addSubview:self.pwdTipLabel];
    
    [accountIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.tipLabel.mas_bottom).with.offset(80);
        make.left.equalTo(self.view.mas_left).with.offset(28);
        make.size.mas_equalTo(CGSizeMake(14, 14));
    }];
    
    [passwordIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(accountIcon.mas_bottom).with.offset(40);
        make.left.equalTo(self.view.mas_left).with.offset(28);
        make.size.mas_equalTo(CGSizeMake(14, 14));
    }];
    
    [accountTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(accountIcon.mas_centerY);
        make.left.equalTo(accountIcon.mas_right).with.offset(25);
        make.right.equalTo(self.view.mas_right).with.offset(-30);
    }];
    
    [accountLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(accountTextField.mas_bottom);
        make.left.equalTo(accountTextField);
        make.width.equalTo(accountTextField.mas_width);
        make.height.equalTo(@1);
    }];
    
    [self.passwordTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(passwordIcon.mas_centerY);
        make.left.equalTo(passwordIcon.mas_right).with.offset(25);
        make.right.equalTo(self.view.mas_right).with.offset(-30);
    }];
    
    [passwordLine mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.passwordTextField.mas_bottom);
        make.left.equalTo(self.passwordTextField);
        make.width.equalTo(self.passwordTextField.mas_width);
        make.height.equalTo(@1);
    }];
    
    [self.validateButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.passwordTextField.mas_bottom).with.offset(50);
        make.centerX.equalTo(self.view.mas_centerX);
        make.size.mas_equalTo(CGSizeMake(282, 44));
    }];

    [self.tipImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.passwordTextField.mas_left);
        make.size.mas_equalTo(CGSizeMake(115, 34));
        make.centerY.equalTo(self.passwordTextField.mas_top).with.offset(-18);
    }];
    
    [self.pwdTipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.tipImageView.mas_left);
        make.right.equalTo(self.tipImageView.mas_right);
        make.height.equalTo(@28);
        make.top.equalTo(self.tipImageView.mas_top);
    }];
}

#pragma mark - Action
- (void)handleLoginAction
{
    if (self.passwordTextField.text.length == 0) {
        self.tipImageView.hidden = NO;
    } else {
        [EMHudManager showLoadingWithText:nil inView:self.view];
        self.validateButton.enabled = NO;
        [self.view endEditing:YES];
        [self.service validateWithPassword:self.passwordTextField.text];
    }
}

#pragma mark - EMValidateServiceDelegate
- (void)validateSuccess:(EMValidateService *)service
{
    FJSLog(@"validateSuccess...");
    [EMHudManager hideLoadingForView:self.view];
    self.validateButton.enabled = YES;
    EMGesturePasswordViewController *gestureViewController = [[EMGesturePasswordViewController alloc] initWithMode:EMGesterePasswordModeSetting];
    [self.navigationController pushViewController:gestureViewController animated:YES];
}

- (void)validateFailed:(EMValidateService *)service
{
    FJSLog(@"validateFailed...");
    self.validateButton.enabled = YES;
    [EMHudManager hideLoadingForView:self.view];
}

- (void)validateFailed:(EMValidateService *)service flag:(NSString *)flag message:(NSString *)msg
{
    [EMHudManager hideLoadingForView:self.view];
    self.validateButton.enabled = YES;
    
    if ([flag isEqualToString:@"0"] || [flag isEqualToString:@"9"]) {
        if (self.showFailedAlert) {
            //保证登录失败弹框唯一性
            return;
        }
        
        self.showFailedAlert = YES;
        
        FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:@"提示" detail:msg buttonTitle:@"确定" completionBlock:^{
            if ([[EMUserManager sharedInstance] isGestureLogin]) {
                EMGesturePasswordViewController *gestureViewController = [[EMGesturePasswordViewController alloc] initWithMode:EMGesterePasswordModeVerification];;
                UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:gestureViewController];
                [self.navigationController presentViewController:navigationController animated:NO completion:^{
                }];
            } else {
                EMLoginViewController *loginViewController = [[EMLoginViewController alloc] initWithNibName:@"EMLoginViewController" bundle:nil];
                UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:loginViewController];
                [self.navigationController presentViewController:navigationController animated:NO completion:^{
                    [[EMUserManager sharedInstance] clearInformation];
                }];
            }
            
        }];
        [alertView show];
        return;
    }
    
    FJSAlertViewType type = FJSAlertViewTypeWarning;
    NSString *title = @"提示";
    NSString *detail = msg;
    if ([flag isEqualToString:@"0001"]) {
        //未开通系统权限
        title = @"验证失败";
        type = FJSAlertViewTypeFailed;
    }
    else if ([flag isEqualToString:@"0002"]) {
        //密码错误
        title = @"验证失败";
        type = FJSAlertViewTypeFailed;
    }
    else if ([flag isEqualToString:@"0003"]) {
        //UM账号被锁定
        type = FJSAlertViewTypeFailed;
        detail = @"UM账号已被锁定，请登陆公司内网在UM用户管理选择“忘记UM密码”";
    }
    
    __weak EMValidateViewController *weakSelf = self;
    FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:type title:title detail:detail buttonTitle:@"确定" completionBlock:^{
        if ([flag isEqualToString:@"0003"]) {
            EMLoginViewController *loginViewController = [[EMLoginViewController alloc] initWithNibName:@"EMLoginViewController" bundle:nil];
            UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:loginViewController];
            [weakSelf.navigationController presentViewController:navigationController animated:NO completion:^{
                [[EMUserManager sharedInstance] clearInformation];
            }];
        }
    }];
    [alertView show];
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    self.tipImageView.hidden = YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    if (self.passwordTextField.text.length == 0) {
        self.tipImageView.hidden = NO;
    } else {
        self.tipImageView.hidden = YES;
        [self.view endEditing:YES];
        [self handleLoginAction];
    }
    
    return YES;
}

#pragma mark - Getter & setter
- (UILabel *)tipLabel
{
    if (!_tipLabel) {
        _tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 96, SCREEN_WIDTH, 30)];
        _tipLabel.font = [UIFont systemFontOfSize:17];
        _tipLabel.textColor = UIColorFromHex(0x999999);
        _tipLabel.textAlignment = NSTextAlignmentCenter;
        _tipLabel.text = @"请验证UM账号";
    }
    return _tipLabel;
}

- (EMValidateService *)service
{
    if (!_service) {
        _service = [[EMValidateService alloc] init];
        _service.delegate = self;
    }
    return _service;
}


@end
