//
//  EMMyAccountViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/22.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSSystemInfo/FJSSystemInfo.h>
#import "EMMyAccountViewController.h"
#import "EMUserManager.h"
#import "EMLoginViewController.h"
#import "EMValidateViewController.h"
#import "FJSAlertView.h"
#import "UILabel+FJSVerticalAlign.h"
#import "NSString+FJSExtension.h"
#import "EMExitLoginApi.h"

@interface EMMyAccountViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, copy) NSArray *titleArray;

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *backButton;
@property (weak, nonatomic) IBOutlet UILabel *userNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *userIDLabel;
@property (weak, nonatomic) IBOutlet UILabel *groupLabel;
@property (weak, nonatomic) IBOutlet UILabel *groupNameLabel;

@property (nonatomic, strong) UIButton *switchGestureButton;

@end

@implementation EMMyAccountViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.trackName = @"我的账户";
    [self initUI];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    self.navigationItem.backBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStylePlain target:nil action:nil];
    BOOL isGestureLogin = [EMUserManager sharedInstance].isGestureLogin;
    NSString *imageName = isGestureLogin ? @"btn_open" : @"btn_close";
    [_switchGestureButton setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
}

- (void)dealloc
{
    FJSLog(@"");
}

#pragma mark - UI
- (void)initUI
{
    self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    self.tableView.backgroundColor = UIColorFromHex(0xeeeeee);
    self.tableView.separatorColor = UIColorFromHex(0xdddddd);
    self.tableView.separatorInset = UIEdgeInsetsMake(0,0, 0, 0);
    
    EMUserManager *userManager = [EMUserManager sharedInstance];
    self.userNameLabel.text = userManager.userName;
    self.userIDLabel.text = userManager.userID;
    
    CGFloat width = SCREEN_WIDTH-self.userIDLabel.x-30;
    NSString *groupText = userManager.userGroup;
    CGFloat height = [groupText fjs_heightForFont:[UIFont systemFontOfSize:15] width:width]+8;
    
    UILabel *teamLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.userIDLabel.x, self.groupNameLabel.y, width, height)];
    teamLabel.text = groupText;
    teamLabel.textColor = [UIColor whiteColor];
    teamLabel.font = [UIFont systemFontOfSize:15];
    teamLabel.numberOfLines = 0;
    [self.view addSubview:teamLabel];
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 1) {
        //退出登录
//        [self dismissViewControllerAnimated:YES completion:^{
//            EMLoginViewController *loginViewController = [[EMLoginViewController alloc] initWithNibName:@"EMLoginViewController" bundle:nil];
//            UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:loginViewController];
//            BOOL isLoginVC = [[[UIApplication sharedApplication] keyWindow].rootViewController isKindOfClass:[EMLoginViewController class]];
//            if (!isLoginVC) {
//                [[[UIApplication sharedApplication] keyWindow].rootViewController presentViewController:navigationController animated:YES completion:^{
//                    [[EMUserManager sharedInstance] clearInformation];
//                }];
//            }
//        }];
        
        EMExitLoginApi *exitLoginApi = [EMExitLoginApi new];
        [exitLoginApi start];
        
        EMLoginViewController *loginViewController = [[EMLoginViewController alloc] initWithNibName:@"EMLoginViewController" bundle:nil];
        UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:loginViewController];
        BOOL isLoginVC = [[[UIApplication sharedApplication] keyWindow].rootViewController isKindOfClass:[EMLoginViewController class]];
        if (!isLoginVC) {
            [self presentViewController:navigationController animated:NO completion:^{
                [[EMUserManager sharedInstance] clearInformation];
            }];
        }
    } else if (indexPath.section == 0 && indexPath.row == 1) {
        //跳转更改手势密码
        EMValidateViewController *validateViewController = [[EMValidateViewController alloc] initWithNibName:@"EMValidateViewController" bundle:nil];
        [self.navigationController pushViewController:validateViewController animated:YES];
        
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0) {
        return 3;
    } else {
        return 1;
    }
    
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"Cell"];
    }
    
    
    cell.selectionStyle = UITableViewCellSelectionStyleGray;
    
    
    if (indexPath.section == 0) {
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(30, 0, 150, 60)];
        titleLabel.font = [UIFont systemFontOfSize:15];
        titleLabel.textColor = UIColorFromHex(0x666666);
        titleLabel.text = self.titleArray[indexPath.row];
        [cell addSubview:titleLabel];
        
        if (indexPath.row == 0) {
            [cell addSubview:self.switchGestureButton];
            
            [self.switchGestureButton mas_makeConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(cell.mas_right).with.offset(-20);
                make.centerY.equalTo(cell.mas_centerY);
                make.size.mas_equalTo(CGSizeMake(55, 24));
            }];
        } else if (indexPath.row == 1) {
            UIImageView *imageView = [UIImageView new];
            imageView.image = [UIImage imageNamed:@"icon_back_right"];
            [cell addSubview:imageView];
            
            [imageView mas_makeConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(cell.mas_right).with.offset(-20);
                make.centerY.equalTo(cell.mas_centerY);
                make.size.mas_equalTo(CGSizeMake(8, 14));
            }];
            
        } else if (indexPath.row == 2) {
            UILabel *versionLabel = [UILabel new];
            versionLabel.textAlignment = NSTextAlignmentRight;
            versionLabel.font = [UIFont systemFontOfSize:15];
            versionLabel.textColor = UIColorFromHex(0x666666);
            versionLabel.text = [NSString stringWithFormat:@"V%@", [FJSSystemInfo appVersion]];
            [cell addSubview:versionLabel];
            
            [versionLabel mas_makeConstraints:^(MASConstraintMaker *make) {
                make.right.equalTo(cell.mas_right).with.offset(-20);
                make.width.equalTo(@150);
                make.centerY.equalTo(cell.mas_centerY);
            }];
        }
        
    } else {
        UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 60)];
        titleLabel.font = [UIFont systemFontOfSize:15];
        titleLabel.textColor = UIColorFromHex(0x333333);
        titleLabel.textAlignment = NSTextAlignmentCenter;
        titleLabel.text = @"退出登录";
        [cell addSubview:titleLabel];
    }
    
    return cell;
}

#pragma mark - Action
- (void)handleGestureSwitch:(UIButton *)sender
{
    NSString *gestureCode = [[EMUserManager sharedInstance] gestureCode];
    if (!(gestureCode && gestureCode.length > 4)) {
        //如果没有手势密码
        FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:@"提示" detail:@"您还没设置手势密码，请设置!" buttonTitle:@"确定" completionBlock:nil];
        [alertView show];
        return;
    }
    
    BOOL isGestureLogin = [EMUserManager sharedInstance].isGestureLogin;
    [[EMUserManager sharedInstance] setGestureLogin:!isGestureLogin];
    
    NSString *imageName = !isGestureLogin ? @"btn_open" : @"btn_close";
    [_switchGestureButton setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
}

- (IBAction)handleBackAction:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Getter & setter
- (NSArray *)titleArray
{
    if (!_titleArray) {
        _titleArray = @[@"手势密码开/关", @"重置手势密码", @"版本信息"];
    }
    return _titleArray;
}

- (UIButton *)switchGestureButton
{
    if (!_switchGestureButton) {
        NSString *imageName = [EMUserManager sharedInstance].isGestureLogin ? @"btn_open" : @"btn_close";
        
        _switchGestureButton = [UIButton new];
        [_switchGestureButton addTarget:self action:@selector(handleGestureSwitch:) forControlEvents:UIControlEventTouchUpInside];
        [_switchGestureButton setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    }
    return _switchGestureButton;
}


@end
