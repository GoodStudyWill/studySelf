//
//  EMValidateService.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@class EMValidateService;

@protocol EMValidateServiceDelegate <NSObject>

- (void)validateSuccess:(EMValidateService *)service;

- (void)validateFailed:(EMValidateService *)service;

- (void)validateFailed:(EMValidateService *)service flag:(NSString *)flag message:(NSString *)msg;

@end

@interface EMValidateService : NSObject

@property (nonatomic, weak) id<EMValidateServiceDelegate> delegate;

- (void)validateWithPassword:(NSString *)password;

@end
