//
//  EMVerifyUserApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>

@interface EMVerifyUserApi : FJSApi

- (instancetype)initWithPassword:(NSString *)password ticket:(NSString *)ticket;

@end
