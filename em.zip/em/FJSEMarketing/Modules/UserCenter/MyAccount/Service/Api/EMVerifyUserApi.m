//
//  EMVerifyUserApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMVerifyUserApi.h"
#import "NSString+FJSSecurity.h"

@interface EMVerifyUserApi ()

@property (nonatomic, copy) NSString *password;
@property (nonatomic, copy) NSString *ticket;

@end

@implementation EMVerifyUserApi

- (instancetype)initWithPassword:(NSString *)password ticket:(NSString *)ticket
{
    self = [super init];
    if (self) {
        _password = password;
        _ticket = ticket;
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"user/verifyUser.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{@"ticket" : [_ticket ?: @"" fjs_RSAEncrypt],
                            @"password" : [_password ?: @"" fjs_RSAEncrypt],
                            };
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
