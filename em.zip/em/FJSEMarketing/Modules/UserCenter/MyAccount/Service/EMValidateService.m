//
//  EMValidateService.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/25.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMValidateService.h"
#import "EMQueryTicketApi.h"
#import "EMVerifyUserApi.h"
#import "FJSAlertView.h"

@interface EMValidateService ()<FJSRequestDelegate>

@property (nonatomic, copy) NSString *password;

@property (nonatomic, assign) BOOL showFailedAlert;

@end

@implementation EMValidateService

- (instancetype)init
{
    self = [super init];
    if (self) {
        _showFailedAlert = NO;
    }
    return self;
}

- (void)validateWithPassword:(NSString *)password
{
    _password = password;
    
    EMQueryTicketApi *queryTicketApi = [[EMQueryTicketApi alloc] init];
    queryTicketApi.delegate = self;
    [queryTicketApi start];
}

#pragma mark - Handle queryTicketApi
- (void)handleQueryTicketData:(NSDictionary *)dataDic
{
    NSString *ticket = dataDic[@"ticket"];
    EMVerifyUserApi *verifyUserApi = [[EMVerifyUserApi alloc] initWithPassword:self.password ticket:ticket];
    verifyUserApi.delegate = self;
    [verifyUserApi start];
}

- (void)handleVerifyUserData:(NSDictionary *)dataDic
{
    NSString *result = dataDic[@"result"];
    if ([result isEqualToString:@"Y"]) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(validateSuccess:)]) {
            [self.delegate validateSuccess:self];
        }
    } else {
        if (self.delegate && [self.delegate respondsToSelector:@selector(validateFailed:)]) {
            [self.delegate validateFailed:self];
        }
    }
}


#pragma mark - FJSRequestDelegate
- (void)apiRequestDidSuccess:(__kindof FJSBaseApi *)request
{
    FJSLog(@"Api class => %@", request.class);
    FJSLog(@"response => %@", request.responseString);
    FJSLog(@"responseObject => %@", request.responseObject);
    NSString *flag = request.responseJSONObject[@"flag"];
    NSString *msg = request.responseJSONObject[@"msg"];
    if (![flag isEqualToString:@"11"] && ![flag isEqualToString:@"1"]) {
        //验证失败
        if (self.delegate && [self.delegate respondsToSelector:@selector(validateFailed:flag:message:)]) {
            [self.delegate validateFailed:self flag:flag message:msg];
        }
        return;
    }
    
    NSDictionary *dataDic = request.responseJSONObject[@"data"];
    if (request.class == [EMQueryTicketApi class]) {
        [self handleQueryTicketData:dataDic];
    } else if (request.class == [EMVerifyUserApi class]) {
        [self handleVerifyUserData:dataDic];
    }
}

- (void)apiRequestDidFail:(__kindof FJSBaseApi *)request
{
    FJSLog(@"Api class => %@", request.class);
    FJSLog(@"response => %@", request.responseString);
    FJSLog(@"responseObject => %@", request.responseObject);
    if (_showFailedAlert) {
        //保证登录失败弹框唯一性
        return;
    }
    
    _showFailedAlert = YES;
    FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:@"提示" detail:@"网络连接异常" buttonTitle:@"确定" completionBlock:^{
        _showFailedAlert = NO;
    }];
    [alertView show];
}

@end
