//
//  EMUserManager.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/17.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>
#import <FJSKeyChainWrapper/FJSKeyChainWrapper.h>
#import "EMUserManager.h"
#import "NSString+FJSBase64.h"
#import "EMScheduleModel.h"
#import "EMNotificationCenter.h"
#import "EMUndoneScheduleCenter.h"

static NSString * const kKeyChainUserAccount = @"keychain.userId";
static NSString * const kKeyChainUserName = @"keychain.userName";
static NSString * const kKeyChainUserPassword = @"keyChain.securityData";

static NSString * const kKeyChainGestureCode = @"userDefault.isGestureLogin";
static NSString * const kKeyChainIsGestureLogin = @"userDefault.gestureCode";

static NSString * const kUserDefaultToken = @"userDefault.token";
static NSString * const kUserDefaultShowLoginNextTime = @"userDefault.showLoginNextTime";

@interface EMUserManager ()

@property (nonatomic, assign) BOOL isClear;

@end

@implementation EMUserManager

+ (EMUserManager *)sharedInstance
{
    static EMUserManager *manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[EMUserManager alloc] init];
    });
    return manager;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        _isClear = NO;
        _login = NO;
        [self loadData];
        [self setNotification];
    }
    return self;
}

#pragma mark - Load
- (void)loadData
{
    _userID = [FJSKeyChainWrapper loadKeyChainWithServiceID:kKeyChainUserAccount];
    _userName = [FJSKeyChainWrapper loadKeyChainWithServiceID:kKeyChainUserName];
    _securityData = [FJSKeyChainWrapper loadKeyChainWithServiceID:kKeyChainUserPassword];
    [self loadGesture];
    
    _token = [[[NSUserDefaults standardUserDefaults] objectForKey:kUserDefaultToken] fjs_base64DecodedString];
}

- (void)loadGesture
{
//    _gestureCode = [[NSUserDefaults standardUserDefaults] objectForKey:[NSString stringWithFormat:@"%@_%@", kUserDefaultGestureCode, _userID]];
//    _gestureLogin = [[NSUserDefaults standardUserDefaults] boolForKey:[NSString stringWithFormat:@"%@_%@", kUserDefaultIsGestureLogin, _userID]];
    _gestureCode = [FJSKeyChainWrapper loadKeyChainWithServiceID:[NSString stringWithFormat:@"%@_%@", kKeyChainGestureCode, self.userID]];
    _gestureLogin = [[FJSKeyChainWrapper loadKeyChainWithServiceID:[NSString stringWithFormat:@"%@_%@", kKeyChainIsGestureLogin, self.userID]] boolValue];
}

- (void)setNotification
{
    //要进入后台和要被关闭的时候，保存数据
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveContext) name:UIApplicationWillResignActiveNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(saveContext) name:UIApplicationWillTerminateNotification object:nil];
}

#pragma mark - Save
- (void)saveContext
{
    if (_isClear) {
        return;
    }
    [self saveAccountAndPassword];
    [self saveGesturePassword];
}

- (void)saveAccountAndPassword
{
    [FJSKeyChainWrapper saveObject:self.userID toServiceID:kKeyChainUserAccount];
    [FJSKeyChainWrapper saveObject:self.userName toServiceID:kKeyChainUserName];
    [FJSKeyChainWrapper saveObject:self.securityData toServiceID:kKeyChainUserPassword];
}

- (void)saveGesturePassword
{
//    [[NSUserDefaults standardUserDefaults] setObject:self.gestureCode forKey:[NSString stringWithFormat:@"%@_%@", kUserDefaultGestureCode, self.userID]];
//    [[NSUserDefaults standardUserDefaults] setBool:self.gestureLogin forKey:[NSString stringWithFormat:@"%@_%@", kUserDefaultIsGestureLogin, self.userID]];
    [FJSKeyChainWrapper saveObject:self.gestureCode toServiceID:[NSString stringWithFormat:@"%@_%@", kKeyChainGestureCode, self.userID]];
    [FJSKeyChainWrapper saveObject:@(self.gestureLogin) toServiceID:[NSString stringWithFormat:@"%@_%@", kKeyChainIsGestureLogin, self.userID]];
}

#pragma mark - Clear
- (void)clearInformation
{
    _isClear = YES;
    _ticket = nil;
    _cityCode = nil;
    _cityName = nil;
    _token = nil;
    _userGroup = nil;
    _roleAuthorities = nil;
    _leader = nil;
    _changeDevice = nil;
    _gestureCode = nil;
    _login = NO;
    
    [EMScheduleModel clearTable];
    [[EMNotificationCenter sharedInstance] clearNotifications];
    [[EMUndoneScheduleCenter sharedInstance] clear];
    
    //下次打开APP弹登录页面
    self.showLoginNextTime = YES;
}

- (void)clearGesture
{
    [FJSKeyChainWrapper deleteKeychainByServiceID:[NSString stringWithFormat:@"%@_%@", kKeyChainGestureCode, self.userID]];
    [FJSKeyChainWrapper saveObject:@(NO) toServiceID:[NSString stringWithFormat:@"%@_%@", kKeyChainIsGestureLogin, self.userID]];
}

#pragma mark - Setter & getter
- (void)setToken:(NSString *)token
{
    if (!token || token.length == 0) {
        return;
    }
    _token = token;
    
    //更改公共参数token
    [[FJSNetworkConfig sharedConfig].commonRequestArgument setObject:_token forKey:@"token"];
    [[NSUserDefaults standardUserDefaults] setObject:[_token fjs_base64EncodedString] forKey:kUserDefaultToken];
}

- (void)setGestureCode:(NSString *)gestureCode
{
//    if (!gestureCode || gestureCode.length < 5) {
//        return;
//    }
    
    _gestureCode = gestureCode;
    [self saveGesturePassword];
}

- (void)setGestureLogin:(BOOL)gestureLogin
{
    _gestureLogin = gestureLogin;
    [self saveGesturePassword];
}

- (void)setShowLoginNextTime:(BOOL)isShow
{
    [[NSUserDefaults standardUserDefaults] setBool:isShow forKey:kUserDefaultShowLoginNextTime];
}

- (BOOL)showLoginNextTime
{
    return [[NSUserDefaults standardUserDefaults] boolForKey:kUserDefaultShowLoginNextTime];
}

@end
