//
//  EMUserManager.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/17.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EMUserManager : NSObject

//防重校验码
@property (nonatomic, copy) NSString *ticket;

//城市编码
@property (nonatomic, copy) NSString *cityCode;

//城市名
@property (nonatomic, copy) NSString *cityName;

//登录态
@property (nonatomic, copy) NSString *token;

//用户所属团队
@property (nonatomic, copy) NSString *userGroup;

//用户UM账号
@property (nonatomic, copy) NSString *userID;

//用户姓名
@property (nonatomic, copy) NSString *userName;

//用户角色
@property (nonatomic, copy) NSString *roleAuthorities;

//审核领导
@property (nonatomic, copy) NSString *leader;

//RSA加密后的密码
@property (nonatomic, copy) NSString *securityData;

//手势密码
@property (nonatomic, copy) NSString *gestureCode;

//是否使用手势密码
@property (nonatomic, assign, getter=isGestureLogin) BOOL gestureLogin;

//是否更换手机
@property (nonatomic, assign, getter=isChangeDevice) BOOL changeDevice;

//登录态
@property (nonatomic, assign, getter=isLogin) BOOL login;

/**
 单例

 @return 单例
 */
+ (EMUserManager *)sharedInstance;

/**
 清除信息
 */
- (void)clearInformation;

/**
 载入手势密码
 */
- (void)loadGesture;

/**
 保存所有密码
 */
- (void)saveContext;

/**
 保存账号密码
 */
- (void)saveAccountAndPassword;

/**
 保存手势密码
 */
- (void)saveGesturePassword;

/**
 清除手势密码
 */
- (void)clearGesture;

/**
 设置下次登录是否显示UM账号密码登录界面

 @param isShow 是否显示
 */
- (void)setShowLoginNextTime:(BOOL)isShow;

/**
 下次登录是否显示UM账号密码登录界面

 @return 下次登录是否显示UM账号密码登录界面
 */
- (BOOL)showLoginNextTime;


@end
