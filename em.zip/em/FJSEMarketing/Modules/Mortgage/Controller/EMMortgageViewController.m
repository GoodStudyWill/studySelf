//
//  EMMortgageViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/10/1.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMMortgageViewController.h"
#import "EMMortgageService.h"
#import "FJSMortgageHandler.h"
#import "EMAppConfig.h"
#import "WKWebView+FJSJavaScript.h"

@interface EMMortgageViewController ()<EMMortgageServiceDelegate, FJSMortgageHandlerDelegate>

@property (nonatomic, strong) WKWebView *webView;

@property (nonatomic, strong) EMMortgageService *service;

@property (nonatomic, assign, getter=isLoadFailed) BOOL loadFailed;

@end

@implementation EMMortgageViewController

@dynamic webView;

- (void)viewDidLoad {
    self.moduleName = @"Mortgage";
    self.loadFailed = NO;
    [super viewDidLoad];
    [EMHudManager hideLoadingForView:self.webView];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.webView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - self.tabBarController.tabBar.height - 64);
    [self setupNavigationBar];
    [EMHudManager hideLoadingForView:self.webView];
}

- (void)setupNavigationBar
{
    self.navigationController.navigationBar.barTintColor = UIColorFromHex(0x00a0ea);
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
}

- (void)login
{
    [self.service getURL];
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    [EMHudManager hideLoadingForView:self.webView];
    [EMHudManager showText:@"加载失败"];
    self.loadFailed = YES;
}

- (void)service:(EMMortgageService *)service handleMtgLoginSuccessWithURL:(NSString *)url
{
    FJSLog(@"url=>%@", url);
    [EMHudManager hideLoadingForView:self.webView];
    if (self.urlString && self.urlString.length > 0) {
        [self.webView stopLoading];
        self.urlString = url;
        if (!self.isLoadFailed) {
            [self.webView fjs_evaluateRefreshURL:self.urlString];
        } else {
            self.loadFailed = NO;
            [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.urlString]]];
            [self.webView reload];
        }
    } else {
        self.urlString = url;
        self.loadFailed = NO;
        [self loadPage];
    }
}

- (EMMortgageService *)service
{
    if (!_service) {
        _service = [EMMortgageService new];
        _service.delegate = self;
    }
    return _service;
}

@end
