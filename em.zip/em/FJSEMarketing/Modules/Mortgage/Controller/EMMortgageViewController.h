//
//  EMMortgageViewController.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/10/1.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSWebViewController.h"

@interface EMMortgageViewController : FJSWebViewController

- (void)login;

@end
