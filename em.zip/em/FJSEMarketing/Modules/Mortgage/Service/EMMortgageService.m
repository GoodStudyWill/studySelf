//
//  EMMortgageService.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/10/1.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMMortgageService.h"
#import "EMTokenOvertimeApi.h"
#import "MTGGetTicketApi.h"
#import "MTGLoginApi.h"
#import "EMUserManager.h"
#import "NSString+FJSSecurity.h"

@interface EMMortgageService ()<FJSRequestDelegate>

@end

@implementation EMMortgageService

- (void)getURL
{
    //先续一下token，调一下接口不需要任何返回
    EMTokenOvertimeApi *tokenOvertimeApi = [EMTokenOvertimeApi new];
    [tokenOvertimeApi start];
    
    MTGGetTicketApi *getTicketApi = [MTGGetTicketApi new];
    getTicketApi.delegate = self;
    [getTicketApi start];
}

- (void)handleGetTicketData:(NSDictionary *)data
{
    //拼接ticket+userID，并且用RSA加密
    NSString *ticket = data[@"ticket"];
    NSString *userID = [NSString stringWithFormat:@"%@%@", ticket, [EMUserManager sharedInstance].userID];
    NSString *encryptUserID = [userID fjs_RSAEncrypt];
    
    MTGLoginApi *loginApi = [[MTGLoginApi alloc] initWithUserID:encryptUserID];
    loginApi.delegate = self;
    [loginApi start];
}

- (void)handleLoginData:(NSDictionary *)data
{
    NSString *h5URL = data[@"h5Url"];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleMtgLoginSuccessWithURL:)]) {
        [self.delegate service:self handleMtgLoginSuccessWithURL:h5URL];
    }
}

- (void)handleApiRequestDidSuccess:(__kindof FJSBaseApi *)request
{
    FJSLog(@"Api class => %@", request.class);
    FJSLog(@"response => %@", request.responseString);
    FJSLog(@"responseObject => %@", request.responseObject);
    NSDictionary *data = request.responseObject[@"data"];
    if (request.class == [MTGGetTicketApi class]) {
        [self handleGetTicketData:data];
    }
    else if (request.class == [MTGLoginApi class]) {
        [self handleLoginData:data];
    }
}

- (void)handleApiRequestDidFail:(__kindof FJSBaseApi *)request
{
    FJSLog(@"Api class => %@", request.class);
    FJSLog(@"response => %@", request.responseString);
}

@end
