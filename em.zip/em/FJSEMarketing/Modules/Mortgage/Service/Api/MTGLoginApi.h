//
//  MTGLoginApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/10/1.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>

@interface MTGLoginApi : FJSApi

- (instancetype)initWithUserID:(NSString *)userID;

@end
