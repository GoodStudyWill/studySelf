//
//  MTGGetTicketApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/10/1.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "MTGGetTicketApi.h"
#import "EMAppConfig.h"

@implementation MTGGetTicketApi

- (NSString *)requestUrl
{
    return [NSString stringWithFormat:@"%@user/getTicket.do", [EMAppConfig sharedInstance].mtgURL];
}

- (BOOL)encryptRequest
{
    return NO;
}

@end
