//
//  MTGLoginApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/10/1.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "MTGLoginApi.h"
#import "EMAppConfig.h"
#import "NSString+FJSExtension.h"

@interface MTGLoginApi ()

@property (nonatomic, copy) NSString *userID;

@end

@implementation MTGLoginApi

- (instancetype)initWithUserID:(NSString *)userID
{
    self = [super init];
    if (self) {
        _userID = userID;
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    NSString *url = [NSString stringWithFormat:@"%@opmgt/login.do?userId=%@", [EMAppConfig sharedInstance].mtgURL, self.userID];
    NSString *encodeUrl = [url stringByReplacingOccurrencesOfString:@"+" withString:@"%2b"];
    
    return encodeUrl;
}

- (BOOL)encryptRequest
{
    return NO;
}

@end
