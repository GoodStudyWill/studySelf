//
//  EMTokenOvertimeApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/10/1.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMTokenOvertimeApi.h"

@implementation EMTokenOvertimeApi

- (NSString *)requestUrl
{
    return @"mortgage/updTokenTimeEfficient.do";
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
