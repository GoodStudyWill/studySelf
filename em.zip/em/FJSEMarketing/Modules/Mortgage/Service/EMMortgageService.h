//
//  EMMortgageService.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/10/1.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMBaseService.h"

@class EMMortgageService;

@protocol EMMortgageServiceDelegate <NSObject>

- (void)service:(EMMortgageService *)service handleMtgLoginSuccessWithURL:(NSString *)url;

@end

@interface EMMortgageService : EMBaseService

@property (nonatomic, weak) id<EMMortgageServiceDelegate> delegate;

- (void)getURL;

@end
