//
//  EMHomePageViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMHomePageViewController.h"
#import "EMHomePageViewController+Extension.h"
#import "EMHomePageService.h"
#import "EMMessageViewController.h"
#import "FJSWebViewController.h"
#import "EMScheduleService.h"
#import "NSDate+FJSExtension.h"
#import "EMScheduleMainViewController.h"
#import "EMNotificationCenter.h"
#import "EMScheduleModel.h"

@interface EMHomePageViewController ()<EMHomePageServiceDelegate, EMHomePageViewDelegate, EMScheduleServiceDelegate>

@property (nonatomic, strong) EMHomePageService *service;
@property (nonatomic, strong) EMScheduleService *scheduleService;

@property (nonatomic, assign) NSInteger refreshTag;

@end

@implementation EMHomePageViewController

#pragma mark - Life cycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.trackName = @"首页";
    
    self.refreshTag = 0;
    [self.view addSubview:self.homePageView];
    
    [[EMNotificationCenter sharedInstance] showPushNotificationAlertViewWithMessage];
    [self addNotification];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self setupNavigationBar];
    
    //每次进入刷新数据
    [self.service loadData];
    [self getSchedules];
}

- (void)getSchedules
{
    //获取每日日程
    [self.scheduleService getScheduleFor:[NSDate fjs_todayInFormat:@"yyyy-MM-dd"]];
    
    //获取日程占比数据
    [self.scheduleService getSchedulesRatioOfThisMonth];
    
}

- (void)homePageViewDidRefreshed
{
    if (self.refreshTag == 1) {
        [self.homePageView didRefreshed];
        self.refreshTag = 0;
    }
}

#pragma mark - Observer
- (void)addNotification
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(scheduleDidRecieveNewComment:) name:EMNotificationCenterNewScheduleComment object:nil];
    });
}

- (void)scheduleDidRecieveNewComment:(NSNotification *)noti
{
    NSDictionary *scheduleInfo = noti.userInfo;
    NSString *scheduleDate = scheduleInfo[EMNotificationCenterKeyScheduleDate];
    
    NSString *todayDate = [NSDate fjs_todayInFormat:@"yyyy-MM-dd"];
    if ([todayDate isEqualToString:scheduleDate]) {
        NSString *scheduleID = scheduleInfo[EMNotificationCenterKeyScheduleID];
        NSString *isRead = scheduleInfo[EMNotificationCenterKeyScheduleCommentRead];
        [self.homePageView todayScheduleViewRefreshSchedule:scheduleID isRead:isRead];
    }
}

#pragma mark - EMHomePageServiceDelegate
- (void)service:(EMHomePageService *)service updateCommissionData:(NSString *)commission
{
    [self.homePageView didRefreshed];
    [self.homePageView updateCommissionView:commission];
}

- (void)service:(EMHomePageService *)service updatPerformanceData:(NSDictionary *)performanceData
{
    [self.homePageView didRefreshed];
    [self.homePageView updatePerformaceView:performanceData];
}

- (void)service:(EMHomePageService *)service updateNewMessagesData:(NSArray *)messageData count:(NSInteger)count
{
    [self.homePageView didRefreshed];
    [self.homePageView updateMessageView:messageData count:count];
}

#pragma mark - EMHomePageViewDelegate
- (void)handleTapMessageViewAction
{
    EMMessageViewController *messageViewController = [[EMMessageViewController alloc] init];
    messageViewController.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:messageViewController animated:YES];
}

- (void)handlePerformaceViewSelectIndex:(NSInteger)index
{
    NSString *urlStr = nil;
    switch (index) {
        case 0:
        {
            urlStr = kEMHtmlURLHomeAchieve;
        }
            break;
            
        case 1:
        {
            urlStr = kEMHtmlURLHomeApply;
        }
            break;
            
        case 2:
        {
            urlStr = kEMHtmlURLHomeOrder;
        }
            break;
            
        default:
            break;
    }
    
    FJSWebViewController *webViewController = [[FJSWebViewController alloc] initWithUrlString:urlStr];
    [webViewController showLeftBarButtonItemWithImage:@"icon_back"];
    webViewController.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:webViewController animated:YES];
}

- (void)handleNewTodayScheduleAction
{
    FJSWebViewController *webViewController = [[FJSWebViewController alloc] initWithUrlString:kEMHtmlURLSchedule];
    [webViewController showLeftBarButtonItemWithImage:@"icon_back"];
    webViewController.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:webViewController animated:YES];
}

- (void)handleSelectTodayScheduleActionWithUrl:(NSString *)urlStr
{
    FJSWebViewController *webViewController = [[FJSWebViewController alloc] initWithUrlString:urlStr];
    [webViewController showLeftBarButtonItemWithImage:@"icon_back"];
    webViewController.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:webViewController animated:YES];
}

- (void)handleGotoTodayScheduleAction
{
    UINavigationController *naviViewController = self.tabBarController.childViewControllers[1];
    EMScheduleMainViewController *mainViewController = nil;
    for (UIViewController *viewController in naviViewController.childViewControllers) {
        if ([viewController isKindOfClass:[EMScheduleMainViewController class]]) {
            mainViewController = (EMScheduleMainViewController *)viewController;
            [mainViewController changeViewIntoScheduleDay];
            mainViewController.flag = kChangViewIntoScheduleDayFlag;
            break;
        }
    }
    [self.tabBarController setSelectedIndex:1];
}

- (void)handleRefresh
{
    self.refreshTag = 1;
    [self.service loadData];
}

#pragma mark - EMScheduleServiceDelegate
- (void)service:(EMScheduleService *)service handleOneDaySchedules:(NSArray *)schedules
{
    [self.homePageView didRefreshed];
    [self.homePageView updateTodaySchedulesView:schedules];
}

- (void)service:(EMScheduleService *)service handleMonthScheduleCountOfExploit:(NSInteger)exploitCount maintain:(NSInteger)maintainCount other:(NSInteger)otherCount
{
    [self.homePageView didRefreshed];
    
    [self.homePageView updateRatioViewCountWithExploit:exploitCount maintain:maintainCount other:otherCount];
}

#pragma mark - Getter
- (EMHomePageView *)homePageView
{
    if (!_homePageView) {
        CGRect frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - self.tabBarController.tabBar.height - 64);
        _homePageView = [[EMHomePageView alloc] initWithFrame:frame];
        _homePageView.delegate = self;
    }
    return _homePageView;
}

- (EMHomePageService *)service
{
    if (!_service) {
        _service = [[EMHomePageService alloc] init];
        _service.delegate = self;
    }
    return _service;
}

- (EMScheduleService *)scheduleService
{
    if (!_scheduleService) {
        _scheduleService = [EMScheduleService new];
        _scheduleService.delegate = self;
    }
    return _scheduleService;
}


@end
