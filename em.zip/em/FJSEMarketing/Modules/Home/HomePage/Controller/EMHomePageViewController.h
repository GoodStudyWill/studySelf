//
//  EMHomePageViewController.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EMHomePageView.h"

@interface EMHomePageViewController : UIViewController

@property (nonatomic, strong) EMHomePageView *homePageView;

@end
