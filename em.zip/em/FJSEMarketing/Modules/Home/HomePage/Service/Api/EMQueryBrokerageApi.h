//
//  EMQueryBrokerageApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/19.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>

@interface EMQueryBrokerageApi : FJSApi

@end
