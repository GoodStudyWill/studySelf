//
//  EMEffectOrderApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/19.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMEffectOrderApi.h"

@implementation EMEffectOrderApi

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"home/effectOrder.do";
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
