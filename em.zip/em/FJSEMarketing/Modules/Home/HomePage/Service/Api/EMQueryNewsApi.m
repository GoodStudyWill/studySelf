//
//  EMQueryNewsApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/19.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMQueryNewsApi.h"

@implementation EMQueryNewsApi

- (NSString *)requestUrl
{
    return @"home/queryNews.do";
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
