//
//  EMQueryBrokerageApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/19.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMQueryBrokerageApi.h"

@implementation EMQueryBrokerageApi

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"home/queryBrokerage.do";
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
