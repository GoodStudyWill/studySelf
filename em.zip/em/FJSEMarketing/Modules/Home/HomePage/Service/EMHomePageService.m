//
//  EMHomePageService.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/19.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMHomePageService.h"
#import "EMQueryBrokerageApi.h"
#import "EMEffectOrderApi.h"
#import "EMQueryNewsApi.h"
#import "EMMessageModel.h"

@interface EMHomePageService ()<FJSRequestDelegate>

@end

@implementation EMHomePageService

- (void)loadData
{
    EMQueryBrokerageApi *queryBrokerageApi = [EMQueryBrokerageApi new];
    queryBrokerageApi.delegate = self;
    [queryBrokerageApi start];
    
    EMEffectOrderApi *effectOrderApi = [EMEffectOrderApi new];
    effectOrderApi.delegate = self;
    [effectOrderApi start];
    
    EMQueryNewsApi *queryNewsApi = [EMQueryNewsApi new];
    queryNewsApi.delegate = self;
    [queryNewsApi start];
}

#pragma mark - Handle response data
- (void)handleQueryBrokerageData:(NSDictionary *)data
{
    NSString *commission = [NSString stringWithFormat:@"%.f", [data[@"brokerage"] floatValue]];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:updateCommissionData:)]) {
        [self.delegate service:self updateCommissionData:commission];
    }
}

- (void)handleEffectOrderData:(NSDictionary *)data
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:updatPerformanceData:)]) {
        [self.delegate service:self updatPerformanceData:data];
    }
}

- (void)handleQueryNewsData:(NSDictionary *)data
{
    NSInteger count = [data[@"newestCount"] integerValue];
    NSArray *rotateMsgs = data[@"rotateMsgs"];
    NSMutableArray *msgData = [self messagesFromData:rotateMsgs];
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:updateNewMessagesData:count:)]) {
        [self.delegate service:self updateNewMessagesData:msgData count:count];
    }
    
}

#pragma mark - TransformData
- (NSMutableArray *)messagesFromData:(NSArray *)data
{
    NSMutableArray *messages = [NSMutableArray arrayWithCapacity:data.count];
    for (NSDictionary *msgDic in data) {
        EMMessageModel *model = [[EMMessageModel alloc] init];
        model.content = msgDic[@"content"];
        model.messageTitle = msgDic[@"messageTitle"];
        model.messageType = msgDic[@"messageType"];
        model.primaryId = msgDic[@"primaryId"];
        model.publishTime = msgDic[@"publishTime"];
        
        [messages addObject:model];
    }
    return messages;
}


#pragma mark - FJSRequestDelegate
- (void)handleApiRequestDidSuccess:(__kindof FJSBaseApi *)request
{
    NSDictionary *data = request.responseObject[@"data"];
    if (request.class == [EMQueryBrokerageApi class]) {
        [self handleQueryBrokerageData:data];
    } else if (request.class == [EMEffectOrderApi class]) {
        [self handleEffectOrderData:data];
    } else if (request.class == [EMQueryNewsApi class]) {
        [self handleQueryNewsData:data];
    }
}

- (void)handleApiRequestDidFail:(__kindof FJSBaseApi *)request
{
    
}

@end
