//
//  EMHomePageService.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/19.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMBaseService.h"

@class EMHomePageService;

@protocol EMHomePageServiceDelegate <NSObject>

/**
 更新佣金

 @param service service
 @param commission 佣金
 */
- (void)service:(EMHomePageService *)service updateCommissionData:(NSString *)commission;

/**
 更新排名和件数信息

 @param service service
 @param performanceData 排名和件数信息
 */
- (void)service:(EMHomePageService *)service updatPerformanceData:(NSDictionary *)performanceData;

/**
 更新新消息和新消息数量

 @param service service
 @param messageData 新消息
 @param count 新消息数量
 */
- (void)service:(EMHomePageService *)service updateNewMessagesData:(NSArray *)messageData count:(NSInteger)count;

@end

@interface EMHomePageService : EMBaseService

@property (nonatomic, weak) id<EMHomePageServiceDelegate> delegate;

- (void)loadData;

@end
