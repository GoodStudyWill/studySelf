//
//  EMTodayScheduleView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/20.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol EMTodayScheduleViewDelegate <NSObject>

- (void)handleGotoDayViewAction;

@end

typedef void(^EMTodayScheduleViewNewScheduleBlock)(void);

typedef void(^EMTodayScheduleViewSelectScheduleBlock)(NSString *url);

@interface EMTodayScheduleView : UIView

@property (nonatomic, weak) id<EMTodayScheduleViewDelegate> delegate;

@property (nonatomic, copy) EMTodayScheduleViewNewScheduleBlock newBlock;

@property (nonatomic, copy) EMTodayScheduleViewSelectScheduleBlock selectBlock;

- (void)updateTodaySchedules:(NSArray *)schedules;

- (void)refreshSchedule:(NSString *)scheduleID isRead:(NSString *)isRead;

@end
