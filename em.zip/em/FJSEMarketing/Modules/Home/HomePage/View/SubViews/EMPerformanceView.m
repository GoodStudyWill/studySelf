//
//  EMPerformanceView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/12.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMPerformanceView.h"
#import <PNChart/PNCircleChart.h>

static NSString * const kPerformaceLoanRank     = @"loanRank";      //放款排名
static NSString * const kPerformaceLoanCount    = @"loanCount";     //放款件数
static NSString * const kPerformaceApplyCount   = @"applyCount";    //申请件数
static NSString * const kPerformaceOpenCount    = @"openCount";     //开单件数

static NSString * const kPerformaceLoanRatio    = @"loanRatio";     //放款比例
static NSString * const kPerformaceOpenRatio    = @"openRatio";     //开单比例

static NSString * const kPerformaceLightFlag    = @"lightFlag";     //排名是否高亮

@interface EMPerformanceView ()

@property (nonatomic, strong) UIImageView *rankImageView;

@property (nonatomic, strong) UILabel *rankLabel;
@property (nonatomic, strong) UILabel *loanLabel;
@property (nonatomic, strong) UILabel *applyLabel;
@property (nonatomic, strong) UILabel *billLabel;

@property (nonatomic, strong) PNCircleChart *loanChart;
@property (nonatomic, strong) PNCircleChart *billChart;

@end

@implementation EMPerformanceView

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.userInteractionEnabled = YES;
        [self initViews];
    }
    return self;
}

#pragma mark - UI
- (void)initViews
{
    self.rankImageView = [UIImageView new];
    self.rankImageView.image = [UIImage imageNamed:@"icon_trophy"];
    [self addSubview:self.rankImageView];
    
    UIButton *applyButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [applyButton setImage:[UIImage imageNamed:@"icon_apply"] forState:UIControlStateNormal];
    [applyButton addTarget:self action:@selector(handleClickApplyAction:) forControlEvents:UIControlEventTouchUpInside];
    applyButton.adjustsImageWhenHighlighted = NO;
    [self addSubview:applyButton];
    
    
    self.rankLabel = [self getNumberLabel];
    [self addSubview:self.rankLabel];
    
    self.loanLabel = [self getNumberLabel];
    [self addSubview:self.loanLabel];
    
    self.applyLabel = [self getNumberLabel];
    [self addSubview:self.applyLabel];
    
    self.billLabel = [self getNumberLabel];
    [self addSubview:self.billLabel];
    
    NSArray *labelArray = @[self.rankLabel, self.loanLabel, self.applyLabel, self.billLabel];
    [labelArray mas_distributeViewsAlongAxis:MASAxisTypeHorizontal withFixedSpacing:60 leadSpacing:40 tailSpacing:40];
    
    [@[self.loanLabel, self.applyLabel, self.billLabel] mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.mas_centerY).with.offset(-7);
        make.width.equalTo(@60);
    }];
    
    [self.rankLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.mas_centerY).with.offset(-10);
        make.width.equalTo(@60);
    }];
    
    UILabel *loanDescLabel = [self getDescLabelWithText:@"放款"];
    [self addSubview:loanDescLabel];
    
    UILabel *applyDescLabel = [self getDescLabelWithText:@"申请"];
    [self addSubview:applyDescLabel];
    
    UILabel *billDescLabel = [self getDescLabelWithText:@"开单"];
    [self addSubview:billDescLabel];
    
    self.loanChart = [[PNCircleChart alloc] initWithFrame:CGRectMake(0, 0, 60, 60) total:@1.0f current:@0 clockwise:YES shadow:YES shadowColor:UIColorFromHex(0xdddddd) displayCountingLabel:NO];
    self.loanChart.strokeColor = UIColorFromHex(0xffd303);
    [self addSubview:self.loanChart];
    [self.loanChart strokeChart];
    
    UITapGestureRecognizer *loanTapGR = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapLoanAction:)];
    loanTapGR.numberOfTapsRequired = 1;
    [self.loanChart addGestureRecognizer:loanTapGR];
    
    self.billChart = [[PNCircleChart alloc] initWithFrame:CGRectMake(0, 0, 60, 60) total:@1.0f current:@0 clockwise:YES shadow:YES shadowColor:UIColorFromHex(0xdddddd) displayCountingLabel:NO];
    self.billChart.strokeColor = UIColorFromHex(0xfb4224);
    [self addSubview:self.billChart];
    [self.billChart strokeChart];
    
    UITapGestureRecognizer *billTapGR = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapBillAction:)];
    billTapGR.numberOfTapsRequired = 1;
    [self.billChart addGestureRecognizer:billTapGR];
    
    [self.rankImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.rankLabel.mas_centerX);
        make.centerY.equalTo(self);
        make.size.mas_equalTo(CGSizeMake(57, 55));
    }];
    
    [applyButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.applyLabel.mas_centerX);
        make.centerY.equalTo(self);
        make.size.mas_equalTo(CGSizeMake(43, 57));
    }];
    
    [loanDescLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.loanLabel.mas_centerX);
        make.centerY.equalTo(self.mas_centerY).with.offset(13);
        make.width.equalTo(@60);
    }];
    
    [applyDescLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(applyButton.mas_centerX);
        make.centerY.equalTo(self.mas_centerY).with.offset(13);
        make.width.equalTo(@60);
    }];
    
    [billDescLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.billLabel.mas_centerX);
        make.centerY.equalTo(self.mas_centerY).with.offset(13);
        make.width.equalTo(@60);
    }];
    
    [self.loanChart mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.loanLabel.mas_centerX);
        make.centerY.equalTo(self.mas_centerY);
        make.size.mas_equalTo(CGSizeMake(60, 60));
    }];
    
    [self.billChart mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self.billLabel.mas_centerX);
        make.centerY.equalTo(self.mas_centerY);
        make.size.mas_equalTo(CGSizeMake(60, 60));
    }];
    
    [self layoutIfNeeded];
    
    self.rankLabel.y -= 10;
    
    FJSLog(@"%@", NSStringFromCGRect(applyButton.frame));
}

#pragma mark - Factory
- (UILabel *)getNumberLabel
{
    UILabel *label = [UILabel new];
    label.font = [UIFont boldSystemFontOfSize:17];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = UIColorFromHex(0xf92211);
    label.text = @"0";
    return label;
}

- (UILabel *)getDescLabelWithText:(NSString *)text
{
    UILabel *label = [UILabel new];
    label.text = text;
    label.font = [UIFont systemFontOfSize:10];
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = UIColorFromHex(0x999999);
    return label;
}

#pragma mark - Action
- (void)handleTapLoanAction:(UITapGestureRecognizer *)gr
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(performanceViewSelectIndex:)]) {
        [self.delegate performanceViewSelectIndex:0];
    }
}

- (void)handleClickApplyAction:(UIButton *)gr
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(performanceViewSelectIndex:)]) {
        [self.delegate performanceViewSelectIndex:1];
    }
}

- (void)handleTapBillAction:(UITapGestureRecognizer *)gr
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(performanceViewSelectIndex:)]) {
        [self.delegate performanceViewSelectIndex:2];
    }
}

#pragma mark - UpdateUI
- (void)updatePerformanceData:(NSDictionary *)data
{
    NSInteger rankNum = [data[kPerformaceLoanRank] integerValue];
    self.rankLabel.text = rankNum > 0 ? [NSString stringWithFormat:@"%ld", [data[kPerformaceLoanRank] integerValue]] : nil;
    self.loanLabel.text = [NSString stringWithFormat:@"%ld", [data[kPerformaceLoanCount] integerValue]];
    self.applyLabel.text = [NSString stringWithFormat:@"%ld", [data[kPerformaceApplyCount] integerValue]];
    self.billLabel.text = [NSString stringWithFormat:@"%ld", [data[kPerformaceOpenCount] integerValue]];
    
    [self.loanChart updateChartByCurrent:data[kPerformaceLoanRatio] byTotal:@1.0f];
    [self.billChart updateChartByCurrent:data[kPerformaceOpenRatio] byTotal:@1.0f];
    
    [self setRankHighlight:[data[kPerformaceLightFlag] integerValue]];
}

- (void)setRankHighlight:(NSInteger)highlight
{
    //1高亮，2不高亮
    NSString *imageName = highlight == 1 ? @"icon_trophy" : @"icon_trophy_gray";
    self.rankImageView.image = [UIImage imageNamed:imageName];
    UIColor *rankTextColor = highlight == 1 ? UIColorFromHex(0xf92211) : UIColorFromHex(0xffffff);
    self.rankLabel.textColor = rankTextColor;
}

@end
