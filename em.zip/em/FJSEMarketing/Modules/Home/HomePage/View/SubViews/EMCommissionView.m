//
//  EMCommissionView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/12.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMCommissionView.h"

@interface EMCommissionView ()

@property (nonatomic, strong) UILabel *commissionLabel;

@end

@implementation EMCommissionView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self initViews];
    }
    return self;
}

- (void)initViews
{
    UIImageView *commissionImageView = [UIImageView new];
    commissionImageView.image = [UIImage imageNamed:@"img_income"];
    [self addSubview:commissionImageView];
    
    self.commissionLabel = [UILabel new];
    self.commissionLabel.text = [NSString stringWithFormat:@"¥ %d", 0];
    self.commissionLabel.textAlignment = NSTextAlignmentCenter;
    self.commissionLabel.textColor = UIColorFromHex(0xf94944);
    self.commissionLabel.font = [UIFont systemFontOfSize:16];
    [self addSubview:self.commissionLabel];
    
    [commissionImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).with.offset(34);
        make.width.equalTo(@58);
        make.centerY.equalTo(self);
    }];
    
    [self.commissionLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(commissionImageView.mas_right);
        make.right.equalTo(self).with.offset(-20);
        make.centerY.equalTo(self);
    }];
}

- (void)updateCommission:(NSString *)commission
{
    self.commissionLabel.text = [NSString stringWithFormat:@"¥ %@", commission];
    
}

@end
