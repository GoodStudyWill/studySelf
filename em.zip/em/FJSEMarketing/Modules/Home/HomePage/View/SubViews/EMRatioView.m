//
//  EMRatioView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/11.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMRatioView.h"

@interface EMRatioView ()

@property (nonatomic, assign) CGFloat loanRatio;
@property (nonatomic, assign) CGFloat applyRatio;
@property (nonatomic, assign) CGFloat billRatio;

@property (nonatomic, strong) CAShapeLayer *wholeLineLayer;

@property (nonatomic, strong) UIView *baseView;
@property (nonatomic, assign) CGFloat totalCount;

@end

@implementation EMRatioView

- (instancetype)initWithLoanRatio:(CGFloat)loanRatio applyRatio:(CGFloat)applyRatio
{
    self = [super init];
    if (self) {
        _loanRatio = loanRatio;
        _applyRatio = applyRatio;
        _billRatio = 1 - loanRatio - applyRatio;
        _totalCount = 0;
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    [self drawLineLayers];
}

- (void)drawLineLayers
{
    if (_baseView) {
        [_baseView removeFromSuperview];
        _baseView = nil;
    }
    
    _baseView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
    [self addSubview:_baseView];
    
    CGPoint fromPoint = CGPointZero;
    CGPoint toPoint = CGPointZero;
    
    if (self.totalCount > 0) {
        fromPoint = CGPointMake(12, self.height / 2);
        toPoint = CGPointMake(self.width - 32, self.height / 2);
    } else {
        fromPoint = CGPointMake(17, self.height / 2);
        toPoint = CGPointMake(self.width - 17, self.height / 2);
    }
    
    CGFloat lineWidth = self.width - 28;
    
    //底线
    UIBezierPath *linePath = [UIBezierPath bezierPath];
    [linePath moveToPoint:fromPoint];
    [linePath addLineToPoint:toPoint];
    
    CAShapeLayer *baseLineLayer = [CAShapeLayer layer];
    baseLineLayer.bounds = CGRectMake(0, 0, lineWidth, 4);
    baseLineLayer.position = CGPointMake(0, 0);
    baseLineLayer.anchorPoint = CGPointMake(0, 0);
    baseLineLayer.lineWidth = 4.0;
    baseLineLayer.lineCap = @"round";
    baseLineLayer.strokeColor = UIColorFromHex(0xdddddd).CGColor;
    
    baseLineLayer.path = linePath.CGPath;
    baseLineLayer.fillColor = nil;
    
    //  添加到图层上
    [_baseView.layer addSublayer:baseLineLayer];
    
    //没有数据
    if (self.totalCount == 0) {
        //比例tag
        CGPoint tagCenter = fromPoint;
        tagCenter.y -= 20;
        UIImageView *tagImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 45, 30)];
        tagImageView.image = [UIImage imageNamed:@"img_gray"];
        tagImageView.center = tagCenter;
        [_baseView addSubview:tagImageView];
        
        tagCenter.y -= 4;
        UILabel *tagLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 45, 16)];
        tagLabel.center = tagCenter;
        tagLabel.text = @"0%";
        tagLabel.textAlignment = NSTextAlignmentCenter;
        tagLabel.textColor = UIColorFromHex(0x333333);
        tagLabel.font = [UIFont systemFontOfSize:12];
        [_baseView addSubview:tagLabel];
        
        return;
    }
    
//    CGFloat toPointX = toPoint.x;
    CGFloat toPointX = 0;
    NSArray *ratioArray = @[@(_billRatio), @(_applyRatio), @(_loanRatio)];
    NSArray *colorArray = @[UIColorFromHex(0x00aeff), UIColorFromHex(0xffd303), UIColorFromHex(0xfb4224)];
    NSArray *imageNameArray = @[@"img_other", @"img_maintain", @"img_break"];
    NSArray *fontColorArray = @[UIColorFromHex(0x00bae9), UIColorFromHex(0xf37800), UIColorFromHex(0xfb3c1d)];
    CGFloat totalRatio = 1;
    for (NSInteger i = 0; i < 3; i++) {
        CGFloat ratio = [ratioArray[i] floatValue];
        if (ratio == 0) {
            continue;
        }
        
        //画线
        UIColor *color = colorArray[i];
        UIBezierPath *linePath = [UIBezierPath bezierPath];
        [linePath moveToPoint:fromPoint];
        [linePath addLineToPoint:toPoint];
        
        CAShapeLayer *lineLayer = [CAShapeLayer layer];
        lineLayer.bounds = CGRectMake(0, 0, lineWidth, 4);
        lineLayer.position = CGPointMake(0, 0);
        lineLayer.anchorPoint = CGPointMake(0, 0);
        lineLayer.lineWidth = 4.0;
        lineLayer.lineCap = @"round";
        lineLayer.strokeColor = color.CGColor;
        
        lineLayer.path = linePath.CGPath;
        lineLayer.fillColor = nil;
        [baseLineLayer addSublayer:lineLayer];
        
        //画点
        UIBezierPath *circlePath = [UIBezierPath bezierPathWithArcCenter:toPoint radius:10/2 startAngle:0 endAngle:M_PI*2 clockwise:YES];
        CAShapeLayer *circleLayer = [CAShapeLayer layer];
        circleLayer.frame = CGRectMake(0, 0, 10, 10);
        circleLayer.strokeColor = color.CGColor;
        circleLayer.fillColor = [UIColor whiteColor].CGColor;
        circleLayer.lineCap =kCALineCapSquare;
        circleLayer.path = circlePath.CGPath;
        circleLayer.lineWidth =4.0f;
        [baseLineLayer addSublayer:circleLayer];
        
        //比例tag
        CGPoint tagCenter = toPoint;
        tagCenter.y -= i == 1 ? -20 : 20;
        UIImageView *tagImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 45, 30)];
        tagImageView.image = [UIImage imageNamed:imageNameArray[i]];
        tagImageView.center = tagCenter;
        [_baseView addSubview:tagImageView];
        
        tagCenter.y -= i == 1 ? -3 : 4;
        CGFloat ratioNum = ratio * 100;
        UILabel *tagLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 45, 16)];
        tagLabel.center = tagCenter;
        tagLabel.text = [NSString stringWithFormat:@"%.f%%", ratioNum];
        tagLabel.textAlignment = NSTextAlignmentCenter;
        tagLabel.textColor = fontColorArray[i];
        tagLabel.font = [UIFont systemFontOfSize:12];
        [_baseView addSubview:tagLabel];
        
        totalRatio -= ratio;
        toPointX = totalRatio * lineWidth;
        toPoint.x = toPointX;
    }
    
    
}

- (void)updateScheduleCountWithExploit:(NSInteger)exploit maintain:(NSInteger)maintain other:(NSInteger)other
{
    self.totalCount = exploit + maintain + other;

    _billRatio = other / self.totalCount;
    _applyRatio = maintain / self.totalCount;
    _loanRatio = 1 - _billRatio - _applyRatio;
    
    [self drawLineLayers];
}

@end
