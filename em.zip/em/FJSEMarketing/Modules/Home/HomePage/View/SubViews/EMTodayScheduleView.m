//
//  EMTodayScheduleView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/20.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMTodayScheduleView.h"
#import "NSDate+FJSExtension.h"
#import "EMScheduleDailyTableViewCell.h"
#import "EMScheduleModel.h"

@interface EMTodayScheduleView ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UIView *noScheduleView;

@property (nonatomic, strong) NSArray *schedules;

@property (nonatomic, copy) NSString *lastTimeStr;

@end

@implementation EMTodayScheduleView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self initViews];
        [self initNoScheduleView];
    }
    return self;
}

- (void)initViews
{
    //今日日程
    UIImageView *titleImageView = [UIImageView new];
    titleImageView.image = [UIImage imageNamed:@"img_tag_today"];
    [self addSubview:titleImageView];
    
    UILabel *titleLabel = [UILabel new];
    titleLabel.text = @"今日日程";
    titleLabel.textColor = [UIColor whiteColor];
    titleLabel.font = [UIFont systemFontOfSize:13];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:titleLabel];
    
    //今日日期
    NSString *dateOfToday = [NSDate fjs_todayInFormat:@"MM/dd"];
    NSString *weekDayOfToday = [NSDate fjs_weekDayOfToday];
    
    UILabel *dateLabel = [UILabel new];
    dateLabel.text = [NSString stringWithFormat:@"%@  %@", dateOfToday, weekDayOfToday];
    dateLabel.textAlignment = NSTextAlignmentCenter;
    dateLabel.font = [UIFont systemFontOfSize:13];
    dateLabel.textColor = UIColorFromHex(0x666666);
    [self addSubview:dateLabel];
    
    //小箭头
    UIButton *arrowButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [arrowButton setImage:[UIImage imageNamed:@"icon_arrow_r1"] forState:UIControlStateNormal];
    arrowButton.imageView.contentMode = UIViewContentModeRight;
    [arrowButton addTarget:self action:@selector(handleClickGotoDayViewAction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:arrowButton];
    
    
    [titleImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).with.offset(-5);
        make.top.equalTo(self).with.offset(10);
        make.size.mas_equalTo(CGSizeMake(83, 27));
    }];
    
    [titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(titleImageView.mas_centerX);
        make.centerY.equalTo(titleImageView.mas_centerY).with.offset(-2);
        make.width.equalTo(titleImageView.mas_width);
    }];
    
    [dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(arrowButton.mas_left).with.offset(-5);
        make.centerY.equalTo(titleLabel.mas_centerY);
        make.width.equalTo(@90);
    }];
    
    [arrowButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self).with.offset(-15);
        make.centerY.equalTo(titleLabel.mas_centerY);
        make.width.equalTo(@13);
    }];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(titleLabel.mas_bottom).with.offset(10);
        make.left.equalTo(self);
        make.right.equalTo(self);
        make.bottom.equalTo(self);
    }];
    
}

- (void)initNoScheduleView
{
    self.noScheduleView = [UIView new];
    [self addSubview:self.noScheduleView];
    
    UILabel *nineLabel = [UILabel new];
    nineLabel.text = @"09:00";
    nineLabel.textAlignment = NSTextAlignmentCenter;
    nineLabel.font = [UIFont systemFontOfSize:14];
    nineLabel.textColor = UIColorFromHex(0x333333);
    [self.noScheduleView addSubview:nineLabel];
    
    UILabel *twelveLabel = [UILabel new];
    twelveLabel.text = @"12:00";
    twelveLabel.textAlignment = NSTextAlignmentCenter;
    twelveLabel.font = [UIFont systemFontOfSize:14];
    twelveLabel.textColor = UIColorFromHex(0x333333);
    [self.noScheduleView addSubview:twelveLabel];
    
    UILabel *sixteenLabel = [UILabel new];
    sixteenLabel.text = @"18:00";
    sixteenLabel.textAlignment = NSTextAlignmentCenter;
    sixteenLabel.font = [UIFont systemFontOfSize:14];
    sixteenLabel.textColor = UIColorFromHex(0x333333);
    [self.noScheduleView addSubview:sixteenLabel];
    
    UIImageView *timeLineView = [UIImageView new];
    timeLineView.image = [UIImage imageNamed:@"home_time_dot"];
    [self.noScheduleView addSubview:timeLineView];
    
    UIImageView *tipImageView = [UIImageView new];
    tipImageView.image = [UIImage imageNamed:@"img_home"];
    [self.noScheduleView addSubview:tipImageView];
    
    UILabel *tipLabel = [UILabel new];
    tipLabel.text = @"今天还没有任何安排哦!";
    tipLabel.textAlignment = NSTextAlignmentRight;
    tipLabel.font = [UIFont systemFontOfSize:14];
    tipLabel.textColor = UIColorFromHex(0x666666);
    [self.noScheduleView addSubview:tipLabel];
    
    UIButton *newScheduleButton = [UIButton new];
    [newScheduleButton setBackgroundColor:UIColorFromHex(0x00a0ea)];
    [newScheduleButton setTitle:@"+ 新建工作计划" forState:UIControlStateNormal];
    [newScheduleButton addTarget:self action:@selector(handleNewSchedule:) forControlEvents:UIControlEventTouchUpInside];
    newScheduleButton.titleLabel.font = [UIFont systemFontOfSize:16];
    newScheduleButton.layer.cornerRadius = 2;
    [self.noScheduleView addSubview:newScheduleButton];
    
    [self.noScheduleView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).with.offset(40);
        make.left.right.bottom.equalTo(self);
    }];
    
    [nineLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(@0);
        make.width.equalTo(@70);
        make.centerY.equalTo(self.noScheduleView.mas_top).with.offset(25);
    }];
    
    [twelveLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(@0);
        make.width.equalTo(@70);
        make.centerY.equalTo(self.noScheduleView.mas_top).with.offset(145);
    }];
    
    [sixteenLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(@0);
        make.width.equalTo(@70);
        make.centerY.equalTo(self.noScheduleView.mas_top).with.offset(265);
    }];
    
    [timeLineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.noScheduleView).with.offset(20);
        make.left.equalTo(@75);
        make.size.mas_equalTo(CGSizeMake(11, 251));
    }];
    
    [tipImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.noScheduleView).with.offset(25);
        make.right.equalTo(self).with.offset(-60);
        make.size.mas_equalTo(CGSizeMake(166, 130));
    }];
    
    [tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(tipImageView.mas_bottom).with.offset(5);
        make.width.equalTo(tipImageView.mas_width);
        make.height.equalTo(@20);
        make.left.equalTo(tipImageView.mas_left);
    }];
    
    [newScheduleButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(tipLabel.mas_bottom).with.offset(5);
        make.size.mas_equalTo(CGSizeMake(142, 34));
        make.right.equalTo(self.noScheduleView).with.offset(-67);
    }];
}

#pragma mark - Action
- (void)handleNewSchedule:(id)sender
{
    if (self.newBlock) {
        self.newBlock();
    }
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    EMScheduleModel *schedule = self.schedules[indexPath.row];
    if (!schedule.agencyCompanyName || schedule.agencyCompanyName.length == 0) {
        return SCREEN_WIDTH > 375 ? 48 : 46;
    }
    
    BOOL isSameSchedule = NO;
    if (indexPath.row > 0) {
        EMScheduleModel *preSchedule = self.schedules[indexPath.row-1];
        isSameSchedule = [preSchedule.startTime isEqualToString:schedule.startTime];
        if (!isSameSchedule && indexPath.row+1 < self.schedules.count) {
            EMScheduleModel *nextSchedule = self.schedules[indexPath.row + 1];
            isSameSchedule = [nextSchedule.startTime isEqualToString:schedule.startTime];
        }
    }
    return isSameSchedule ? 38 : 48;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    EMScheduleDailyTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    EMScheduleModel *schedule = cell.model;
    if (schedule.scheduleId && schedule.scheduleId.length > 0) {
        NSString *urlStr = [NSString stringWithFormat:@"%@%@", kEMHtmlURLSchedule, schedule.scheduleId];
        if (self.selectBlock) {
            self.selectBlock(urlStr);
        }
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.schedules.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"EMScheduleDailyTableViewCell";
    
    EMScheduleDailyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"EMScheduleDailyTableViewCell" owner:nil options:nil] lastObject];
    }
    
    cell.model = self.schedules[indexPath.row];
    BOOL isShowTime = YES;
    if (indexPath.row > 0) {
        //前面有相同时间就不显示时间
        EMScheduleModel *preModel = self.schedules[indexPath.row-1];
        isShowTime = ![preModel.startTime isEqualToString:cell.model.startTime];
        cell.showTime = isShowTime;
        
        if ([cell.model.startTime isEqualToString:self.lastTimeStr]) {
            //最后一个时间点
            EMScheduleDailyLineType lineType = isShowTime ? EMScheduleDailyLineTypeLastHasTime : EMScheduleDailyLineTypeLastNoTime;
            
            [cell setLine:lineType];
        }
    } else {
        cell.showTime = YES;
        [cell setLine:EMScheduleDailyLineTypeFirst];
    }
    
    return cell;
}

#pragma mark - Update
- (void)updateTodaySchedules:(NSArray *)schedules
{
    if (schedules && schedules.count > 0) {
        self.noScheduleView.hidden = YES;
        self.tableView.hidden = NO;
        
        NSMutableArray *scheduleArray = [NSMutableArray array];
        
        EMScheduleModel *firstSchedule = schedules.firstObject;
        NSString *today = firstSchedule.date;
        NSDate *nineDate = [NSDate fjs_dateFromString:[NSString stringWithFormat:@"%@ 09:00:00", today]];
        NSDate *twelveDate = [NSDate fjs_dateFromString:[NSString stringWithFormat:@"%@ 12:00:00", today]];
        NSDate *sixteenDate = [NSDate fjs_dateFromString:[NSString stringWithFormat:@"%@ 18:00:00", today]];
        
        NSMutableArray *beforeNineArr = [NSMutableArray array];
        NSMutableArray *betweenNineTwelveArr = [NSMutableArray array];
        NSMutableArray *betweenTwelveSixteenArr = [NSMutableArray array];
        NSMutableArray *afterSixteenArr = [NSMutableArray array];
        NSMutableArray *nineArr = [NSMutableArray array];
        NSMutableArray *twelveArr = [NSMutableArray array];
        NSMutableArray *sixteenArr = [NSMutableArray array];
        
        for (EMScheduleModel *schedule in schedules) {
            NSString *dateStr = [NSString stringWithFormat:@"%@ %@", schedule.date, schedule.startTime];
            NSDate *date = [NSDate fjs_dateFromString:dateStr inFormat:@"yyyy-MM-dd HH:mm"];
            NSComparisonResult nineResult = [date compare:nineDate];
            NSComparisonResult twelveResult = [date compare:twelveDate];
            NSComparisonResult sixteenResult = [date compare:sixteenDate];
            
            if (nineResult == NSOrderedAscending) {
                [beforeNineArr addObject:schedule];
            }
            else if (nineResult == NSOrderedSame) {
                [nineArr addObject:schedule];
            }
            else if (nineResult == NSOrderedDescending && twelveResult == NSOrderedAscending) {
                [betweenNineTwelveArr addObject:schedule];
            }
            else if (twelveResult == NSOrderedSame) {
                [twelveArr addObject:schedule];
            }
            else if (twelveResult == NSOrderedDescending && sixteenResult == NSOrderedAscending) {
                [betweenTwelveSixteenArr addObject:schedule];
            }
            else if (sixteenResult == NSOrderedSame) {
                [sixteenArr addObject:schedule];
            }
            else if (sixteenResult == NSOrderedDescending) {
                [afterSixteenArr addObject:schedule];
            }
        }
        
        if (nineArr.count == 0) {
            EMScheduleModel *nineSchedule = [EMScheduleModel new];
            nineSchedule.startTime = @"09:00";
            [nineArr addObject:nineSchedule];
        }
        
        if (twelveArr.count == 0) {
            EMScheduleModel *twelveSchedule = [EMScheduleModel new];
            twelveSchedule.startTime = @"12:00";
            [twelveArr addObject:twelveSchedule];
        }
        
        if (sixteenArr.count == 0) {
            EMScheduleModel *sixteenSchedule = [EMScheduleModel new];
            sixteenSchedule.startTime = @"18:00";
            [sixteenArr addObject:sixteenSchedule];
        }
        
        BOOL isScrollToOffset = betweenTwelveSixteenArr.count == 0 && betweenNineTwelveArr.count == 0 && SCREEN_WIDTH <= 375;
        
        NSInteger totalCount = beforeNineArr.count + nineArr.count + betweenNineTwelveArr.count + twelveArr.count + betweenTwelveSixteenArr.count + sixteenArr.count + afterSixteenArr.count;
        CGFloat contentHeight = totalCount * 48;
//        if (contentHeight < self.tableView.height) {
        BOOL isAdjust = (contentHeight < 288 && SCREEN_WIDTH == 375) || (contentHeight < self.tableView.height && SCREEN_WIDTH > 375);
        if (isAdjust) {
            NSInteger count = SCREEN_WIDTH > 375 ? 2 : 1;
            
            BOOL isInsertBoth = betweenTwelveSixteenArr.count == 0 && betweenNineTwelveArr.count == 0;
            BOOL isInsertBetweenNineTwelve = (betweenNineTwelveArr.count < 2 && betweenTwelveSixteenArr.count == 1) || isInsertBoth;
            BOOL isInsertBetweenTwelveSixteen = (betweenNineTwelveArr.count == 1 && betweenTwelveSixteenArr.count < 2) || isInsertBoth;
            if (betweenNineTwelveArr.count == 0) {
                for (NSInteger i = 0; i < count; i++) {
                    EMScheduleModel *nineSchedule = [EMScheduleModel new];
                    nineSchedule.startTime = @"09:00";
                    [betweenNineTwelveArr addObject:nineSchedule];
                }
            }
            
            if (betweenTwelveSixteenArr.count == 0) {
                for (NSInteger i = 0; i < count; i++) {
                    EMScheduleModel *twelveSchedule = [EMScheduleModel new];
                    twelveSchedule.startTime = @"12:00";
                    [betweenTwelveSixteenArr addObject:twelveSchedule];
                }
            }
            
            if (afterSixteenArr.count == 0 && beforeNineArr.count == 0) {
                if (isInsertBetweenNineTwelve) {
                    EMScheduleModel *nineSchedule = betweenNineTwelveArr.lastObject;
                    NSArray *timeCompArray = [nineSchedule.startTime componentsSeparatedByString:@":"];
                    NSInteger firstNum = [timeCompArray.firstObject integerValue];
                    NSInteger lastNum = [timeCompArray.lastObject integerValue];
                    BOOL isInsert = (firstNum >= 10 && lastNum > 30) || [nineSchedule.startTime isEqualToString:@"11:00"];
                    EMScheduleModel *newSchedule = [EMScheduleModel new];
                    newSchedule.startTime = isInsert ? @"09:00" : nineSchedule.startTime;
                    if (isInsert) {
                        [betweenNineTwelveArr insertObject:newSchedule atIndex:0];
                    } else {
                        [betweenNineTwelveArr addObject:newSchedule];
                    }
                }
                
                if (isInsertBetweenTwelveSixteen) {
                    EMScheduleModel *twelveSchedule = betweenTwelveSixteenArr.lastObject;
                    NSArray *timeCompArray = [twelveSchedule.startTime componentsSeparatedByString:@":"];
                    NSInteger firstNum = [timeCompArray.firstObject integerValue];
                    BOOL isInsert = firstNum > 15;
                    EMScheduleModel *newSchedule = [EMScheduleModel new];
                    newSchedule.startTime = isInsert ? @"12:00" : twelveSchedule.startTime;
                    if (isInsert) {
                        [betweenTwelveSixteenArr insertObject:newSchedule atIndex:0];
                    } else {
                        [betweenTwelveSixteenArr addObject:newSchedule];
                    }
                }
            }
            
        }
        
        [scheduleArray addObjectsFromArray:beforeNineArr];
        [scheduleArray addObjectsFromArray:nineArr];
        [scheduleArray addObjectsFromArray:betweenNineTwelveArr];
        [scheduleArray addObjectsFromArray:twelveArr];
        [scheduleArray addObjectsFromArray:betweenTwelveSixteenArr];
        [scheduleArray addObjectsFromArray:sixteenArr];
        [scheduleArray addObjectsFromArray:afterSixteenArr];
        
        EMScheduleModel *lastSchedule = scheduleArray.lastObject;
        self.lastTimeStr = lastSchedule.startTime;
        
        self.schedules = scheduleArray;
        
        [self.tableView reloadData];
        
        if (isScrollToOffset) {
            self.tableView.contentOffset = CGPointMake(0, 10);
        }
    } else {
        self.schedules = schedules;
        self.noScheduleView.hidden = NO;
        self.tableView.hidden = YES;
    }
}

- (void)refreshSchedule:(NSString *)scheduleID isRead:(NSString *)isRead
{
    for (NSInteger i = 0; i < self.schedules.count; i++) {
        EMScheduleModel *schedule = self.schedules[i];
        if ([schedule.scheduleId isEqualToString:scheduleID]) {
            schedule.appraiseIsRead = isRead;
            EMScheduleDailyTableViewCell *cell = [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
            [cell appraise];
            break;
        }
    }
}

#pragma mark - Action
- (void)handleClickGotoDayViewAction
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handleGotoDayViewAction)]) {
        [self.delegate handleGotoDayViewAction];
    }
}

#pragma mark - Getter
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [UITableView new];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self addSubview:_tableView];
    }
    return _tableView;
}


@end
