//
//  EMMessageRollingView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/27.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EMMessageRollingView : UIView

@property (nonatomic, strong) NSMutableArray *messages;

- (instancetype)initWithTimeInterval:(NSTimeInterval)timeInterval;

@end
