//
//  EMMessageView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/11.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMMessageView.h"
#import "EMMessageRollingView.h"

@interface EMMessageView ()

@property (nonatomic, strong) EMMessageRollingView *rollingView;

@property (nonatomic, strong) UIImageView *redDotImageView;
@property (nonatomic, strong) UILabel *countLabel;

@end

@implementation EMMessageView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self initViews];
    }
    return self;
}

- (void)initViews
{
    UIButton *messageButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [messageButton setImage:[UIImage imageNamed:@"icon_news"] forState:UIControlStateNormal];
    [messageButton setTitle:@"  消息" forState:UIControlStateNormal];
    [messageButton setTitleColor:UIColorFromHex(0xfeb402) forState:UIControlStateNormal];
    [messageButton addTarget:self action:@selector(handleClickMessageButton:) forControlEvents:UIControlEventTouchUpInside];
    messageButton.titleLabel.font = [UIFont systemFontOfSize:14.0];
    [self addSubview:messageButton];
    
    self.redDotImageView = [UIImageView new];
    self.redDotImageView.image = [UIImage imageNamed:@"icon_msgReddot"];
    self.redDotImageView.hidden = YES;
    [self addSubview:self.redDotImageView];
    
    self.countLabel = [UILabel new];
    self.countLabel.text = @"12";
    self.countLabel.textColor = [UIColor whiteColor];
    self.countLabel.textAlignment = NSTextAlignmentCenter;
    self.countLabel.font = [UIFont systemFontOfSize:10];
    [self.redDotImageView addSubview:self.countLabel];
    
    UIView *lineView = [UIView new];
    lineView.backgroundColor = UIColorFromHex(0xdddddd);
    [self addSubview:lineView];
    
    self.rollingView = [[EMMessageRollingView alloc] initWithTimeInterval:2.0];
    [self addSubview:self.rollingView];
    
    [messageButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).with.offset(5);
        make.centerY.equalTo(self);
        make.width.equalTo(@56);
    }];
    
    [self.redDotImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(messageButton.mas_left).with.offset(13);
        make.top.equalTo(self).with.offset(2);
        make.size.mas_equalTo(CGSizeMake(17, 14));
    }];
    
    [self.countLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(@0);
        make.top.equalTo(@0);
        make.size.mas_equalTo(self.redDotImageView);
    }];
    
    [lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(messageButton.mas_right).with.offset(10);
        make.top.equalTo(self).with.offset(10);
        make.bottom.equalTo(self).with.offset(-10);
        make.width.equalTo(@2);
    }];
    
    [self.rollingView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.height.equalTo(@25);
        make.left.equalTo(lineView.mas_right).with.offset(10);
        make.right.equalTo(self).with.offset(-15);
    }];
    
    [self updateConstraintsIfNeeded];
}

- (void)handleClickMessageButton:(id)sender
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handleClickMessageView)]) {
        [self.delegate handleClickMessageView];
    }
}

- (void)setMessages:(NSArray *)messages count:(NSInteger)count
{
    self.rollingView.messages = [messages mutableCopy];
    if (count > 0) {
        self.countLabel.text = count > 9 ? @"9+" : [NSString stringWithFormat:@"%ld", count];
        self.redDotImageView.hidden = NO;
    } else {
        self.redDotImageView.hidden = YES;
    }
    
}

@end
