//
//  EMPerformanceView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/12.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol EMPerformanceViewDelegate <NSObject>

/**
 选择

 @param index 0:放款 1:申请 2:开单
 */
- (void)performanceViewSelectIndex:(NSInteger)index;

@end

@interface EMPerformanceView : UIView

@property (nonatomic, weak) id<EMPerformanceViewDelegate> delegate;

- (void)updatePerformanceData:(NSDictionary *)data;

@end
