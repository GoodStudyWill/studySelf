//
//  EMMessageView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/11.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol EMMessageViewDelegate <NSObject>

- (void)handleClickMessageView;

@end

@interface EMMessageView : UIView

@property (nonatomic, weak) id<EMMessageViewDelegate> delegate;

- (void)setMessages:(NSArray *)messages count:(NSInteger)count;

@end
