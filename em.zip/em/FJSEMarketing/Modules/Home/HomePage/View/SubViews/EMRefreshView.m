//
//  EMRefreshView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/12.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMRefreshView.h"
#import "FJSActivityIndicatorView.h"

@interface EMRefreshView ()<UIScrollViewDelegate>

@property (nonatomic, assign) NSInteger refreshTag;

@property (nonatomic, strong) FJSActivityIndicatorView *downIndicator;

@end

@implementation EMRefreshView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initScrollView];
    }
    return self;
}

- (void)initScrollView
{
    CGSize contentSize = self.bounds.size;
    contentSize.height += 1;
    self.scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
    self.scrollView.contentSize = contentSize;
    self.scrollView.delegate = self;
    self.scrollView.bounces = YES;
    self.scrollView.showsVerticalScrollIndicator = NO;
    self.scrollView.showsHorizontalScrollIndicator = NO;
    [self addSubview:self.scrollView];
}

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView
{
    if (_refreshTag == 1) {
        
        [self.downIndicator startAnimating];
        [scrollView setContentInset:UIEdgeInsetsMake(51, 0, 0, 0)];
        [self refresh];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    // 保持indecator的位置一直在顶端
    if (scrollView.contentOffset.y < -50) {
        _refreshTag = 1;
        [self.downIndicator changeStatus:YES];
    } else {
        [self.downIndicator changeStatus:NO];
    }
    
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGPoint offect = self.scrollView.contentOffset;
    offect.y = 0;
    [self.scrollView setContentOffset:offect animated:NO];
    
}

- (void)refresh
{
    
}

- (void)didRefreshed
{
    if (_refreshTag == 1) {
        [self.downIndicator stopAnimating];
        [self.scrollView setContentInset:UIEdgeInsetsMake(0, 0, 0, 0)];
    }
    _refreshTag = 0;
}

- (FJSActivityIndicatorView *)downIndicator
{
    if (!_downIndicator) {
        _downIndicator  = [[FJSActivityIndicatorView alloc] initWithFrame:CGRectMake(0, -30, SCREEN_WIDTH, 30) style:FJSActivityIndicatorViewStyleDown];
        [self.scrollView addSubview:_downIndicator];
    }
    return _downIndicator;
}

@end
