//
//  EMMessageRollingView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/27.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMMessageRollingView.h"
#import "EMMessageModel.h"
#import "NSDate+FJSExtension.h"

@interface EMMessageRollingView ()

@property (nonatomic, assign) NSTimeInterval timeInterval;

@property (nonatomic, assign) NSInteger index;
@property (nonatomic, assign) NSInteger modelIndex;

@property (nonatomic, strong) NSTimer *timer;

@end

@implementation EMMessageRollingView

- (instancetype)initWithTimeInterval:(NSTimeInterval)timeInterval
{
    self = [super init];
    if (self) {
        _timeInterval = timeInterval;
        self.clipsToBounds = YES;
    }
    return self;
}

- (void)setMessages:(NSMutableArray *)messages
{
    [self stopTimer];
    _messages = messages;
    
    EMMessageModel *model = [[EMMessageModel alloc] init];
    model.messageTitle = @"";
    [_messages addObject:model];
    
    self.index = 1;
    self.modelIndex = 0;
    
    UIView *firstView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, self.width, self.height)];
    [self setMessageView:firstView withMessage:_messages.firstObject];
    firstView.tag = self.index;
    [self addSubview:firstView];
    
    if (messages.count > 1) {
        [self startTimer];
    }
}

- (void)startTimer
{
    self.timer = [NSTimer scheduledTimerWithTimeInterval:3.0 target:self selector:@selector(nextView) userInfo:nil repeats:YES];
}

- (void)stopTimer
{
    [self.timer invalidate];
    self.timer = nil;
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
}

- (void)nextView
{
    UIView *firstView = [self viewWithTag:self.index];
    
    UIView *nowView = [[UIView alloc] initWithFrame:CGRectMake(0, self.height, self.width, self.height)];
    nowView.tag = self.index + 1;
    
    EMMessageModel *model = self.messages[self.modelIndex+1];
    if ([model.messageTitle isEqualToString:@""]) {
        self.modelIndex = -1;
        self.index = 0;
    }
    if (nowView.tag == self.messages.count) {
        nowView.tag = 1;
    }
    
    [self setMessageView:nowView withMessage:self.messages[self.modelIndex+1]];
    [self addSubview:nowView];
    
    [UIView animateWithDuration:0.6 animations:^{
        firstView.y = -self.height;
        nowView.y = 0;
        
    } completion:^(BOOL finished) {
        [firstView removeFromSuperview];
        
    } ];
    self.index++;
    self.modelIndex++;
}

- (void)setMessageView:(UIView *)view withMessage:(EMMessageModel *)message
{
    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.width-80, self.height)];
    titleLabel.text = message.messageTitle;
    titleLabel.textColor = UIColorFromHex(0x333333);
    titleLabel.font = [UIFont systemFontOfSize:14];
    [view addSubview:titleLabel];
    
    UILabel *dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.width-80, 0, 80, self.height)];
    dateLabel.text = [NSDate fjs_dateStringFromString:message.publishTime intoFormat:@"yyyy-MM-dd"];
    dateLabel.textColor = UIColorFromHex(0x666666);
    dateLabel.font = [UIFont systemFontOfSize:13];
    dateLabel.textAlignment = NSTextAlignmentCenter;
    [view addSubview:dateLabel];
    
}

@end
