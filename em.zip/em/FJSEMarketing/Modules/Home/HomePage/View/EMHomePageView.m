//
//  EMHomePageView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/11.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMHomePageView.h"
#import "EMMessageView.h"
#import "EMRatioView.h"
#import "EMCommissionView.h"
#import "EMPerformanceView.h"
#import "EMTodayScheduleView.h"

@interface EMHomePageView ()<EMPerformanceViewDelegate, EMMessageViewDelegate, EMTodayScheduleViewDelegate>

@property (nonatomic, strong) UIView *bgView;

@property (nonatomic, strong) EMMessageView *messageView;
@property (nonatomic, strong) EMRatioView *ratioView;
@property (nonatomic, strong) EMCommissionView *commissionView;
@property (nonatomic, strong) EMTodayScheduleView *scheduleView;
@property (nonatomic, strong) EMPerformanceView *performanceView;

@end

@implementation EMHomePageView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = UIColorFromHex(0xeeeeee);
        self.userInteractionEnabled = YES;
        
        [self initContentView];
        [self layoutConstraints];
        [self setupActions];
    }
    return self;
}

#pragma mark - UI
- (void)initContentView
{
    __weak EMHomePageView *weakSelf = self;
    
    UIImageView *backgroundImageView = [[UIImageView alloc] initWithFrame:self.bounds];
    backgroundImageView.image = [UIImage imageNamed:@"bg_home@3x.jpg"];
    [self addSubview:backgroundImageView];
    [self sendSubviewToBack:backgroundImageView];
    
    self.bgView = [[UIView alloc] initWithFrame:self.bounds];
    [self.scrollView addSubview:self.bgView];
    
    self.messageView = [EMMessageView new];
    self.messageView.delegate = self;
    [self setView:self.messageView];
    
    self.ratioView = [[EMRatioView alloc] initWithLoanRatio:0.2 applyRatio:0.28];
    [self setView:self.ratioView];
    
    self.commissionView = [EMCommissionView new];
    [self setView:self.commissionView];
    
    self.scheduleView = [EMTodayScheduleView new];
    self.scheduleView.newBlock = ^{
        [weakSelf handleNewButtonAction];
    };
    self.scheduleView.selectBlock = ^(NSString *url) {
        [weakSelf handleSelectScheduleAction:url];
    };
    self.scheduleView.delegate = self;
    [self setView:self.scheduleView];
    
    self.performanceView = [EMPerformanceView new];
    self.performanceView.delegate = self;
    [self setView:self.performanceView];
    
    [self.bgView addSubview:self.messageView];
    [self.bgView addSubview:self.commissionView];
    [self.bgView addSubview:self.ratioView];
    [self.bgView addSubview:self.scheduleView];
    [self.bgView addSubview:self.performanceView];
}

- (void)layoutConstraints
{
    [self.messageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.bgView).with.offset(5);
        make.left.equalTo(self.bgView).with.offset(10);
        make.right.equalTo(self.bgView).with.offset(-10);
        make.height.equalTo(@40);
    }];
    
    [self.ratioView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.messageView.mas_bottom).with.offset(5);
        make.left.equalTo(self.bgView).with.offset(10);
        make.right.equalTo(self.commissionView.mas_left).with.offset(-2);
        make.height.equalTo(@76);
        make.width.equalTo(self.commissionView);
    }];
    
    [self.commissionView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.messageView.mas_bottom).with.offset(5);
        make.left.equalTo(self.ratioView.mas_right).with.offset(2);
        make.right.equalTo(self.bgView).with.offset(-10);
        make.height.equalTo(@76);
        make.width.equalTo(self.ratioView);
    }];
    
    [self.scheduleView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.ratioView.mas_bottom).with.offset(2);
        make.left.equalTo(self.bgView).with.offset(10);
        make.right.equalTo(self.bgView).with.offset(-10);
        make.bottom.equalTo(self.performanceView.mas_top).with.offset(-5);
    }];
    
    [self.performanceView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.bgView).with.offset(-5);
        make.left.equalTo(self.bgView).with.offset(10);
        make.right.equalTo(self.bgView).with.offset(-10);
        make.height.equalTo(@75);
    }];
    
    [self layoutIfNeeded];
}

- (void)setView:(UIView *)view
{
    UIColor *backgroundColor = [UIColor whiteColor];
    CGFloat alpha = 0.92;
    CGFloat cornerRadius = 2;
    
    view.backgroundColor = backgroundColor;
    view.alpha = alpha;
    view.layer.cornerRadius = cornerRadius;
}

- (void)refresh
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handleRefresh)]) {
        [self.delegate handleRefresh];
    }
}

#pragma mark - Actions
- (void)setupActions
{
    UITapGestureRecognizer *tapMessageGR = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapMessageViewAction)];
    tapMessageGR.numberOfTapsRequired = 1;
    [self.messageView addGestureRecognizer:tapMessageGR];
}

- (void)handleTapMessageViewAction
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handleTapMessageViewAction)]) {
        [self.delegate handleTapMessageViewAction];
    }
}

- (void)handleNewButtonAction
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handleNewTodayScheduleAction)]) {
        [self.delegate handleNewTodayScheduleAction];
    }
}

- (void)handleSelectScheduleAction:(NSString *)urlStr
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handleSelectTodayScheduleActionWithUrl:)]) {
        [self.delegate handleSelectTodayScheduleActionWithUrl:urlStr];
    }
}

#pragma mark - UpdateUI
- (void)updateCommissionView:(NSString *)commission
{
    [self.commissionView updateCommission:commission];
}

- (void)updatePerformaceView:(NSDictionary *)performaceData
{
    [self.performanceView updatePerformanceData:performaceData];
}

- (void)updateMessageView:(NSArray *)messages count:(NSInteger)count
{
    [self.messageView setMessages:messages count:count];
}

- (void)updateTodaySchedulesView:(NSArray *)schedules
{
    [self.scheduleView updateTodaySchedules:schedules];
}

- (void)updateRatioViewCountWithExploit:(NSInteger)exploit maintain:(NSInteger)maintain other:(NSInteger)other
{
    [self.ratioView updateScheduleCountWithExploit:exploit maintain:maintain other:other];
}

- (void)todayScheduleViewRefreshSchedule:(NSString *)scheduleID isRead:(NSString *)isRead
{
    [self.scheduleView refreshSchedule:scheduleID isRead:isRead];
}

#pragma mark - EMPerformanceViewDelegate
- (void)performanceViewSelectIndex:(NSInteger)index
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handlePerformaceViewSelectIndex:)]) {
        [self.delegate handlePerformaceViewSelectIndex:index];
    }
}

#pragma mark - EMMessageViewDelegate
- (void)handleClickMessageView
{
    [self handleTapMessageViewAction];
}

#pragma mark - EMTodayScheduleViewDelegate
- (void)handleGotoDayViewAction
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handleGotoTodayScheduleAction)]) {
        [self.delegate handleGotoTodayScheduleAction];
    }
}

@end
