//
//  EMHomePageView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/11.
//  Copyright © 2017年 pingan. All rights reserved.
//

//#import <UIKit/UIKit.h>
#import "EMRefreshView.h"

@protocol EMHomePageViewDelegate <NSObject>

- (void)handleTapMessageViewAction;

- (void)handlePerformaceViewSelectIndex:(NSInteger)index;

- (void)handleNewTodayScheduleAction;

- (void)handleSelectTodayScheduleActionWithUrl:(NSString *)urlStr;

- (void)handleGotoTodayScheduleAction;

- (void)handleRefresh;

@end

@interface EMHomePageView : EMRefreshView

@property (nonatomic, weak) id<EMHomePageViewDelegate> delegate;

- (void)updateCommissionView:(NSString *)commission;

- (void)updatePerformaceView:(NSDictionary *)performaceData;

- (void)updateMessageView:(NSArray *)messages count:(NSInteger)count;

- (void)updateTodaySchedulesView:(NSArray *)schedules;

- (void)updateRatioViewCountWithExploit:(NSInteger)exploit maintain:(NSInteger)maintain other:(NSInteger)other;

- (void)todayScheduleViewRefreshSchedule:(NSString *)scheduleID isRead:(NSString *)isRead;

@end
