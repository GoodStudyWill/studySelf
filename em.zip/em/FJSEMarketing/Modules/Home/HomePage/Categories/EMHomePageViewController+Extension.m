//
//  EMHomePageViewController+Extension.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/11.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMHomePageViewController+Extension.h"
#import "EMMyAccountViewController.h"
#import "EMAttendanceViewController.h"

@implementation EMHomePageViewController (Extension)

#pragma mark - Setup navigationBar
- (void)setupNavigationBar
{
    self.navigationController.navigationBar.barTintColor = UIColorFromHex(0x00a0ea);
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    UIBarButtonItem *backItem = [[UIBarButtonItem alloc] initWithTitle:@"" style:UIBarButtonItemStyleDone target:nil action:nil];
    [self.navigationItem setBackBarButtonItem:backItem];
    
    UIBarButtonItem *meItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_my"]
                                                               style:UIBarButtonItemStylePlain
                                                              target:self
                                                              action:@selector(handleMeItemAction:)];
    
    self.navigationItem.leftBarButtonItem = meItem;
    
    UIBarButtonItem *attendanceItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_attendance"]
                                                                       style:UIBarButtonItemStylePlain
                                                                      target:self
                                                                      action:@selector(handleAttendanceItemAction:)];
    self.navigationItem.rightBarButtonItem = attendanceItem;
    
    UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(117, 15, 58, 17)];
    imageView.image = [UIImage imageNamed:@"LOGO_home"];
    imageView.contentMode = UIViewContentModeScaleAspectFit;
    self.navigationItem.titleView = imageView;
    
    
}

- (void)handleMeItemAction:(id)sender
{
    FJSLog(@"me....");
    self.navigationItem.leftBarButtonItem.enabled = NO;
    EMMyAccountViewController *myAccountViewController = [[EMMyAccountViewController alloc] initWithNibName:@"EMMyAccountViewController" bundle:nil];
    myAccountViewController.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:myAccountViewController animated:YES];
}

- (void)handleAttendanceItemAction:(id)sender
{
    FJSLog(@"attendance....");
    self.navigationItem.rightBarButtonItem.enabled = NO;
    EMAttendanceViewController *attendanceViewController = [[EMAttendanceViewController alloc] initWithNibName:@"EMAttendanceViewController" bundle:nil];
    attendanceViewController.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:attendanceViewController animated:YES];
}

@end
