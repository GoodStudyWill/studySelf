//
//  EMDailyScheduleDataSource.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/22.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMDailyScheduleDataSource.h"
#import "EMScheduleModel.h"

@interface EMDailyScheduleDataSource ()<UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray *dailySchedules;

@end

@implementation EMDailyScheduleDataSource

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _dailySchedules.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return nil;
}

#pragma mark - Setter & getter
- (NSMutableArray *)dailySchedules
{
    if (!_dailySchedules) {
        _dailySchedules = [@[[self getScheduleWithName:@"链家上海分公司" date:@"2017-7-7 09:00"],
                             [self getScheduleWithName:@"我爱我家上海分公司" date:@"2017-7-7 10:00"],
                             [self getScheduleWithName:@"中原地产上海分公司" date:@"2017-7-7 11:00"],
                             [self getScheduleWithName:@"中原地产上海分公司" date:@"2017-7-7 12:00"],
                             [self getScheduleWithName:@"中介上海分公司" date:@"2017-7-7 13:00"],
                             [self getScheduleWithName:@"家家顺上海分公司" date:@"2017-7-7 14:00"],
                             [self getScheduleWithName:@"链家分公司" date:@"2017-7-7 19:00"],
                             ] mutableCopy];
    }
    return _dailySchedules;
}

- (EMScheduleModel *)getScheduleWithName:(NSString *)name date:(NSString *)date
{
    EMScheduleModel *model = [EMScheduleModel new];
    model.agencyCompanyName = name;
    model.startTime = date;
    return model;
}

@end
