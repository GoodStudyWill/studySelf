//
//  EMScheduleConstant.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/31.
//  Copyright © 2017年 pingan. All rights reserved.
//

#ifndef EMScheduleConstant_h
#define EMScheduleConstant_h

//计划类型
typedef NS_ENUM(NSUInteger, EMScheduleType)
{
    EMScheduleTypeExploit    = 1,       //中介开拓
    EMScheduleTypeMaintain   = 2,       //中介维护
    EMScheduleTypeOther      = 99,      //其他
};

//计划状态
typedef NS_ENUM(NSUInteger, EMScheduleStatus)
{
    EMScheduleStatusAwaiting    = 0,   //待完成，新建后
    EMScheduleStatusUndone      = 1,   //未完成
    EMScheduleStatusDone        = 2,   //已完成，执行已解决
    EMScheduleStatusUnhandled   = 3,   //执行未解决
};

//中介类型
typedef NS_ENUM(NSUInteger, EMScheduleAgencyType)
{
    EMScheduleAgencyTypeHouse = 0,  //房产中介
    EMScheduleAgencyTypeFinance,    //金融中介
    EMScheduleAgencyTypeOther,      //其他
};

//提醒时间类型
typedef NS_ENUM(NSUInteger, EMScheduleRemindTimeType) {
    EMScheduleRemindTimeTypeOnTime          = 1,    //事件发生时
    EMScheduleRemindTimeTypeFiveMinsAgo,            //5分钟前
    EMScheduleRemindTimeTypeFifteenMinsAgo,         //15分钟前
    EMScheduleRemindTimeTypeHalfHourAgo,            //30分钟前
    EMScheduleRemindTimeTypeAnHourAgo,              //1小时前
    EMScheduleRemindTimeTypeTwoHoursAgo,            //2小时前
    EMScheduleRemindTimeTypeADayAgo,                //一天前
    EMScheduleRemindTimeTypeTwoDaysAgo,             //两天前
    EMScheduleRemindTimeTypeAWeekAgo,               //一周前
};

#endif /* EMScheduleConstant_h */
