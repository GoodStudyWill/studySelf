//
//  EMScheduleModel.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleModel.h"
#import "NSDate+FJSExtension.h"

@implementation EMScheduleModel

+ (NSDictionary *)describeColumnDict
{
    //设置主键为scheduleID
    FJSDBColumnDes *scheduleId = [FJSDBColumnDes new];
    scheduleId.primaryKey = YES;
    scheduleId.columnName = @"schedule_id";
    
    return @{@"scheduleId" : scheduleId};
}

- (NSString *)startTime
{
    if (!_startTime) {
        if (!_startDate) {
            return nil;
        }
        
        _startTime = [[_startDate componentsSeparatedByString:@" "] lastObject];
    }
    return _startTime;
}

@end
