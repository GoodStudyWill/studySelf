//
//  EMScheduleModel.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSDatabase/FJSDatabase.h>

@interface EMScheduleModel : FJSDBModel

//备注
@property (nonatomic, copy) NSString *remark;

//计划类型
@property (nonatomic, copy) NSString *scheduleType;

//中介公司ID
@property (nonatomic, copy) NSString *primaryID;

//计划拜访中介名称
@property (nonatomic, copy) NSString *agencyCompanyName;

//提醒类型
@property (nonatomic, copy) NSString *reminderTimeType;

//事项
@property (nonatomic, copy) NSString *matter;

//计划开始日期
@property (nonatomic, copy) NSString *date;

//计划开始时间完整，例如"2017-07-03 9:00"
@property (nonatomic, copy) NSString *startDate;

//计划开始时间完整，例如"9:00"
@property (nonatomic, copy) NSString *startTime;

//计划状态
@property (nonatomic, copy) NSString *status;

//计划ID
@property (nonatomic, copy) NSString *scheduleId;

//经理点评是否已读，0未读，1已读
@property (nonatomic, copy) NSString *appraiseIsRead;

@end
