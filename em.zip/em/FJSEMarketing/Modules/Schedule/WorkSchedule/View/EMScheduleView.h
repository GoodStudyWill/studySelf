//
//  EMScheduleView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/20.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

//工作计划视图类型
typedef NS_ENUM(NSUInteger, EMScheduleViewType) {
    EMScheduleViewTypeDay,      //日视图
    EMScheduleViewTypeWeek,     //周视图
    EMScheduleViewTypeMonth,    //月视图
};

typedef void (^EMScheduleViewChangeViewBlock)(EMScheduleViewType type);

@protocol EMScheduleViewDelegate <NSObject>

- (void)selectPreviousButton;

- (void)selectNextButton;

- (void)returnNow;

@end

@interface EMScheduleView : UIView

@property (nonatomic, weak) id<EMScheduleViewDelegate> delegate;

@property (nonatomic, copy) EMScheduleViewChangeViewBlock changeBlock;

- (void)setHeaderTitle:(NSString *)title type:(EMScheduleViewType)type;

@end
