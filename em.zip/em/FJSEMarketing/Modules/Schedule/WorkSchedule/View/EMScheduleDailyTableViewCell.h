//
//  EMScheduleDailyTableViewCell.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/9.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, EMScheduleDailyLineType) {
    EMScheduleDailyLineTypeFirst,           //第一个节点，上面的线不显示
    EMScheduleDailyLineTypeLastHasTime,     //最后一个节点，下面的线不显示
    EMScheduleDailyLineTypeLastNoTime,      //最后一个节点的其他事项，线不显示
};

@class EMScheduleModel;

@interface EMScheduleDailyTableViewCell : UITableViewCell

@property (nonatomic, strong) EMScheduleModel *model;

@property (nonatomic, assign) BOOL showTime;

@property (weak, nonatomic) IBOutlet UILabel *smallTimeLabel;

- (void)clearInfo;

- (void)setLine:(EMScheduleDailyLineType)type;

- (void)appraise;

@end
