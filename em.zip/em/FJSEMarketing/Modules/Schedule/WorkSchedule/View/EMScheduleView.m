//
//  EMScheduleView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/20.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleView.h"
#import "EMScheduleHeaderView.h"
#import "EMScheduleSelectView.h"

@interface EMScheduleView ()<EMScheduleHeaderViewDelegate>

@property (nonatomic, strong) EMScheduleHeaderView *headerView;
@property (nonatomic, strong) UIView *selectView;

@end

@implementation EMScheduleView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self initViews];
    }
    return self;
}

- (void)initViews
{
    self.headerView = [EMScheduleHeaderView new];
    self.headerView.delegate = self;
    [self addSubview:self.headerView];
    
    [self.headerView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self);
        make.left.equalTo(self);
        make.right.equalTo(self);
        make.height.equalTo(@60);
    }];
}

#pragma mark - Set header title
- (void)setHeaderTitle:(NSString *)title type:(EMScheduleViewType)type
{
    [self.headerView setTitle:title type:type];
}

#pragma mark - EMScheduleHeaderViewDelegate
- (void)showSelectView
{
    self.selectView = [UIView new];
    self.selectView.frame = self.bounds;
    [self addSubview:self.selectView];
    
    UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapSelectView:)];
    tapGR.numberOfTapsRequired = 1;
    [self.selectView addGestureRecognizer:tapGR];
    
    __weak EMScheduleView *weakSelf = self;
    EMScheduleSelectView *scheduleSelectView = [[[NSBundle mainBundle] loadNibNamed:@"EMScheduleSelectView" owner:self options:nil] lastObject];
    scheduleSelectView.selectBlock = ^(EMScheduleViewType type) {
        [weakSelf selectView:type];
    };
    [self.selectView addSubview:scheduleSelectView];
    
    [scheduleSelectView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.headerView.mas_centerY).with.offset(13);
        make.right.equalTo(self.headerView).with.offset(-10);
        make.size.mas_equalTo(CGSizeMake(88, 105));
    }];
}

- (void)clickPreviousButton
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(selectPreviousButton)]) {
        [self.delegate selectPreviousButton];
    }
}

- (void)clickNextButton
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(selectNextButton)]) {
        [self.delegate selectNextButton];
    }
}

- (void)clickNowButton
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(returnNow)]) {
        [self.delegate returnNow];
    }
}

#pragma mark - Action
- (void)tapSelectView:(UIGestureRecognizer *)sender
{
    [self removeSelectView];
}

#pragma mark - Select view
- (void)selectView:(EMScheduleViewType)type
{
    self.changeBlock(type);
    [self removeSelectView];
}

- (void)removeSelectView
{
    [self.selectView removeFromSuperview];
    self.selectView = nil;
}

#pragma mark - HitTest
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    UIView *view = [super hitTest:point withEvent:event];
    
    //穿透
    CGRect headerRect = self.headerView.bounds;
    CGRect selectViewRect = self.selectView.bounds;
    if (!CGRectContainsPoint(headerRect, point) && !CGRectContainsPoint(selectViewRect, point)) {
        return nil;
    }
    return view;
}


@end
