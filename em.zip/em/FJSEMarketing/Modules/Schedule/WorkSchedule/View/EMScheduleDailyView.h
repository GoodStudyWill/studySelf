//
//  EMScheduleDailyView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/2.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@class EMScheduleModel;

@protocol EMScheduleDailyViewDelegate <NSObject>

- (void)dailyViewUpdateScheduleTime:(EMScheduleModel *)schedule;

- (void)dailyViewDidSelectSchedule:(EMScheduleModel *)schedule;

@end

@interface EMScheduleDailyView : UIView

@property (nonatomic, weak) id<EMScheduleDailyViewDelegate> delegate;

- (void)setDailySchedules:(NSMutableArray *)schedules;

- (void)refreshSchedule:(NSString *)scheduleID;

@end
