//
//  EMScheduleHeaderView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/20.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EMScheduleView.h"

@protocol EMScheduleHeaderViewDelegate <NSObject>

- (void)showSelectView;

- (void)clickPreviousButton;

- (void)clickNextButton;

- (void)clickNowButton;

@end

@interface EMScheduleHeaderView : UIView

@property (nonatomic, weak) id<EMScheduleHeaderViewDelegate> delegate;

- (void)setTitle:(NSString *)title type:(EMScheduleViewType)type;

@end
