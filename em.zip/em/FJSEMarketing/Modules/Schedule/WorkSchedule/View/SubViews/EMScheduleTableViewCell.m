//
//  EMScheduleTableViewCell.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/31.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleTableViewCell.h"
#import "EMScheduleConstant.h"
#import "EMScheduleModel.h"
#import "EMNotificationCenter.h"

@interface EMScheduleTableViewCell ()

@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;
@property (weak, nonatomic) IBOutlet UILabel *companyLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIImageView *appraiseIcon;


@end

@implementation EMScheduleTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    if (selected && [self.schedule.appraiseIsRead isEqualToString:@"0"]) {
        self.schedule.appraiseIsRead = @"1";
        [self.schedule update];
        [[EMNotificationCenter sharedInstance] postAppraiseNotification:self.schedule];
        
        self.appraiseIcon.hidden = YES;
        self.companyLabel.x = 41;
        self.companyLabel.width = 240;
    }
}

- (void)setSchedule:(EMScheduleModel *)schedule
{
    _schedule = schedule;
    
    NSString *imageName = nil;
    UIColor *companyColor = UIColorFromHex(0x333333);
    UIColor *timeColor = UIColorFromHex(0xff715a);
    
    EMScheduleType scheduleType = schedule.scheduleType.integerValue;
    switch (scheduleType) {
        case EMScheduleTypeExploit:
        {
            imageName = @"icon_square_red";
        }
            break;
            
        case EMScheduleTypeMaintain:
        {
            imageName = @"icon_square_yellow";
        }
            break;
            
        case EMScheduleTypeOther:
        {
            imageName = @"icon_square_blue";
        }
            break;
    }
    
    EMScheduleStatus status = schedule.status.integerValue;
    if (status == EMScheduleStatusDone || status == EMScheduleStatusUnhandled) {
        imageName = @"icon_finished";
        companyColor = UIColorFromHex(0x999999);
        timeColor = UIColorFromHex(0x999999);
    }
    
    self.iconImageView.image = [UIImage imageNamed:imageName];
    
    NSString *companyName = _schedule.agencyCompanyName;
    if (!companyName || companyName.length == 0) {
        companyName = _schedule.matter;
    }
    else if (companyName.length > 10) {
        NSString *frontStr = [companyName substringToIndex:5];
        NSString *backStr = [companyName substringFromIndex:companyName.length-5];
        companyName = [NSString stringWithFormat:@"%@...%@", frontStr, backStr];
    }
    
    self.companyLabel.text = companyName;
    self.companyLabel.textColor = companyColor;
    
    BOOL hasUnreadAppraise = [schedule.appraiseIsRead isEqualToString:@"0"];
    self.appraiseIcon.hidden = !hasUnreadAppraise;
    self.companyLabel.x = hasUnreadAppraise ? 59 : 41;
    self.companyLabel.width = hasUnreadAppraise ? 222 : 240;
    
    self.timeLabel.text = _schedule.startTime;
    self.timeLabel.textColor = timeColor;
    
}

@end
