//
//  EMScheduleSelectView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/31.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EMScheduleView.h"

typedef void (^EMScheduleSelectViewBlock)(EMScheduleViewType type);

@interface EMScheduleSelectView : UIView

@property (nonatomic, copy) EMScheduleSelectViewBlock selectBlock;

@end
