//
//  EMScheduleSelectView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/31.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleSelectView.h"

@interface EMScheduleSelectView ()

@end

@implementation EMScheduleSelectView


- (IBAction)showView:(UIButton *)sender {
    if (self.selectBlock) {
        self.selectBlock(sender.tag);
    }
    
}


@end
