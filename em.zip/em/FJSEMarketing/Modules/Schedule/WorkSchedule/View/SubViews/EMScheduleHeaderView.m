//
//  EMScheduleHeaderView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/20.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleHeaderView.h"

@interface EMScheduleHeaderView ()

//回到现在按钮，不同视图下，分别为 “今日”， “本周”， “本月”
@property (nonatomic, strong) UIButton *nowButton;

@property (nonatomic, strong) UILabel *dateLabel;

@property (nonatomic, strong) UIView *changeView;

@end

@implementation EMScheduleHeaderView

- (instancetype)init
{
    self = [super init];
    if (self) {
        [self initViews];
    }
    return self;
}

- (void)initViews
{
    self.backgroundColor = [UIColor whiteColor];
    self.layer.cornerRadius = 2.0f;
    
    self.nowButton = [self getButtonWithTitle:@"本周"];
    [self.nowButton addTarget:self action:@selector(handleNowButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.nowButton];
    
    UIButton *selectViewButton = [self getButtonWithTitle:@"切换视图"];
    [selectViewButton addTarget:self action:@selector(handleClickSelectButton) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:selectViewButton];
    
    self.dateLabel = [UILabel new];
//    self.dateLabel.text = @"2017年7月 第二周";
    self.dateLabel.font = [UIFont systemFontOfSize:16];
    self.dateLabel.textColor = UIColorFromHex(0x666666);
    self.dateLabel.textAlignment = NSTextAlignmentCenter;
    [self addSubview:self.dateLabel];
    
    UIButton *previousButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [previousButton setImage:[UIImage imageNamed:@"arrow_date_L"] forState:UIControlStateNormal];
    [previousButton addTarget:self action:@selector(handlePreButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:previousButton];
    
    UIButton *nextButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [nextButton setImage:[UIImage imageNamed:@"arrow_date_R"] forState:UIControlStateNormal];
    [nextButton addTarget:self action:@selector(handleNextButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:nextButton];
    
    
    [self.nowButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).with.offset(20);
        make.centerY.equalTo(self);
    }];
    
    [selectViewButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self).with.offset(-10);
        make.centerY.equalTo(self);
    }];
    
    [self.dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self);
    }];
    
    [previousButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).with.offset(73);
        make.centerY.equalTo(self);
        make.width.height.equalTo(@25);
    }];
    
    [nextButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self).with.offset(-73);
        make.centerY.equalTo(self);
        make.width.height.equalTo(@25);
    }];
}

- (void)handleClickSelectButton
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(showSelectView)]) {
        [self.delegate showSelectView];
    }
    
}

- (void)removeChangeView
{
    [self.changeView removeFromSuperview];
    self.changeView = nil;
}

#pragma mark - Action
- (void)handlePreButtonAction
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickPreviousButton)]) {
        [self.delegate clickPreviousButton];
    }
}

- (void)handleNextButtonAction
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickNextButton)]) {
        [self.delegate clickNextButton];
    }
}

- (void)handleNowButtonAction
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(clickNowButton)]) {
        [self.delegate clickNowButton];
    }
}

#pragma mark - Factory
- (UIButton *)getButtonWithTitle:(NSString *)title
{
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:UIColorFromHex(0xffa32c) forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:13];
    button.titleLabel.textAlignment = NSTextAlignmentCenter;
    return button;
}

- (void)setTitle:(NSString *)title type:(EMScheduleViewType)type
{
    self.dateLabel.text = title;
    
    switch (type) {
        case EMScheduleViewTypeDay:
        {
            [self.nowButton setTitle:@"今日" forState:UIControlStateNormal];
        }
            break;
            
        case EMScheduleViewTypeWeek:
        {
            [self.nowButton setTitle:@"本周" forState:UIControlStateNormal];
        }
            break;
            
        case EMScheduleViewTypeMonth:
        {
            [self.nowButton setTitle:@"本月" forState:UIControlStateNormal];
        }
            break;
    }
}

@end
