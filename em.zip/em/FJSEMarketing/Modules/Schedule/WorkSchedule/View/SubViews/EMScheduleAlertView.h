//
//  EMScheduleAlertView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/11/6.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^EMScheduleAlertViewCompeletionBlock)(NSString *operateType, NSString *remark, NSString *status);

@interface EMScheduleAlertView : UIView

/**
 创建计划标记完成弹框

 @param operateType 操作类型，默认为2
 @param remark 备注
 @param completionBlock 回调
 @return 弹框
 */
+ (EMScheduleAlertView *)alertViewWithOperateType:(NSString *)operateType
                                           remark:(NSString *)remark
                                  completionBlock:(EMScheduleAlertViewCompeletionBlock)completionBlock;

- (void)show;

@end
