//
//  EMScheduleAlertView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/11/6.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleAlertView.h"
#import "UITextView+FJSPlaceHolder.h"

@interface EMScheduleAlertView ()<UITextViewDelegate>

@property (nonatomic, assign) EMScheduleStatus status;
@property (nonatomic, copy) NSString *remark;
@property (nonatomic, assign) NSString *operateType;

@property (nonatomic, copy) EMScheduleAlertViewCompeletionBlock completionBlock;

@property (nonatomic, strong) UIView *backgroundView;
@property (nonatomic, strong) UIButton *doneButton;
@property (nonatomic, strong) UIButton *undoneButton;
@property (nonatomic, strong) UILabel *remarkLabel;
@property (nonatomic, strong) UITextView *remarkTextView;
@property (nonatomic, strong) UIButton *submitButton;

@end

@implementation EMScheduleAlertView

+ (EMScheduleAlertView *)alertViewWithOperateType:(NSString *)operateType
                                           remark:(NSString *)remark
                                  completionBlock:(EMScheduleAlertViewCompeletionBlock)completionBlock
{
    EMScheduleAlertView *alertView = [[EMScheduleAlertView alloc] initWithOperateType:operateType
                                                                               remark:remark
                                                                      completionBlock:completionBlock];
    return alertView;
}

- (EMScheduleAlertView *)initWithOperateType:(NSString *)operateType
                                      remark:(NSString *)remark
                             completionBlock:(EMScheduleAlertViewCompeletionBlock)completionBlock
{
    self = [super initWithFrame:[UIApplication sharedApplication].keyWindow.bounds];
    if (self) {
        //如果operateType没值，默认为2
        _operateType = operateType ?: @"2";
        _remark = remark;
        _completionBlock = completionBlock;
        _status = EMScheduleStatusDone;
        
        [self initViews];
    }
    return self;
}

#pragma mark - Init views
- (void)initViews
{
    [self.backgroundView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self);
        make.width.equalTo(@310);
        make.height.equalTo(@295);
    }];
    
    [self.doneButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@31);
        make.left.equalTo(@20);
        make.right.equalTo(self.undoneButton.mas_left).with.offset(-32);
    }];
    
    [self.undoneButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@31);
        make.left.equalTo(self.doneButton.mas_right).with.offset(32);
    }];
    
    [self.remarkLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.doneButton.mas_bottom).with.offset(30);
        make.left.equalTo(@20);
    }];
    
    [self.remarkTextView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.remarkLabel.mas_bottom).with.offset(13);
        make.bottom.equalTo(self.submitButton.mas_top).with.offset(-22);
        make.left.equalTo(@20);
        make.right.equalTo(@(-20));
    }];
    
    [self.submitButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.remarkTextView.mas_bottom).with.offset(22);
        make.bottom.equalTo(@(-20));
        make.height.equalTo(@(41));
        make.left.equalTo(@20);
        make.right.equalTo(@(-20));
    }];
}

#pragma mark - Show & dismiss
- (void)show
{
    self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0];
    self.backgroundView.layer.opacity = 0.5f;
    self.backgroundView.layer.transform = CATransform3DMakeScale(1.3f, 1.3f, 1.0);
    
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    
    [UIView animateWithDuration:0.2f delay:0.0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        self.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:0.5f];
        self.backgroundView.layer.opacity = 1.0f;
        self.backgroundView.layer.transform = CATransform3DMakeScale(1, 1, 1);
    } completion:nil];
}

- (void)dismiss
{
    [self endEditing:YES];
    
    CATransform3D currentTransform = self.backgroundView.layer.transform;
    self.backgroundView.layer.opacity = 1.0f;
    [UIView animateWithDuration:0.2f delay:0.0 options:UIViewAnimationOptionTransitionNone animations:^{
        self.backgroundColor = [UIColor colorWithRed:0.0f green:0.0f blue:0.0f alpha:0.0f];
        self.backgroundView.layer.transform = CATransform3DConcat(currentTransform, CATransform3DMakeScale(0.6f, 0.6f, 1.0));
        self.backgroundView.layer.opacity = 0.0f;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}

#pragma mark - Action
- (void)handleSelectStatusAction:(UIButton *)sender
{
    self.status = sender.tag;
    if (sender.tag == EMScheduleStatusDone) {
        [self.doneButton setImage:[UIImage imageNamed:@"btn_ratio_selected"] forState:UIControlStateNormal];
        [self.undoneButton setImage:[UIImage imageNamed:@"btn_ratio_unselect"] forState:UIControlStateNormal];
    } else if (sender.tag == EMScheduleStatusUnhandled) {
        [self.doneButton setImage:[UIImage imageNamed:@"btn_ratio_unselect"] forState:UIControlStateNormal];
        [self.undoneButton setImage:[UIImage imageNamed:@"btn_ratio_selected"] forState:UIControlStateNormal];
    }
}

- (void)handleSubmitAction:(UIButton *)sender
{
    self.remark = [self.remarkTextView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
//    if (!self.remark || self.remark.length == 0) {
//        [EMHudManager showText:@"备注信息不能为空"];
//        return;
//    }
    
    if (self.completionBlock) {
        NSString *status = [NSString stringWithFormat:@"%lu", (unsigned long)self.status];
        self.remark = [self.remarkTextView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        self.completionBlock(self.operateType, self.remark, status);
    }
    [self dismiss];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    
    if (CGRectContainsPoint(self.backgroundView.frame, point)) {
        [self endEditing:YES];
    } else {
        [self dismiss];
    }
}

#pragma mark - UITextViewDelegate
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    if (floor(self.backgroundView.center.y) != floor(self.center.y)) {
        return;
    }
    
    CGPoint center = self.center;
    center.y -= 100;
    [UIView animateWithDuration:0.3 animations:^{
        self.backgroundView.center = center;
    }];
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    self.remark = [textView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (floor(self.backgroundView.center.y) == floor(self.center.y)) {
        return;
    }
    
    CGPoint center = self.center;
    [UIView animateWithDuration:0.3 animations:^{
        self.backgroundView.center = center;
    }];
}

- (void)textViewDidChange:(UITextView *)textView
{
    if (textView.text.length > 500) {
        textView.text = [textView.text substringWithRange:NSMakeRange(0, 500)];
        [textView.undoManager removeAllActions];
        [textView becomeFirstResponder];
    }
}

#pragma mark - Getter
- (UIView *)backgroundView
{
    if (!_backgroundView) {
        _backgroundView = [UIView new];
        _backgroundView.backgroundColor = [UIColor whiteColor];
        _backgroundView.layer.cornerRadius = 4;
        [self addSubview:_backgroundView];
    }
    return _backgroundView;
}

- (UIButton *)doneButton
{
    if (!_doneButton) {
        _doneButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_doneButton setTitle:@"  执行已解决" forState:UIControlStateNormal];
        [_doneButton setTitleColor:UIColorFromHex(0x333333) forState:UIControlStateNormal];
        [_doneButton setImage:[UIImage imageNamed:@"btn_ratio_selected"] forState:UIControlStateNormal];
        _doneButton.titleLabel.font = [UIFont systemFontOfSize:16];
        [_doneButton addTarget:self action:@selector(handleSelectStatusAction:) forControlEvents:UIControlEventTouchUpInside];
        _doneButton.tag = EMScheduleStatusDone;
        [self.backgroundView addSubview:_doneButton];
    }
    return _doneButton;
}

- (UIButton *)undoneButton
{
    if (!_undoneButton) {
        _undoneButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_undoneButton setTitle:@"  执行未解决" forState:UIControlStateNormal];
        [_undoneButton setTitleColor:UIColorFromHex(0x333333) forState:UIControlStateNormal];
        [_undoneButton setImage:[UIImage imageNamed:@"btn_ratio_unselect"] forState:UIControlStateNormal];
        _undoneButton.titleLabel.font = [UIFont systemFontOfSize:16];
        [_undoneButton addTarget:self action:@selector(handleSelectStatusAction:) forControlEvents:UIControlEventTouchUpInside];
        _undoneButton.tag = EMScheduleStatusUnhandled;
        [self.backgroundView addSubview:_undoneButton];
    }
    return _undoneButton;
}

- (UILabel *)remarkLabel
{
    if (!_remarkLabel) {
        _remarkLabel = [UILabel new];
        _remarkLabel.text = @"备注";
        _remarkLabel.textColor = UIColorFromHex(0x999999);
        _remarkLabel.font = [UIFont systemFontOfSize:15];
        [self.backgroundView addSubview:_remarkLabel];
    }
    return _remarkLabel;
}

- (UITextView *)remarkTextView
{
    if (!_remarkTextView) {
        _remarkTextView = [UITextView new];
        _remarkTextView.backgroundColor = UIColorFromHex(0xeeeeee);
        _remarkTextView.textColor = UIColorFromHex(0x333333);
        _remarkTextView.font = [UIFont systemFontOfSize:14];
        _remarkTextView.fjs_placeHolder = @"请输入您要填写的内容(限500字内)";
        _remarkTextView.fjs_placeHolderColor = UIColorFromHex(0x999999);
        _remarkTextView.delegate = self;
        
        if (self.remark) {
            _remarkTextView.text = self.remark;
        }
        [self.backgroundView addSubview:_remarkTextView];
    }
    return _remarkTextView;
}

- (UIButton *)submitButton
{
    if (!_submitButton) {
        _submitButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_submitButton setTitle:@"提交" forState:UIControlStateNormal];
        [_submitButton setTitleColor:UIColorFromHex(0xffffff) forState:UIControlStateNormal];
        _submitButton.titleLabel.font = [UIFont systemFontOfSize:16];
        _submitButton.backgroundColor = UIColorFromHex(0x00a0ea);
        _submitButton.layer.cornerRadius = 2;
        [_submitButton addTarget:self action:@selector(handleSubmitAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.backgroundView addSubview:_submitButton];
    }
    return _submitButton;
}

@end
