//
//  EMScheduleDailyView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/2.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleDailyView.h"
#import "EMScheduleModel.h"
#import "NSDate+FJSExtension.h"
#import "EMScheduleDailyTableViewCell.h"
#import "NSString+FJSExtension.h"
#import "EMScheduleConstant.h"

typedef NS_ENUM(NSUInteger, EMSnapshotMeetsEdge){
    EMSnapshotMeetsEdgeTop,
    EMSnapshotMeetsEdgeBottom,
};

@interface EMScheduleDailyView ()<UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate>

@property (nonatomic, strong) UITableView *tableView;

//计划集合
@property (nonatomic, strong) NSMutableArray *schedules;
//时间集合
@property (nonatomic, strong) NSMutableArray *timeArray;
//按时间分类的计划集合
@property (nonatomic, strong) NSMutableDictionary *scheduleDict;

/**对被选中的cell的截图*/
@property (nonatomic, strong) UIView *snapshot;
/**被选中的cell的原始位置*/
@property (nonatomic, strong) NSIndexPath *originalIndexPath;
/**被选中的cell的新位置*/
@property (nonatomic, strong) NSIndexPath *relocatedIndexPath;
/**cell被拖动到边缘后开启，tableview自动向上或向下滚动*/
@property (nonatomic, strong) CADisplayLink *autoScrollTimer;
/**记录手指所在的位置*/
@property (nonatomic, assign) CGPoint fingerLocation;
/**自动滚动的方向*/
@property (nonatomic, assign) EMSnapshotMeetsEdge autoScrollDirection;

@property (nonatomic, strong) UITableViewCell *selectedTimeCell;

@property (nonatomic, strong) EMScheduleModel *selectedModel;

@property (nonatomic, strong) UIView *noScheduleView;

@end

@implementation EMScheduleDailyView

- (void)layoutSubviews
{
    [super layoutSubviews];
    self.tableView.frame = CGRectMake(0, 0, self.width, self.height);
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([self isKeyTime:indexPath.row]) {
        BOOL isSameSchedule = NO;
        if (indexPath.row > 0) {
            NSString *time = self.timeArray[indexPath.row];
            NSString *preTime = self.timeArray[indexPath.row-1];
            isSameSchedule = [preTime isEqualToString:time];
            if (!isSameSchedule && indexPath.row+1 < self.timeArray.count) {
                NSString *nextTime = self.timeArray[indexPath.row + 1];
                isSameSchedule = [nextTime isEqualToString:time];
            }
        }
        return isSameSchedule ? 38 : 48;
    } else {
        return 9;
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    EMScheduleDailyTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    EMScheduleModel *schedule = cell.model;
    if (schedule.scheduleId && schedule.scheduleId.length > 0) {
        if (self.delegate && [self.delegate respondsToSelector:@selector(dailyViewDidSelectSchedule:)]) {
            [self.delegate dailyViewDidSelectSchedule:schedule];
        }
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (BOOL)isKeyTime:(NSInteger)index
{
    NSString *timeKey = self.timeArray[index];
    NSArray *scheduleArray = self.scheduleDict[timeKey];
    
    NSArray *timeCompArray = [timeKey componentsSeparatedByString:@":"];
    BOOL isKeyTime = [timeCompArray.lastObject isEqualToString:@"00"];
    return scheduleArray.count > 0 || isKeyTime;
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
//    return self.count;
    return self.timeArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"EMScheduleDailyTableViewCell";
    
    EMScheduleDailyTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"EMScheduleDailyTableViewCell" owner:nil options:nil] lastObject];
    }
    
    NSString *timeKey = self.timeArray[indexPath.row];
    NSArray *scheduleArray = self.scheduleDict[timeKey];
    
    EMScheduleModel *model = nil;
    if (scheduleArray && scheduleArray.count > 0) {
        //有日程
        NSUInteger lastIndex = [self.timeArray indexOfObject:timeKey];
        int index = abs((int)lastIndex - (int)indexPath.row);
        model = scheduleArray[index];
        
        cell.model = model;
        BOOL isShowTime = YES;
        if (indexPath.row > 0) {
            NSString *preTimeKey = self.timeArray[indexPath.row-1];
            isShowTime = ![preTimeKey isEqualToString:timeKey];
        }
        
        cell.showTime = isShowTime;
    } else {
        model = [EMScheduleModel new];
        model.startTime = timeKey;
        cell.model = model;
    }
    
    return cell;
}

#pragma mark - LongPressGestureRecognized
- (void)longPressGestureRecognized:(id)sender
{
    UILongPressGestureRecognizer *longPress = (UILongPressGestureRecognizer *)sender;
    UIGestureRecognizerState longPressState = longPress.state;
    //手指在tableView中的位置
    _fingerLocation = [longPress locationInView:self.tableView];
    //手指按住位置对应的indexPath，可能为nil
    _relocatedIndexPath = [self.tableView indexPathForRowAtPoint:_fingerLocation];
    
    
    switch (longPressState) {
        case UIGestureRecognizerStateBegan:
        {
            //手势开始，对被选中cell截图，隐藏原cell
            _originalIndexPath = [self.tableView indexPathForRowAtPoint:_fingerLocation];
            
            EMScheduleDailyTableViewCell *cell = [self.tableView cellForRowAtIndexPath:_originalIndexPath];
            if (!cell.model.scheduleId || cell.model.scheduleId.length == 0) {
                return;
            }
            
            if (_originalIndexPath) {
                [self cellSelectedAtIndexPath:_originalIndexPath];
            }
            break;
        }
            
        case UIGestureRecognizerStateChanged:
        {
            //点击位置移动，判断手指按住位置是否进入其它indexPath范围，若进入则更新数据源并移动cell
            //截图跟随手指移动
            if (!_snapshot) {
                break;
            }
            CGPoint center = _snapshot.center;
            center.y = _fingerLocation.y;
            _snapshot.center = center;
            if ([self checkIfSnapshotMeetsEdge]) {
                [self startAutoScrollTimer];
            }else{
                [self stopAutoScrollTimer];
            }
            
            //手指按住位置对应的indexPath，可能为nil
            _relocatedIndexPath = [self.tableView indexPathForRowAtPoint:_fingerLocation];
            if (_relocatedIndexPath && ![_relocatedIndexPath isEqual:_originalIndexPath]) {
                [self cellRelocatedToNewIndexPath:_relocatedIndexPath];
            }
            
            break;
        }
            
        default:
        {
            if (!_snapshot) {
                break;
            }
            //长按手势结束或被取消，移除截图，reloadData
            //移出屏幕外，获取到的relocatedIndexPath为nil
            NSString *relocatedTimeKey = nil;
            if (!_relocatedIndexPath) {
                if (_fingerLocation.y > self.tableView.contentSize.height) {
                    //移出屏幕下
                    relocatedTimeKey = self.timeArray.lastObject;
                } else {
                    //移出屏幕上
                    relocatedTimeKey = self.timeArray.firstObject;
                }
            } else {
                relocatedTimeKey = self.timeArray[_relocatedIndexPath.row];
            }
            
            NSMutableArray *scheduleArray = [NSMutableArray arrayWithArray:self.schedules];
            for (EMScheduleModel *aModel in scheduleArray) {
                if ([aModel.scheduleId isEqualToString:self.selectedModel.scheduleId]) {
                    aModel.startTime = relocatedTimeKey;
                    aModel.startDate = [NSString stringWithFormat:@"%@ %@", aModel.date, aModel.startTime];
                    if (self.delegate && [self.delegate respondsToSelector:@selector(dailyViewUpdateScheduleTime:)]) {
                        [self.delegate dailyViewUpdateScheduleTime:aModel];
                    }
                    break;
                }
            }
            [self stopAutoScrollTimer];
            [self didEndDraging];
            
            self.schedules = scheduleArray;
        }
            break;
    }
}

# pragma mark - timer methods
/**
 *  创建定时器并运行
 */
- (void)startAutoScrollTimer{
    if (!_autoScrollTimer) {
        _autoScrollTimer = [CADisplayLink displayLinkWithTarget:self selector:@selector(startAutoScroll)];
        [_autoScrollTimer addToRunLoop:[NSRunLoop mainRunLoop] forMode:NSRunLoopCommonModes];
    }
}
/**
 *  停止定时器并销毁
 */
- (void)stopAutoScrollTimer{
    if (_autoScrollTimer) {
        [_autoScrollTimer invalidate];
        _autoScrollTimer = nil;
    }
}

# pragma mark - Private methods

/**
 *  cell被长按手指选中，对其进行截图，原cell隐藏
 */
- (void)cellSelectedAtIndexPath:(NSIndexPath *)indexPath{
    EMScheduleDailyTableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    
    BOOL isNotSnapshot = !cell.model.scheduleId || cell.model.scheduleId.length == 0 || cell.model.status.integerValue == EMScheduleStatusDone || cell.model.status.integerValue == EMScheduleStatusUnhandled;
    if (isNotSnapshot) {
        _originalIndexPath = nil;
        _relocatedIndexPath = nil;
        return;
    }
    
    self.selectedModel = cell.model;
    [cell clearInfo];

    UIView *snapshot = [self customSnapshotOfModel:self.selectedModel frame:cell.frame];
    [self.tableView addSubview:snapshot];
    _snapshot = snapshot;
    CGPoint center = _snapshot.center;
    center.y = _fingerLocation.y;
    [UIView animateWithDuration:0.2 animations:^{
        _snapshot.alpha = 0.98;
        _snapshot.center = center;
    }];
}

/**
 *  截图被移动到新的indexPath范围，显示当前位置的时间
 *  @param indexPath 新的indexPath
 */
- (void)cellRelocatedToNewIndexPath:(NSIndexPath *)indexPath
{
    EMScheduleDailyTableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    cell.smallTimeLabel.hidden = NO;
    
    EMScheduleDailyTableViewCell *preCell = [self.tableView cellForRowAtIndexPath:_originalIndexPath];
    preCell.smallTimeLabel.hidden = YES;
    //更新cell的原始indexPath为当前indexPath
    _originalIndexPath = indexPath;
}

/**
 *  拖拽结束，显示cell，并移除截图
 */
- (void)didEndDraging{
    
    EMScheduleDailyTableViewCell *cell = [self.tableView cellForRowAtIndexPath:_originalIndexPath];
    
    cell.hidden = NO;
    cell.alpha = 0;
    [UIView animateWithDuration:0.2 animations:^{
        _snapshot.center = cell.center;
        _snapshot.alpha = 0;
        _snapshot.transform = CGAffineTransformIdentity;
        cell.alpha = 1;
    } completion:^(BOOL finished) {
        cell.hidden = NO;
        [_snapshot removeFromSuperview];
        _snapshot = nil;
        _originalIndexPath = nil;
        _relocatedIndexPath = nil;
    }];
}

/** 返回一个给定view的截图. */
- (UIView *)customSnapshotOfModel:(EMScheduleModel *)model frame:(CGRect)frame
{
    UIView *snapshot = [[UIView alloc] initWithFrame:frame];
    
    NSString *showStr = model.agencyCompanyName;
    if (!showStr || showStr.length == 0) {
        showStr = model.matter;
    }
    
    CGSize size = [showStr sizeWithAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:16]}];
    
    CGFloat width = size.width > frame.size.width-110-20-15 ? frame.size.width-110-20-15-5 : size.width;
    
    UIImageView *companyImageView = [[UIImageView alloc] initWithFrame:CGRectMake(110, 0, width+20+15, 41)];
    companyImageView.image = [UIImage imageNamed:@"img_company"];
    [snapshot addSubview:companyImageView];
    
    UILabel *companyLabel = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, width, 41)];
    companyLabel.text = showStr;
    companyLabel.textColor = UIColorFromHex(0x333333);
    companyLabel.font = [UIFont systemFontOfSize:16];
    [companyImageView addSubview:companyLabel];
    
    return snapshot;
}

/**
 *  将可变数组中的一个对象移动到该数组中的另外一个位置
 *  @param array     要变动的数组
 *  @param fromIndex 从这个index
 *  @param toIndex   移至这个index
 */
- (void)moveObjectInMutableArray:(NSMutableArray *)array fromIndex:(NSInteger)fromIndex toIndex:(NSInteger)toIndex{
    if (fromIndex < toIndex) {
        for (NSInteger i = fromIndex; i < toIndex; i ++) {
            [array exchangeObjectAtIndex:i withObjectAtIndex:i + 1];
        }
    }else{
        for (NSInteger i = fromIndex; i > toIndex; i --) {
            [array exchangeObjectAtIndex:i withObjectAtIndex:i - 1];
        }
    }
}

/**
 *  检查截图是否到达边缘，并作出响应
 */
- (BOOL)checkIfSnapshotMeetsEdge{
    CGFloat minY = CGRectGetMinY(_snapshot.frame);
    CGFloat maxY = CGRectGetMaxY(_snapshot.frame);
    if (minY < self.tableView.contentOffset.y) {
        _autoScrollDirection = EMSnapshotMeetsEdgeTop;
        return YES;
    }
    if (maxY > self.tableView.bounds.size.height + self.tableView.contentOffset.y) {
        _autoScrollDirection = EMSnapshotMeetsEdgeBottom;
        return YES;
    }
    return NO;
}

/**
 *  开始自动滚动
 */
- (void)startAutoScroll{
    CGFloat pixelSpeed = 4;
    if (_autoScrollDirection == EMSnapshotMeetsEdgeTop) {//向下滚动
        if (self.tableView.contentOffset.y > 0) {//向下滚动最大范围限制
            [self.tableView setContentOffset:CGPointMake(0, self.tableView.contentOffset.y - pixelSpeed)];
            _snapshot.center = CGPointMake(_snapshot.center.x, _snapshot.center.y - pixelSpeed);
        }
    }else{                                               //向上滚动
        if (self.tableView.contentOffset.y + self.tableView.bounds.size.height < self.tableView.contentSize.height) {//向下滚动最大范围限制
            [self.tableView setContentOffset:CGPointMake(0, self.tableView.contentOffset.y + pixelSpeed)];
            _snapshot.center = CGPointMake(_snapshot.center.x, _snapshot.center.y + pixelSpeed);
        }
    }
    
    /*  当把截图拖动到边缘，开始自动滚动，如果这时手指完全不动，则不会触发‘UIGestureRecognizerStateChanged’，对应的代码就不会执行，导致虽然截图在tableView中的位置变了，但并没有移动那个隐藏的cell，用下面代码可解决此问题，cell会随着截图的移动而移动
     */
    _relocatedIndexPath = [self.tableView indexPathForRowAtPoint:_snapshot.center];
    if (_relocatedIndexPath && ![_relocatedIndexPath isEqual:_originalIndexPath]) {
//        [self cellRelocatedToNewIndexPath:_relocatedIndexPath];
    }
}

#pragma mark - Refresh
//重置数据源
- (void)resetScheduleDictionary
{
    [_timeArray removeAllObjects];
    [self.scheduleDict removeAllObjects];
    NSString *dateStr = @"2017-8-8 00:00:00";
    NSDate *zeroDate = [NSDate fjs_dateFromString:dateStr];
    
    //创建时间
    NSTimeInterval tenMinTimeInterval = 10 * 60;
    for (NSInteger i = 0; i < 24*6; i++) {
        NSDate *date = [NSDate dateWithTimeInterval:+tenMinTimeInterval * i sinceDate:zeroDate];
        NSString *key = [date fjs_dateInFormat:@"HH:mm"];
        [self.timeArray addObject:key];
        [_scheduleDict setObject:[NSMutableArray array] forKey:key];
    }
}

#pragma mark - Setter
//外部调用
- (void)setDailySchedules:(NSMutableArray *)schedules
{
    //切换日期的时候滚动到9:00位置
    EMScheduleModel *oldSchedule = self.schedules.firstObject;
    EMScheduleModel *newSchedule = schedules.firstObject;
    NSString *oldDate = oldSchedule ? oldSchedule.date : @"";
    NSString *newDate = newSchedule ? newSchedule.date : @"";
    BOOL isScroll = ![oldDate isEqualToString:newDate];
    
    self.schedules = schedules;
    if (schedules && schedules.count > 0 && isScroll) {
        NSUInteger index = [self.timeArray indexOfObject:@"09:00"];
        NSIndexPath *indexPath = [NSIndexPath indexPathForRow:index-1 inSection:0];
        [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionTop animated:NO];
    }
}

- (void)setSchedules:(NSMutableArray *)schedules
{
    _schedules = schedules;
    
    if (_schedules && _schedules.count > 0) {
        [self resetScheduleDictionary];
        self.noScheduleView.hidden = YES;
        for (EMScheduleModel *model in schedules) {
            NSMutableArray *timeScheduleArray = self.scheduleDict[model.startTime];
            if (timeScheduleArray.count > 0) {
                //如果当前时间有超过一个日程，timeArray添加多一条时间
                NSInteger index = [self.timeArray indexOfObject:model.startTime];
                [self.timeArray insertObject:model.startTime atIndex:index];
            }
            [timeScheduleArray addObject:model];
        }
        [self.tableView reloadData];
    } else {
        [self.timeArray removeAllObjects];
        self.noScheduleView.hidden = NO;
        [self.tableView reloadData];
    }
    
}

#pragma mark - Getter
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [UITableView new];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        [self addSubview:_tableView];
        
        UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc]initWithTarget:self action:@selector(longPressGestureRecognized:)];
        [_tableView addGestureRecognizer:longPress];
    }
    return _tableView;
}

- (UIView *)noScheduleView
{
    if (!_noScheduleView) {
        _noScheduleView = [[UIView alloc] initWithFrame:self.bounds];
        [self addSubview:_noScheduleView];
        
        UIImageView *timeLineView = [[UIImageView alloc] initWithFrame:CGRectMake(75, 35, 11, 360)];
        timeLineView.image = [UIImage imageNamed:@"plan_time_dot"];
        [_noScheduleView addSubview:timeLineView];
        
        UILabel *zeroLabel = [UILabel new];
        zeroLabel.text = @"00:00";
        zeroLabel.font = [UIFont systemFontOfSize:14];
        zeroLabel.textAlignment = NSTextAlignmentCenter;
        [_noScheduleView addSubview:zeroLabel];
        
        [zeroLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(timeLineView.mas_top).with.offset(5);
            make.width.equalTo(@75);
            make.left.equalTo(@0);
        }];
        
        UILabel *nineLabel = [UILabel new];
        nineLabel.text = @"09:00";
        nineLabel.font = [UIFont systemFontOfSize:14];
        nineLabel.textAlignment = NSTextAlignmentCenter;
        [_noScheduleView addSubview:nineLabel];
        
        [nineLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(timeLineView.mas_top).with.offset(5 +88);
            make.width.equalTo(@75);
            make.left.equalTo(@0);
        }];
        
        UILabel *twelveLabel = [UILabel new];
        twelveLabel.text = @"12:00";
        twelveLabel.font = [UIFont systemFontOfSize:14];
        twelveLabel.textAlignment = NSTextAlignmentCenter;
        [_noScheduleView addSubview:twelveLabel];
        
        [twelveLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(timeLineView.mas_top).with.offset(5+88+80);
            make.width.equalTo(@75);
            make.left.equalTo(@0);
        }];
        
        UILabel *sixteenLabel = [UILabel new];
        sixteenLabel.text = @"18:00";
        sixteenLabel.font = [UIFont systemFontOfSize:14];
        sixteenLabel.textAlignment = NSTextAlignmentCenter;
        [_noScheduleView addSubview:sixteenLabel];
        
        [sixteenLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(timeLineView.mas_top).with.offset(5+88+80+88);
            make.width.equalTo(@75);
            make.left.equalTo(@0);
        }];
        
        UILabel *twentyFourLabel = [UILabel new];
        twentyFourLabel.text = @"24:00";
        twentyFourLabel.font = [UIFont systemFontOfSize:14];
        twentyFourLabel.textAlignment = NSTextAlignmentCenter;
        [_noScheduleView addSubview:twentyFourLabel];
        
        [twentyFourLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(timeLineView.mas_top).with.offset(5+88+80+88+90);
            make.width.equalTo(@75);
            make.left.equalTo(@0);
        }];
        
        UIImageView *tipImageView = [UIImageView new];
        tipImageView.image = [UIImage imageNamed:@"icon_nojob"];
        [_noScheduleView addSubview:tipImageView];
        
        [tipImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@132);
            make.right.equalTo(@(-80));
            make.size.mas_equalTo(CGSizeMake(124, 90));
        }];
        
        UILabel *tipLabel = [UILabel new];
        tipLabel.text = @"暂无日程安排";
        tipLabel.font = [UIFont systemFontOfSize:14];
        tipLabel.textColor = UIColorFromHex(0x666666);
        tipLabel.textAlignment = NSTextAlignmentCenter;
        [_noScheduleView addSubview:tipLabel];
        
        [tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(tipImageView.mas_bottom).with.offset(10);
            make.width.equalTo(tipImageView);
            make.left.equalTo(tipImageView);
        }];

    }
    return _noScheduleView;
}

- (NSMutableArray *)timeArray
{
    if (!_timeArray) {
        _timeArray = [NSMutableArray array];
    }
    return _timeArray;
}

- (NSMutableDictionary *)scheduleDict
{
    if (!_scheduleDict) {
        _scheduleDict = [NSMutableDictionary dictionary];
        
    }
    return _scheduleDict;
}

@end
