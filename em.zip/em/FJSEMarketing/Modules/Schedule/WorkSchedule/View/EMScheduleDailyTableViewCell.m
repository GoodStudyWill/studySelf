//
//  EMScheduleDailyTableViewCell.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/9.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleDailyTableViewCell.h"
#import "EMScheduleModel.h"
#import "EMScheduleConstant.h"
#import "EMNotificationCenter.h"

typedef NS_ENUM(NSUInteger, EMScheduleDailyType) {
    EMScheduleDailyTypeKeyTime,     //关键节点时间，00:00, 09:00, 12:00, 18:00
    EMScheduleDailyTypeOnTime,      //除了关键节点时间外的整点
    EMScheduleDailyTypeOther,       //非整点
};


@interface EMScheduleDailyTableViewCell ()

@property (weak, nonatomic) IBOutlet UILabel *companyLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UIImageView *typeIcon;
@property (weak, nonatomic) IBOutlet UIView *lineView;
@property (weak, nonatomic) IBOutlet UIImageView *appraiseIcon;

@end

@implementation EMScheduleDailyTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    if (selected && [self.model.appraiseIsRead isEqualToString:@"0"]) {
        self.model.appraiseIsRead = @"1";
        [self.model update];
        [[EMNotificationCenter sharedInstance] postAppraiseNotification:self.model];
        
        self.appraiseIcon.hidden = YES;
    }
}

- (void)setModel:(EMScheduleModel *)model
{
    _model = model;
    
    self.timeLabel.text = _model.startTime;
    self.smallTimeLabel.text = _model.startTime;
    
    EMScheduleDailyType type = [self getTypeFromSchedule:_model];
    self.timeLabel.hidden = type == EMScheduleDailyTypeOther;
    self.typeIcon.hidden = type == EMScheduleDailyTypeOther;
    self.typeIcon.image = type == EMScheduleDailyTypeKeyTime ? [UIImage imageNamed:@"icon_time_graydot_big"] : [UIImage imageNamed:@"icon_time_graydot"];
    self.appraiseIcon.hidden = ![model.appraiseIsRead isEqualToString:@"0"];
    
    if (_model.scheduleId && _model.scheduleId.length > 0) {
        //如果计划有内容
        BOOL isDone = _model.status.integerValue == EMScheduleStatusDone || _model.status.integerValue == EMScheduleStatusUnhandled;
        UIColor *companyColor = isDone ? UIColorFromHex(0x999999) : [UIColor blackColor];
        if (isDone) {
            self.typeIcon.image = type == EMScheduleDailyTypeKeyTime ? [UIImage imageNamed:@"icon_time_graydot_big"] : [UIImage imageNamed:@"icon_time_graydot"];
        }
        
        self.companyLabel.textColor = companyColor;
        self.lineView.height = 48;
        [self setupIcon:_model];
        
        NSString *companyName = _model.agencyCompanyName;
        if (!companyName || companyName.length == 0) {
            companyName = _model.matter;
        }
        else if (companyName.length > 10) {
            NSString *frontStr = [companyName substringToIndex:5];
            NSString *backStr = [companyName substringFromIndex:companyName.length-5];
            companyName = [NSString stringWithFormat:@"%@...%@", frontStr, backStr];
        }
        self.companyLabel.text = companyName;
    } else {
        self.companyLabel.text = @"";
        self.lineView.height = type == EMScheduleDailyTypeOther ? 9 : 48;
    }
}

- (BOOL)isKeyTime:(EMScheduleModel *)model
{
    NSString *time = model.startTime;
    NSArray *timeCompArray = [time componentsSeparatedByString:@":"];
    BOOL isKeyTime = [timeCompArray.lastObject isEqualToString:@"00"];
    return isKeyTime;
}

- (EMScheduleDailyType)getTypeFromSchedule:(EMScheduleModel *)schedule
{
    EMScheduleDailyType type = EMScheduleDailyTypeOther;
    NSString *time = schedule.startTime;
    NSArray *timeCompArray = [time componentsSeparatedByString:@":"];
    if ([timeCompArray.lastObject isEqualToString:@"00"]) {
        type = EMScheduleDailyTypeOnTime;
        
        BOOL isKeyTime = [timeCompArray.firstObject isEqualToString:@"00"] || [timeCompArray.firstObject isEqualToString:@"09"] || [timeCompArray.firstObject isEqualToString:@"12"] || [timeCompArray.firstObject isEqualToString:@"18"];
        if (isKeyTime) {
            type = EMScheduleDailyTypeKeyTime;
        }
    }
    return type;
}

- (void)setupIcon:(EMScheduleModel *)schedule
{
    EMScheduleDailyType type = [self getTypeFromSchedule:_model];
    NSString *iconName = @"icon_time_reddot";
    switch (schedule.scheduleType.integerValue) {
        case EMScheduleTypeExploit:
        {
            iconName = type == EMScheduleDailyTypeKeyTime ? @"icon_time_red_big" : @"icon_time_reddot";
        }
            break;
            
        case EMScheduleTypeMaintain:
        {
            iconName = type == EMScheduleDailyTypeKeyTime ? @"icon_time_yellow_big" : @"icon_time_ryellowdot";
        }
            break;
            
        case EMScheduleTypeOther:
        {
            iconName = type == EMScheduleDailyTypeKeyTime ? @"icon_time_blue_big" : @"icon_time_rbluedot";
        }
            break;
    }
    
    self.typeIcon.image = [UIImage imageNamed:iconName];
}

- (void)setShowTime:(BOOL)showTime
{
    _showTime = showTime;
    self.timeLabel.hidden = !showTime;
    self.typeIcon.hidden = !showTime;
    self.lineView.height = 48;
}

- (void)setLine:(EMScheduleDailyLineType)type
{
    switch (type) {
        case EMScheduleDailyLineTypeFirst:
        {
            self.lineView.y = 24;
            self.lineView.height = 24;
        }
            break;
            
        case EMScheduleDailyLineTypeLastHasTime:
        {
            self.lineView.height = 24;
        }
            break;
            
        case EMScheduleDailyLineTypeLastNoTime:
        {
            self.lineView.height = 0;
        }
            break;
    }
}

- (void)clearInfo
{
    self.companyLabel.text = @"";
    self.typeIcon.hidden = [self isKeyTime:self.model];
}

- (void)appraise
{
    self.appraiseIcon.hidden = [self.model.appraiseIsRead isEqualToString:@"1"];
}

@end
