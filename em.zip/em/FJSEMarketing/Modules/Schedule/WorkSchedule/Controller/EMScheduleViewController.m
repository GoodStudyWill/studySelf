//
//  EMScheduleViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/14.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleViewController.h"
#import "JTCalendar.h"
#import "EMScheduleService.h"
#import "NSDate+FJSExtension.h"
#import "EMScheduleTableViewCell.h"
#import "EMScheduleModel.h"
#import "EMScheduleDailyView.h"
#import "EMNotificationCenter.h"
#import "FJSWebViewController.h"

@interface EMScheduleViewController ()<JTCalendarDelegate, UITableViewDataSource, UITableViewDelegate, EMScheduleServiceDelegate, EMScheduleViewDelegate, EMScheduleDailyViewDelegate>

@property (nonatomic, strong) EMScheduleService *service;

@property (weak, nonatomic) IBOutlet JTHorizontalCalendarView *calendarView;

@property (nonatomic, strong) JTCalendarManager *calendarManager;

@property (nonatomic, strong) EMScheduleView *scheduleView;
@property (nonatomic, strong) EMScheduleDailyView *dailyView;

@property (nonatomic, strong) NSDate *dateSelected;
@property (nonatomic, strong) NSDate *weekDateSelected;
@property (nonatomic, strong) NSDate *monthDateSelected;
@property (nonatomic, strong) NSDate *todayDate;
@property (nonatomic, strong) NSDate *minDate;
@property (nonatomic, strong) NSDate *maxDate;
@property (nonatomic, strong) NSMutableDictionary *eventsByDate;

@property (nonatomic, strong) NSDate *monthDate;

@property (nonatomic, strong) UITableView *weekScheduleTableView;
@property (nonatomic, strong) UITableView *monthScheduleTableView;

@property (nonatomic, strong) NSArray *weekSchedules;
@property (nonatomic, strong) NSArray *monthSchedules;
@property (nonatomic, strong) NSDictionary *monthScheduleDic;

@property (nonatomic, copy) NSString *dayDate;
@property (nonatomic, copy) NSString *monthDayDate;

@property (nonatomic, strong) NSDate *fromDate;
@property (nonatomic, strong) NSDate *toDate;

@property (nonatomic, strong) UIView *noWeekScheduleView;
@property (nonatomic, strong) UIView *noMonthScheduleView;

@end

@implementation EMScheduleViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
//    self.trackName = @"工作计划";
    self.monthDateSelected = [NSDate date];
    [self addNotification];
    [self.service getAllSchdulesEvent];
    self.view.backgroundColor = [UIColor clearColor];
    self.view.userInteractionEnabled = YES;
    [self layoutConstraints];
    [self setupCalendar];
    [self refreshViewInto:self.type];
    
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

#pragma mark - UI
- (void)layoutConstraints
{
    [self.view addSubview:self.dailyView];
    [self.view addSubview:self.weekScheduleTableView];
    [self.view addSubview:self.monthScheduleTableView];
    self.noWeekScheduleView.hidden = YES;
    self.noMonthScheduleView.hidden = YES;
    self.calendarView.width = SCREEN_WIDTH-20;
    
    [self.view addSubview:self.scheduleView];
    
    [self.dailyView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@62);
        make.left.equalTo(@0);
        make.width.equalTo(self.scheduleView);
        make.bottom.equalTo(self.scheduleView.mas_bottom).with.offset(-5);
    }];
    
    [self.weekScheduleTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@162);
        make.width.equalTo(self.scheduleView);
        make.bottom.equalTo(self.scheduleView.mas_bottom).with.offset(-5);
    }];
    
    [self.monthScheduleTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@362);
        make.width.equalTo(self.scheduleView);
        make.bottom.equalTo(self.scheduleView.mas_bottom).with.offset(-5);
    }];
    
}

- (void)setupCalendar
{
    self.calendarView.userInteractionEnabled = YES;
    _calendarManager = [JTCalendarManager new];
    _calendarManager.delegate = self;
    
    _calendarManager.settings.weekModeEnabled = YES;
    _calendarManager.settings.weekDayFormat = JTCalendarWeekDayFormatSingle;
    _calendarManager.dateHelper.calendar.locale = [NSLocale localeWithLocaleIdentifier:@"zh_CN"];
    _calendarManager.dateHelper.calendar.firstWeekday = 2;
    
    // Create a min and max date for limit the calendar, optional
    [self createMinAndMaxDate];
    
    NSDate *firstDate = [_calendarManager.dateHelper firstWeekDayOfWeek:_todayDate];
    FJSLog(@"firstDateOfWeek => %@", firstDate);
    
    NSTimeInterval oneDay = 24 * 60 * 60;
    NSDate *thursdayDate = [NSDate dateWithTimeInterval:+oneDay*3 sinceDate:firstDate];
    FJSLog(@"thursdayDate => %@", thursdayDate);
    
    [_calendarManager setMenuView:nil];
    [_calendarManager setContentView:self.calendarView];
    [_calendarManager setDate:thursdayDate];
}

- (void)setFrame:(CGRect)frame
{
    self.view.frame = frame;
    self.scheduleView.frame = frame;
}

#pragma mark - Observer
- (void)addNotification
{
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshSchedule:) name:@"refreshSchedule" object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(scheduleDidRecieveNewComment:) name:EMNotificationCenterNewScheduleComment object:nil];
    });
}

- (void)refreshSchedule:(NSNotification *)noti
{
    FJSLog(@"refreshSchedule...");
    NSString *date = (NSString *)noti.object;
    [self.service getAllSchdulesEvent];
    [self refreshScheudleWithDate:date];
}

- (void)scheduleDidRecieveNewComment:(NSNotification *)noti
{
    NSDictionary *scheduleInfo = noti.userInfo;
    NSString *scheduleDate = scheduleInfo[EMNotificationCenterKeyScheduleDate];
    
    [self refreshScheudleWithDate:scheduleDate];
}

- (void)refreshScheudleWithDate:(NSString *)date
{
    switch (self.type) {
        case EMScheduleViewTypeDay:
        {
            if (![date isEqualToString:self.dayDate]) {
                return;
            }
            
            [self.service getScheduleFor:date];
        }
            break;
            
        case EMScheduleViewTypeWeek:
        {
            NSDate *completeDate = [NSDate fjs_dateFromString:date inFormat:@"yyyy-MM-dd"];
            NSComparisonResult fromResult = [completeDate compare:self.fromDate];
            NSComparisonResult toResult = [completeDate compare:self.toDate];
            BOOL isInWeek = fromResult != NSOrderedAscending && toResult != NSOrderedDescending;
            if (!isInWeek) {
                return;
            }
            
            [self.service getSchedulesFrom:[self.fromDate fjs_dateInFormat:@"yyyy-MM-dd"] to:[self.toDate fjs_dateInFormat:@"yyyy-MM-dd"]];
        }
            break;
            
        case EMScheduleViewTypeMonth:
        {
            if (![date isEqualToString:self.monthDayDate]) {
                return;
            }
            
            [self.service getScheduleForMonthDay:date];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - Change view
- (void)changeViewInto:(EMScheduleViewType)type
{
    if (self.type == type) {
        return;
    }
    
    self.monthDateSelected = [NSDate date];
    
    [self refreshViewInto:type];
}

- (void)refreshViewInto:(EMScheduleViewType)type
{
    self.noWeekScheduleView.hidden = YES;
    self.noMonthScheduleView.hidden = YES;
    
    self.type = type;
    switch (type) {
        case EMScheduleViewTypeDay:
        {
            self.dailyView.hidden = NO;
            self.calendarView.hidden = YES;
            self.weekScheduleTableView.hidden = YES;
            self.monthScheduleTableView.hidden = YES;
            
            self.dayDate = [_todayDate fjs_dateInFormat:@"yyyy-MM-dd"];
            [self.service getScheduleFor:self.dayDate];
        }
            break;
            
        case EMScheduleViewTypeWeek:
        {
            self.calendarView.hidden = NO;
            self.calendarView.height = 100;
            self.weekScheduleTableView.hidden = NO;
            self.dailyView.hidden = YES;
            self.monthScheduleTableView.hidden = YES;
            self.calendarManager.settings.weekModeEnabled = YES;
            [self.calendarManager reload];
            
            NSDate *firstDate = [_calendarManager.dateHelper firstWeekDayOfWeek:[NSDate date]];
            NSTimeInterval oneDay = 24 * 60 * 60;
            NSDate *lastWeekDate = [NSDate dateWithTimeInterval:+oneDay*6 sinceDate:firstDate];
            self.fromDate = firstDate;
            self.toDate = lastWeekDate;
            [self.service getSchedulesFrom:[firstDate fjs_dateInFormat:@"yyyy-MM-dd"] to:[lastWeekDate fjs_dateInFormat:@"yyyy-MM-dd"]];
            _dateSelected = _todayDate;
            
            NSDate *thursdayDate = [NSDate dateWithTimeInterval:+oneDay*3 sinceDate:firstDate];
            [self.calendarManager setDate:thursdayDate];
            
        }
            break;
            
        case EMScheduleViewTypeMonth:
        {
            self.calendarView.hidden = NO;
            self.calendarView.height = 300;
            self.weekScheduleTableView.hidden = YES;
            self.dailyView.hidden = YES;
            self.monthScheduleTableView.hidden = NO;
            self.calendarManager.settings.weekModeEnabled = NO;
            self.calendarManager.settings.pageViewNumberOfWeeks = 0;
            [self.calendarManager reload];
            
            self.monthDayDate = [_todayDate fjs_dateInFormat:@"yyyy-MM-dd"];
            [self.service getScheduleForMonthDay:self.monthDayDate];
            [self.calendarManager setDate:_todayDate];
            _dateSelected = _todayDate;
            _monthDateSelected = _todayDate;
        }
            break;
    }
    [self setHeader];
}

- (void)setHeader
{
    NSString *title = nil;
    switch (self.type) {
        case EMScheduleViewTypeDay:
        {
            title = [NSDate fjs_todayInFormat:@"yyyy年M月d日"];
        }
            break;
            
        case EMScheduleViewTypeWeek:
        {
            title = [self titleOfThisWeek];
        }
            break;
            
        case EMScheduleViewTypeMonth:
        {
            title = [NSDate fjs_todayInFormat:@"yyyy年M月"];
        }
            break;
    }
    
    [self.scheduleView setHeaderTitle:title type:self.type];
}

- (NSString *)titleOfThisWeek
{
    NSDate *firstDate = [_calendarManager.dateHelper firstWeekDayOfWeek:[NSDate date]];
    FJSLog(@"firstDateOfWeek => %@", firstDate);
    
    NSUInteger numOfWeek = [_calendarManager.dateHelper numberOfWeeks:firstDate];
    FJSLog(@"numOfWeek => %lu", numOfWeek);
    
    NSTimeInterval oneDay = 24 * 60 * 60;
    NSDate *lastWeekDate = [NSDate dateWithTimeInterval:+oneDay*6 sinceDate:firstDate];
    NSString *lastDateString = [lastWeekDate fjs_dateInFormat:@"yyyy-M-d"];
    NSArray *lastDateArr = [lastDateString componentsSeparatedByString:@"-"];
    NSInteger lastYear = [lastDateArr.firstObject integerValue];
    NSInteger lastMonth = [lastDateArr[1] integerValue];
    NSInteger lastDay = [lastDateArr.lastObject integerValue];
    
    NSString *title = nil;
    if (lastDay <= 7 && lastDay >= 4) {
        title = [NSString stringWithFormat:@"%ld年%ld月 第一周", lastYear, lastMonth];
    } else {
        NSString *firstDateString = [firstDate fjs_dateInFormat:@"yyyy-M-d"];
        NSArray *dateArr = [firstDateString componentsSeparatedByString:@"-"];
        NSInteger firstYear = [dateArr.firstObject integerValue];
        NSInteger firstMonth = [dateArr[1] integerValue];
        NSInteger firstDay = [dateArr.lastObject integerValue];
        NSInteger addition = 0;
        if (firstDay % 7 <= 4) {
            addition =  1;
        } else {
            addition = 2;
        }
        NSInteger week = firstDay / 7 + addition;
        
        NSArray *chineseNumArray = @[@"一", @"二", @"三", @"四", @"五", @"六"];
        title = [NSString stringWithFormat:@"%ld年%ld月 第%@周", firstYear, firstMonth, chineseNumArray[week-1]];
    }
    return title;
}


#pragma mark - JTCalendarDelegate
- (void)calendar:(JTCalendarManager *)calendar prepareDayView:(JTCalendarDayView *)dayView
{
    dayView.textLabel.font = [UIFont systemFontOfSize:14];
    
    if (self.type == EMScheduleViewTypeWeek) {
        [self calendar:calendar prepareWeekTypeDayView:dayView];
    }
    
    else if (self.type == EMScheduleViewTypeMonth) {
        [self calendar:calendar prepareMonthTypeDayView:dayView];
    }
}

- (void)calendar:(JTCalendarManager *)calendar didTouchDayView:(JTCalendarDayView *)dayView
{
    _monthDateSelected = dayView.date;
    
    // Animation for the circleView
    dayView.circleView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.1, 0.1);
    [UIView transitionWithView:dayView
                      duration:.3
                       options:0
                    animations:^{
                        dayView.circleView.transform = CGAffineTransformIdentity;
                        [_calendarManager reload];
                    } completion:nil];
    
    
    // Don't change page in week mode because block the selection of days in first and last weeks of the month
    if(_calendarManager.settings.weekModeEnabled){
        return;
    }
    
    [EMHudManager showLoadingWithText:nil inView:self.scheduleView];

    self.monthDayDate = [_monthDateSelected fjs_dateInFormat:@"yyyy-MM-dd"];
    [self.service getScheduleForMonthDay:self.monthDayDate];
    
    // Load the previous or next page if touch a day from another month
    
    if(![_calendarManager.dateHelper date:_calendarView.date isTheSameMonthThan:dayView.date]){
        if([_calendarView.date compare:dayView.date] == NSOrderedAscending){
            [_calendarView loadNextPageWithAnimation];
        }
        else{
            [_calendarView loadPreviousPageWithAnimation];
        }
    }
}

#pragma mark - Set calendar UI
//设置周视图日历UI
- (void)calendar:(JTCalendarManager *)calendar prepareWeekTypeDayView:(JTCalendarDayView *)dayView
{
    dayView.dotView.hidden = YES;
    //今天
    if([_calendarManager.dateHelper date:[NSDate date] isTheSameDayThan:dayView.date]){
        dayView.circleView.hidden = NO;
        dayView.circleView.backgroundColor = UIColorFromHex(0x00a0ea);
        dayView.textLabel.textColor = [UIColor whiteColor];
    }
    
    
    //其他月份
    else if(![_calendarManager.dateHelper date:_calendarView.date isTheSameMonthThan:dayView.date]){
        dayView.circleView.hidden = YES;
        dayView.textLabel.textColor = UIColorFromHex(0xcccccc);
    }
    
    // Another day of the current month
    else{
        dayView.circleView.hidden = YES;
        dayView.textLabel.textColor = [UIColor blackColor];
    }
}

//设置月视图日历UI
- (void)calendar:(JTCalendarManager *)calendar prepareMonthTypeDayView:(JTCalendarDayView *)dayView
{
    //选中的日期
    if(_monthDateSelected && [_calendarManager.dateHelper date:_monthDateSelected isTheSameDayThan:dayView.date]){
        dayView.circleView.hidden = NO;
        dayView.circleView.backgroundColor = UIColorFromHex(0x00a0ea);
        dayView.dotView.backgroundColor = [UIColor whiteColor];
        dayView.textLabel.textColor = [UIColor whiteColor];
    }
    
    //今天
    else if([_calendarManager.dateHelper date:[NSDate date] isTheSameDayThan:dayView.date]){
        dayView.circleView.hidden = NO;
        dayView.circleView.backgroundColor = [UIColor whiteColor];
        dayView.textLabel.textColor = UIColorFromHex(0x00a0ea);
        dayView.dotView.backgroundColor = UIColorFromHex(0x00a0ea);
    }
    
    //其他月份
    else if(![_calendarManager.dateHelper date:_calendarView.date isTheSameMonthThan:dayView.date]){
        dayView.circleView.hidden = YES;
        dayView.dotView.backgroundColor = UIColorFromHex(0xcccccc);
        dayView.textLabel.textColor = UIColorFromHex(0xcccccc);
    }
    
    // Another day of the current month
    else{
        dayView.circleView.hidden = YES;
        dayView.dotView.backgroundColor =  UIColorFromHex(0xcccccc);
        dayView.textLabel.textColor = [UIColor blackColor];
    }
    
    if([self haveEventForDay:dayView.date]){
        dayView.dotView.hidden = NO;
    }
    else{
        dayView.dotView.hidden = YES;
    }
}


#pragma mark - CalendarManager delegate - Page mangement
// Used to limit the date for the calendar, optional
- (BOOL)calendar:(JTCalendarManager *)calendar canDisplayPageWithDate:(NSDate *)date
{
    return [_calendarManager.dateHelper date:date isEqualOrAfter:_minDate andEqualOrBefore:_maxDate];
}

- (void)calendarDidLoadNextPage:(JTCalendarManager *)calendar
{
    FJSLog(@"Next page loaded, date=>%@", calendar.date);
    [self setupScheduleHeaderWithDate:calendar.date];
}

- (void)calendarDidLoadPreviousPage:(JTCalendarManager *)calendar
{
    FJSLog(@"Previous page loaded, date=>%@", calendar.date);
    [self setupScheduleHeaderWithDate:calendar.date];
}

#pragma mark - Schedule header
- (void)setupScheduleHeaderWithDate:(NSDate *)date
{
    if (self.type == EMScheduleViewTypeMonth) {
        self.monthDayDate = [date fjs_dateInFormat:@"yyyy-MM-dd"];
        [self.scheduleView setHeaderTitle:[date fjs_dateInFormat:@"yyyy年M月"] type:EMScheduleViewTypeMonth];
        [self setupMonthCalendarHeightWithDate:date];
    }
    
    if (self.type == EMScheduleViewTypeWeek) {
        [self setupWeekScheduleWithDate:date];
    }
}

- (void)setupWeekScheduleWithDate:(NSDate *)date
{
    NSDate *firstDate = [_calendarManager.dateHelper firstWeekDayOfWeek:date];
    self.fromDate = firstDate;
    FJSLog(@"firstDateOfWeek => %@", firstDate);
    
    NSUInteger numOfWeek = [_calendarManager.dateHelper numberOfWeeks:firstDate];
    FJSLog(@"numOfWeek => %lu", numOfWeek);
    
    NSTimeInterval oneDay = 24 * 60 * 60;
    NSDate *lastWeekDate = [NSDate dateWithTimeInterval:+oneDay*6 sinceDate:firstDate];
    self.toDate = lastWeekDate;
    NSString *lastDateString = [lastWeekDate fjs_dateInFormat:@"yyyy-M-d"];
    NSArray *lastDateArr = [lastDateString componentsSeparatedByString:@"-"];
    NSInteger lastYear = [lastDateArr.firstObject integerValue];
    NSInteger lastMonth = [lastDateArr[1] integerValue];
    NSInteger lastDay = [lastDateArr.lastObject integerValue];
    
    NSArray *chineseNumArray = @[@"一", @"二", @"三", @"四", @"五", @"六"];
    
    NSString *title = nil;
    if (lastDay <= 7 && lastDay >= 4) {
        title = [NSString stringWithFormat:@"%ld年%ld月 第一周", lastYear, lastMonth];
        _monthDate = lastWeekDate;
    } else {
        NSString *firstDateString = [firstDate fjs_dateInFormat:@"yyyy-M-d"];
        NSArray *dateArr = [firstDateString componentsSeparatedByString:@"-"];
        NSInteger firstYear = [dateArr.firstObject integerValue];
        NSInteger firstMonth = [dateArr[1] integerValue];
        NSInteger firstDay = [dateArr.lastObject integerValue];
        NSInteger addition = 0;
        if (firstDay % 7 <= 4) {
            addition =  1;
        } else {
            addition = 2;
        }
        NSInteger week = firstDay / 7 + addition;
        title = [NSString stringWithFormat:@"%ld年%ld月 第%@周", firstYear, firstMonth, chineseNumArray[week-1]];
        _monthDate = firstDate;
    }
    
    if (self.type == EMScheduleViewTypeWeek) {
        [self.scheduleView setHeaderTitle:title type:EMScheduleViewTypeWeek];
    }
    
    [EMHudManager showLoadingWithText:nil inView:self.scheduleView];
    [self.service getSchedulesFrom:[firstDate fjs_dateInFormat:@"yyyy-MM-dd"] to:[lastWeekDate fjs_dateInFormat:@"yyyy-MM-dd"]];
    FJSLog(@"lastDateOfWeek => %@", lastWeekDate);
}

- (void)setupMonthCalendarHeightWithDate:(NSDate *)date
{
    NSUInteger numberOfWeeks = [_calendarManager.dateHelper numberOfWeeks:date];
    
    if (numberOfWeeks == 6) {
        self.calendarView.height = 300;
        
        [self.monthScheduleTableView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@362);
            make.width.equalTo(self.scheduleView);
            make.bottom.equalTo(self.scheduleView.mas_bottom).with.offset(-5);
        }];
    } else {
        self.calendarView.height = 270;
        
        [self.monthScheduleTableView mas_remakeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@332);
            make.width.equalTo(self.scheduleView);
            make.bottom.equalTo(self.scheduleView.mas_bottom).with.offset(-5);
        }];
    }
}


#pragma mark - Set date
- (void)createMinAndMaxDate
{
    _todayDate = [NSDate date];
    
    _monthDate = _todayDate;
    
    //设置可以查到最远的时间
    _minDate = [_calendarManager.dateHelper addToDate:_todayDate months:-100];
    
    //设置可以查到最近的时间
    _maxDate = [_calendarManager.dateHelper addToDate:_todayDate months:100];
}

// Used only to have a key for _eventsByDate
- (NSDateFormatter *)dateFormatter
{
    static NSDateFormatter *dateFormatter;
    if(!dateFormatter){
        dateFormatter = [NSDateFormatter new];
        dateFormatter.dateFormat = @"yyyy-MM-dd";
    }
    
    return dateFormatter;
}

- (BOOL)haveEventForDay:(NSDate *)date
{
    NSString *key = [[self dateFormatter] stringFromDate:date];
    
    NSString *dateStr = self.monthScheduleDic[key];
    if (dateStr && dateStr.length > 0) {
        return YES;
    }
    
    return NO;
    
}

#pragma mark - EMScheduleServiceDelegate
- (void)service:(EMScheduleService *)service handleOneDaySchedules:(NSArray *)schedules
{
    [EMHudManager hideLoadingForView:self.scheduleView];
    [self.dailyView setDailySchedules:[schedules mutableCopy]];
}

- (void)service:(EMScheduleService *)service handlePeriodSchedules:(NSArray *)schedules
{
    [EMHudManager hideLoadingForView:self.scheduleView];
    self.weekSchedules = schedules;
    [self.weekScheduleTableView reloadData];
    
    BOOL isShowSchedules = schedules && schedules.count > 0;
    self.noWeekScheduleView.hidden = isShowSchedules;
    self.weekScheduleTableView.hidden = !isShowSchedules;
}

- (void)service:(EMScheduleService *)service handleMonthSchedules:(NSDictionary *)schedulesDic todaySchedules:(NSArray *)todaySchedules
{
    [EMHudManager hideLoadingForView:self.scheduleView];
    self.monthSchedules = todaySchedules;
    [self.monthScheduleTableView reloadData];
    
    BOOL isShowSchedules = todaySchedules && todaySchedules.count > 0;
    self.noMonthScheduleView.hidden = isShowSchedules;
    self.monthScheduleTableView.hidden = !isShowSchedules;
}

- (void)updateScheduleTime:(EMScheduleService *)service
{
    [EMHudManager hideLoadingForView:self.dailyView];
}

- (void)service:(EMScheduleService *)service handleAllSchedules:(NSDictionary *)allSchedules
{
    self.monthScheduleDic = allSchedules;
    [self.calendarManager reload];
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 30;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    EMScheduleTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    EMScheduleModel *schedule = cell.schedule;
    if (schedule.scheduleId && schedule.scheduleId.length > 0) {
        NSString *urlStr = [NSString stringWithFormat:@"%@%@", kEMHtmlURLSchedule, schedule.scheduleId];
        FJSWebViewController *webViewController = [[FJSWebViewController alloc] initWithUrlString:urlStr];
        [webViewController showLeftBarButtonItemWithImage:@"icon_back"];
        webViewController.hidesBottomBarWhenPushed = YES;
        [self.parentViewController.navigationController pushViewController:webViewController animated:YES];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    EMScheduleModel *model = nil;
    if (tableView == self.weekScheduleTableView) {
        NSArray *daySchedules = self.weekSchedules[section];
        model = daySchedules.firstObject;
    } else {
        model = self.monthSchedules.firstObject;
    }
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 355, 30)];
    headerView.backgroundColor = UIColorFromHex(0xf9f9f9);
    
    NSDate *date = [NSDate fjs_dateFromString:model.startDate inFormat:@"yyyy-MM-dd HH:mm"];
    UILabel *weekLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 100, 30)];
    weekLabel.text = [date fjs_weekDay];
    weekLabel.textColor = UIColorFromHex(0x999999);
    weekLabel.font = [UIFont systemFontOfSize:13];
    [headerView addSubview:weekLabel];
    
    UILabel *dayLabel = [[UILabel alloc] initWithFrame:CGRectMake(SCREEN_WIDTH-20-10-100, 0, 100, 30)];
    dayLabel.text = [date fjs_dateInFormat:@"M/d"];
    dayLabel.textAlignment = NSTextAlignmentRight;
    dayLabel.textColor = UIColorFromHex(0x999999);
    dayLabel.font = [UIFont systemFontOfSize:13];
    [headerView addSubview:dayLabel];
    
    if (tableView == self.monthScheduleTableView) {
        NSString *todayStr = [NSDate fjs_todayInFormat:@"M/d"];
        if ([todayStr isEqualToString:dayLabel.text]) {
            weekLabel.text = @"今日";
        }
    }
    
    return headerView;
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (tableView == self.weekScheduleTableView) {
        return self.weekSchedules.count;
    }
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.weekScheduleTableView) {
        NSArray *daySchedules = self.weekSchedules[section];
        return daySchedules.count;
    }

    return self.monthSchedules.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *scheduleCellIdentifier = @"ScheduleCell";
    EMScheduleTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:scheduleCellIdentifier];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"EMScheduleTableViewCell" owner:nil options:nil] lastObject];
    }
    
    if (tableView == self.weekScheduleTableView) {
        NSArray *daySchedules = self.weekSchedules[indexPath.section];
        cell.schedule = daySchedules[indexPath.row];
        
        return cell;
    } else {
        cell.schedule = self.monthSchedules[indexPath.row];
        return cell;
    }
    
    return nil;
}

#pragma mark - EMScheduleViewDelegate
- (void)selectNextButton
{
    switch (self.type) {
        case EMScheduleViewTypeDay:
        {
            NSDate *date = [NSDate fjs_dateFromString:self.dayDate inFormat:@"yyyy-MM-dd"];
            NSDate *nextDate = [NSDate dateWithTimeInterval:+24*60*60 sinceDate:date];
            self.dayDate = [nextDate fjs_dateInFormat:@"yyyy-MM-dd"];
            [self.service getScheduleFor:self.dayDate];
            [self.scheduleView setHeaderTitle:[nextDate fjs_dateInFormat:@"yyyy年M月d日"] type:EMScheduleViewTypeDay];
        }
            break;
            
        case EMScheduleViewTypeWeek:
        {
            NSDate *newDate =  [_calendarManager.date dateByAddingTimeInterval:60*60*24*7];
            [_calendarManager setDate:newDate];
            
            [self setupScheduleHeaderWithDate:newDate];
            
        }
            break;
            
        case EMScheduleViewTypeMonth:
        {
            NSDate *newDate =  [_calendarManager.date dateByAddingTimeInterval:60*60*24*30];
            [_calendarManager setDate:newDate];
            
            [self setupScheduleHeaderWithDate:newDate];
        }
            break;
    }
}

- (void)selectPreviousButton
{
    switch (self.type) {
        case EMScheduleViewTypeDay:
        {
            NSDate *date = [NSDate fjs_dateFromString:self.dayDate inFormat:@"yyyy-MM-dd"];
            NSDate *preDate = [NSDate dateWithTimeInterval:-24*60*60 sinceDate:date];
            self.dayDate = [preDate fjs_dateInFormat:@"yyyy-MM-dd"];
            [self.service getScheduleFor:self.dayDate];
            [self.scheduleView setHeaderTitle:[preDate fjs_dateInFormat:@"yyyy年M月d日"] type:EMScheduleViewTypeDay];
        }
            break;
            
        case EMScheduleViewTypeWeek:
        {
            NSDate *newDate =  [_calendarManager.date dateByAddingTimeInterval:-60*60*24*7];
            [_calendarManager setDate:newDate];
            
            [self setupScheduleHeaderWithDate:newDate];
            
        }
            break;
            
        case EMScheduleViewTypeMonth:
        {
            NSDate *newDate =  [_calendarManager.date dateByAddingTimeInterval:-60*60*24*30];
            [_calendarManager setDate:newDate];
            
            [self setupScheduleHeaderWithDate:newDate];
        }
            break;
    }
}

- (void)returnNow
{
    [self refreshViewInto:self.type];
}

#pragma mark - EMScheduleDailyViewDelegate
- (void)dailyViewUpdateScheduleTime:(EMScheduleModel *)schedule
{
    [EMHudManager showLoadingWithText:@"" inView:self.dailyView];
    [self.service updateScheduleTime:schedule];
}

- (void)dailyViewDidSelectSchedule:(EMScheduleModel *)schedule
{
    NSString *urlStr = [NSString stringWithFormat:@"%@%@", kEMHtmlURLSchedule, schedule.scheduleId];
    FJSWebViewController *webViewController = [[FJSWebViewController alloc] initWithUrlString:urlStr];
    [webViewController showLeftBarButtonItemWithImage:@"icon_back"];
    webViewController.hidesBottomBarWhenPushed = YES;
    [self.parentViewController.navigationController pushViewController:webViewController animated:YES];
}

#pragma mark - Getter
- (EMScheduleService *)service
{
    if (!_service) {
        _service = [[EMScheduleService alloc] init];
        _service.delegate = self;
    }
    return _service;
}

- (EMScheduleView *)scheduleView
{
    if (!_scheduleView) {
        __weak EMScheduleViewController *weakSelf = self;
        
        _scheduleView = [[EMScheduleView alloc] init];
        _scheduleView.delegate = self;
        _scheduleView.changeBlock = ^(EMScheduleViewType type) {
            [weakSelf changeViewInto:type];
        };
    }
    return _scheduleView;
}

- (EMScheduleDailyView *)dailyView
{
    if (!_dailyView) {
        _dailyView = [EMScheduleDailyView new];
        _dailyView.delegate = self;
    }
    return _dailyView;
}

- (UITableView *)weekScheduleTableView
{
    if (!_weekScheduleTableView) {
        _weekScheduleTableView = [UITableView new];
        _weekScheduleTableView.separatorColor = UIColorFromHex(0xdddddd);
        _weekScheduleTableView.delegate = self;
        _weekScheduleTableView.dataSource = self;
        _weekScheduleTableView.showsVerticalScrollIndicator = NO;
        _weekScheduleTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    }
    return _weekScheduleTableView;
}
- (UITableView *)monthScheduleTableView
{
    if (!_monthScheduleTableView) {
        _monthScheduleTableView = [UITableView new];
        _monthScheduleTableView.separatorColor = UIColorFromHex(0xdddddd);
        _monthScheduleTableView.delegate = self;
        _monthScheduleTableView.dataSource = self;
        _monthScheduleTableView.showsVerticalScrollIndicator = NO;
        _monthScheduleTableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    }
    return _monthScheduleTableView;
}

- (UIView *)noWeekScheduleView
{
    if (!_noWeekScheduleView) {
        _noWeekScheduleView  = [UIView new];
        [self.view addSubview:_noWeekScheduleView];
        
        UIImageView *tipImageView = [UIImageView new];
        tipImageView.image = [UIImage imageNamed:@"icon_nojob"];
        [_noWeekScheduleView addSubview:tipImageView];
        
        UILabel *tipLabel = [UILabel new];
        tipLabel.text = @"暂无日程安排";
        tipLabel.font = [UIFont systemFontOfSize:14];
        tipLabel.textColor = UIColorFromHex(0x666666);
        tipLabel.textAlignment = NSTextAlignmentCenter;
        [_noWeekScheduleView addSubview:tipLabel];
        
        [_noWeekScheduleView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.left.right.equalTo(self.weekScheduleTableView);
        }];
        
        [tipImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(@107);
            make.right.equalTo(@(-120));
            make.size.mas_equalTo(CGSizeMake(124, 90));
        }];
        
        [tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(tipImageView.mas_bottom).with.offset(10);
            make.width.equalTo(tipImageView);
            make.left.equalTo(tipImageView);
        }];
    }
    return _noWeekScheduleView;
}

- (UIView *)noMonthScheduleView
{
    if (!_noMonthScheduleView) {
        _noMonthScheduleView  = [UIView new];
        [self.view addSubview:_noMonthScheduleView];
        
        UIImageView *tipImageView = [UIImageView new];
        tipImageView.image = [UIImage imageNamed:@"icon_nojob"];
        [_noMonthScheduleView addSubview:tipImageView];
        
        UILabel *tipLabel = [UILabel new];
        tipLabel.text = @"暂无日程安排";
        tipLabel.font = [UIFont systemFontOfSize:14];
        tipLabel.textColor = UIColorFromHex(0x666666);
        tipLabel.textAlignment = NSTextAlignmentCenter;
        [_noMonthScheduleView addSubview:tipLabel];
        
        [_noMonthScheduleView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.bottom.left.right.equalTo(self.monthScheduleTableView);
        }];
        
        [tipImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(tipLabel.mas_top).with.offset(-10);
            make.right.equalTo(@(-120));
            make.size.mas_equalTo(CGSizeMake(124, 90));
        }];
        
        [tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.equalTo(@(-10));
            make.width.equalTo(tipImageView);
            make.left.equalTo(tipImageView);
        }];
    }
    return _noMonthScheduleView;
}

@end
