//
//  EMScheduleViewController.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/14.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EMScheduleView.h"

@interface EMScheduleViewController : UIViewController

@property (nonatomic, assign) EMScheduleViewType type;

- (void)setFrame:(CGRect)frame;

- (void)changeViewInto:(EMScheduleViewType)type;

- (void)refreshViewInto:(EMScheduleViewType)type;

@end
