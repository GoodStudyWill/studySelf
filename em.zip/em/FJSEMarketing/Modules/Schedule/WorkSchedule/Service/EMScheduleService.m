//
//  EMScheduleService.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/20.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleService.h"
#import "EMGetPeriodScheduleApi.h"
#import "EMGetMonthScheduleApi.h"
#import "EMGetDailyScheduleApi.h"
#import "EMScheduleModel.h"
#import "EMScheduleFashUpdateApi.h"
#import "EMGetUndoneSchedulesApi.h"
#import "EMScheduleConstant.h"
#import "NSDate+FJSExtension.h"
#import "FJSDateHelper.h"
#import "EMNotificationCenter.h"

//按时间段请求
static NSInteger const kGetScheduleTagPeriod    = 10001;
//按月请求
static NSInteger const kGetScheduleTagMonth     = 10002;
//请求比例
static NSInteger const kGetScheduleTagRatio     = 10003;

@interface EMScheduleService ()<FJSRequestDelegate>

@property (nonatomic, copy) NSString *monthSelectedDateStr;

@end

@implementation EMScheduleService

#pragma mark - Get schedules
//按天获取日程
- (void)getScheduleFor:(NSString *)date
{
    NSArray *scheduleArray = [self retrieveSchedulesFromDatabaseFrom:date to:date];
    if (!scheduleArray || scheduleArray.count == 0) {
        EMGetDailyScheduleApi *api = [[EMGetDailyScheduleApi alloc] initWithDate:date];
        api.delegate = self;
        [api start];
        return;
    }
    
    //数据库获取的数据是倒序排列的
//    NSArray *returnSchedules = [[scheduleArray reverseObjectEnumerator] allObjects];
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleOneDaySchedules:)]) {
        [self.delegate service:self handleOneDaySchedules:scheduleArray];
    }
}

//按时间段获取日程
- (void)getSchedulesFrom:(NSString *)startDate to:(NSString *)endDate
{
    NSArray *scheduleArray = [self retrieveSchedulesFromDatabaseFrom:startDate to:endDate];
    if (!scheduleArray || scheduleArray.count == 0) {
        EMGetPeriodScheduleApi *api = [[EMGetPeriodScheduleApi alloc] initWithStartDate:startDate endDate:endDate];
        api.tag = kGetScheduleTagPeriod;
        api.delegate = self;
        [api start];
        return;
    }
    
    //按天分类
    NSMutableArray *schedules = [NSMutableArray array];
    NSMutableArray *daySchedules = [NSMutableArray array];
    NSString *dateStr = @"";
    for (EMScheduleModel *model in scheduleArray) {
        if (![model.date isEqualToString:dateStr]) {
            dateStr = model.date;
            daySchedules = [NSMutableArray array];
            [schedules addObject:daySchedules];
        }
        [daySchedules addObject:model];
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handlePeriodSchedules:)]) {
        [self.delegate service:self handlePeriodSchedules:schedules];
    }
}

//按月获取日程
- (void)getScheduleForMonthDay:(NSString *)date
{
    NSArray *scheduleArray = [self retrieveSchedulesFromDatabaseFrom:date to:date];
    if (!scheduleArray || scheduleArray.count == 0) {
        EMGetMonthScheduleApi *api = [[EMGetMonthScheduleApi alloc] initWithDate:date];
        api.delegate = self;
        [api start];
        return;
    }
    
    //数据库获取的数据是倒序排列的
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleMonthSchedules:todaySchedules:)]) {
        [self.delegate service:self handleMonthSchedules:nil todaySchedules:scheduleArray];
    }
}

//从网络上获取待反馈日程
- (void)getUndoneSchedulesInNetwork
{
    EMGetUndoneSchedulesApi *api = [EMGetUndoneSchedulesApi new];
    api.delegate = self;
    [api start];
}

//获取待反馈日程
- (void)getUndoneSchedules
{
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *adcomps = [[NSDateComponents alloc] init];
    [adcomps setYear:0];
    [adcomps setMonth:-6];
    [adcomps setDay:0];
    NSDate *beforeDate = [calendar dateByAddingComponents:adcomps toDate:[NSDate date] options:0];
    NSString *beforeDateStr = [beforeDate fjs_dateInFormat:@"yyyy-MM-dd HH:mm"];
    
    NSArray *scheduleArray = [self retrieveReverseUndoneSchedulesFromDatabaseFrom:beforeDateStr to:[NSDate fjs_todayInFormat:@"yyyy-MM-dd HH:mm"]];
    if (!scheduleArray || scheduleArray.count == 0) {
        [self getUndoneSchedulesInNetwork];
        return;
    }
    
    //按天分类
    NSInteger count = 0;
    NSMutableArray *schedules = [NSMutableArray array];
    NSMutableArray *daySchedules = [NSMutableArray array];
    NSString *dateStr = @"";
    for (EMScheduleModel *model in scheduleArray) {
        if (![model.date isEqualToString:dateStr]) {
            dateStr = model.date;
            daySchedules = [NSMutableArray array];
        }
        if (model.status.integerValue == EMScheduleStatusUndone) {
            [daySchedules addObject:model];
            count++;
            if (![schedules containsObject:daySchedules]) {
                [schedules addObject:daySchedules];
            }
        }
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleUndoneSchedules:count:)]) {
        [self.delegate service:self handleUndoneSchedules:schedules count:count];
    }
    
}

//获取本月日程占比
- (void)getSchedulesRatioOfThisMonth
{
    NSDate *firstDateOfThisMonth = [FJSDateHelper firstDayOfMonth:[NSDate date]];
    NSDate *lastDateOfThisMonth = [FJSDateHelper lastDayOfMonth:[NSDate date]];
    NSString *firstDateStr = [firstDateOfThisMonth fjs_dateInFormat:@"yyyy-MM-dd"];
    NSString *lastDateStr = [lastDateOfThisMonth fjs_dateInFormat:@"yyyy-MM-dd"];
    
    NSArray *scheduleArray = [self retrieveSchedulesFromDatabaseFrom:firstDateStr to:lastDateStr];
    if (!scheduleArray || scheduleArray.count == 0) {
        EMGetPeriodScheduleApi *api = [[EMGetPeriodScheduleApi alloc] initWithStartDate:firstDateStr endDate:lastDateStr];
        api.tag = kGetScheduleTagRatio;
        api.delegate = self;
        [api start];
        return;
    }
    
    NSInteger exploitCount = 0;
    NSInteger maintainCount = 0;
    NSInteger otherCount = 0;
    for (EMScheduleModel *schedule in scheduleArray) {
        switch (schedule.scheduleType.integerValue) {
            case EMScheduleTypeExploit:
            {
                exploitCount++;
            }
                break;
                
            case EMScheduleTypeMaintain:
            {
                maintainCount++;
            }
                break;
                
            case EMScheduleTypeOther:
            {
                otherCount++;
            }
                break;
        }
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleMonthScheduleCountOfExploit:maintain:other:)]) {
        [self.delegate service:self handleMonthScheduleCountOfExploit:exploitCount maintain:maintainCount other:otherCount];
    }
}

- (void)getAllSchdulesEvent
{
    NSArray *scheduleArray = [EMScheduleModel retrieveAll];
    NSMutableDictionary *scheduleDic = [NSMutableDictionary dictionary];
    for (EMScheduleModel *schedule in scheduleArray) {
        [scheduleDic setObject:schedule.date forKey:schedule.date];
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleAllSchedules:)]) {
        [self.delegate service:self handleAllSchedules:scheduleDic];
    }
}

#pragma mark - SQL
///从数据库中查询数据，顺序排序
- (NSArray *)retrieveSchedulesFromDatabaseFrom:(NSString *)startDate to:(NSString *)endDate
{
    NSString *criteria = [NSString stringWithFormat:@"WHERE date >= '%@' AND date <= '%@' order by startDate", startDate, endDate];
    NSArray *dataArray = [EMScheduleModel retrieveByCriteria:criteria];
    return dataArray;
}

///从数据库中查询数据，倒序排序
- (NSArray *)retrieveReverseSchedulesFromDatabaseFrom:(NSString *)startDate to:(NSString *)endDate
{
    NSString *criteria = [NSString stringWithFormat:@"WHERE date >= '%@' AND date <= '%@'", startDate, endDate];
    NSArray *dataArray = [EMScheduleModel retrieveByCriteria:criteria];
    return dataArray;
}

///从数据库中查询待反馈日程，倒序
- (NSArray *)retrieveReverseUndoneSchedulesFromDatabaseFrom:(NSString *)startDate to:(NSString *)endDate
{
    NSString *criteria = [NSString stringWithFormat:@"WHERE startDate >= '%@' AND startDate <= '%@' order by startDate desc", startDate, endDate];
    NSArray *dataArray = [EMScheduleModel retrieveByCriteria:criteria];
    return dataArray;
}

- (NSArray *)retrieveAllScheduleEvent
{
    NSString *criteria = @"DISTINCT date";
    NSArray *dataArray = [EMScheduleModel retrieveByCriteria:criteria];
    return dataArray;
}

#pragma mark - Update schedule
- (void)updateScheduleTime:(EMScheduleModel *)schedule
{
    [schedule createOrUpdate];
    EMScheduleFashUpdateApi *api = [[EMScheduleFashUpdateApi alloc] initWithStartDate:schedule.startDate scheduleID:schedule.scheduleId];
    api.delegate = self;
    [api start];
}

#pragma mark - Handle api
- (void)handleDailyScheduleData:(NSArray *)data
{
    NSArray *scheduleArray = [NSArray array];
    NSDictionary *dayScheduleDic = data.firstObject;
    
    NSString *dateStr = dayScheduleDic[@"date"];
    NSArray *dayScheduleDicts = dayScheduleDic[@"daySchedules"];
    for (NSDictionary *scheduleDic in dayScheduleDicts) {
        //先入库，再获取，防止顺序不统一
        [self scheduleFromDictionary:scheduleDic date:dateStr];
        
//        EMScheduleModel *model = [self scheduleFromDictionary:scheduleDic date:dateStr];
//        [scheduleArray addObject:model];
    }
    scheduleArray = [self retrieveSchedulesFromDatabaseFrom:dateStr to:dateStr];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleOneDaySchedules:)]) {
        [self.delegate service:self handleOneDaySchedules:scheduleArray];
    }
}

- (void)handlePeriodScheduleData:(NSArray *)data
{
    NSMutableArray *scheduleArray = [NSMutableArray arrayWithCapacity:data.count];
    
    for (NSDictionary *dayScheduleDic in data) {
        NSString *dateStr = dayScheduleDic[@"date"] ?: @"";
        
        NSArray *dayScheduleDicts = dayScheduleDic[@"daySchedules"];
        NSMutableArray *daySchedules = [NSMutableArray arrayWithCapacity:dayScheduleDicts.count];
        for (NSDictionary *scheduleDic in dayScheduleDicts) {
            EMScheduleModel *model = [self scheduleFromDictionary:scheduleDic date:dateStr];
            [daySchedules addObject:model];
        }
        [scheduleArray addObject:daySchedules];
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handlePeriodSchedules:)]) {
        [self.delegate service:self handlePeriodSchedules:scheduleArray];
    }
}

- (void)handleMonthScheduleData:(NSArray *)data
{
    NSMutableArray *scheduleArray = [NSMutableArray arrayWithCapacity:data.count];
    NSDictionary *dayScheduleDic = data.firstObject;
    
    NSString *dateStr = dayScheduleDic[@"date"];
    NSArray *dayScheduleDicts = dayScheduleDic[@"daySchedules"];
    for (NSDictionary *scheduleDic in dayScheduleDicts) {
        EMScheduleModel *model = [self scheduleFromDictionary:scheduleDic date:dateStr];
        [scheduleArray addObject:model];
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleMonthSchedules:todaySchedules:)]) {
        [self.delegate service:self handleMonthSchedules:nil todaySchedules:scheduleArray];
    }
}

//类型转换
- (EMScheduleModel *)scheduleFromDictionary:(NSDictionary *)dict date:(NSString *)dateStr
{
    EMScheduleModel *schedule = [self onlyScheduleFromDictionary:dict date:dateStr];
    
    //入库
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT,0), ^{
        [schedule createOrUpdate];
    });
    return schedule;
}

//不入库
- (EMScheduleModel *)onlyScheduleFromDictionary:(NSDictionary *)dict date:(NSString *)dateStr
{
    EMScheduleModel *schedule = [EMScheduleModel new];
    schedule.date = dateStr;
    schedule.agencyCompanyName = dict[@"agencyCompanyName"] ?: @"";
    schedule.matter = dict[@"matter"] ?: @"";
    schedule.primaryID = dict[@"primaryID"] ?: @"";
    schedule.remark = dict[@"remark"] ?: @"";
    schedule.reminderTimeType = dict[@"reminderTimeType"] ?: @"";
    schedule.scheduleId = dict[@"scheduleId"] ?: @"";
    schedule.scheduleType = dict[@"scheduleType"] ?: @"";
    schedule.startDate = dict[@"startDate"] ?: @"";
    schedule.status = dict[@"status"] ?: @"";
    schedule.appraiseIsRead = [dict[@"appraiseIsRead"] isEqualToString:@"0"] ? @"0" : @"1";
    
    return schedule;
}

- (void)handleScheduleFastUpdateApi
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(updateScheduleTime:)]) {
        [self.delegate updateScheduleTime:self];
    }
}

- (void)handleUndoneScheduleApi:(NSArray *)data
{
    NSMutableArray *scheduleArray = [NSMutableArray arrayWithCapacity:data.count];
    
    NSInteger count = 0;
    NSMutableArray *allSchedules= [NSMutableArray arrayWithCapacity:data.count];
    for (NSDictionary *dayScheduleDic in data) {
        NSString *dateStr = dayScheduleDic[@"date"] ?: @"";
        
        NSArray *dayScheduleDicts = dayScheduleDic[@"daySchedules"];
        NSMutableArray *daySchedules = [NSMutableArray arrayWithCapacity:dayScheduleDicts.count];
        for (NSDictionary *scheduleDic in dayScheduleDicts) {
            EMScheduleModel *model = [self onlyScheduleFromDictionary:scheduleDic date:dateStr];
            [allSchedules addObject:model];
            
            NSDate *scheduleDate = [NSDate fjs_dateFromString:model.startDate inFormat:@"yyyy-MM-dd HH:mm"];
            NSComparisonResult result = [scheduleDate compare:[NSDate date]];
            //未完成状态
            if (model.status.integerValue == EMScheduleStatusUndone) {
                if (result != NSOrderedDescending) {
                    //时间早于现在的时间，加入待反馈列表
                    [daySchedules addObject:model];
                    count++;
                } else {
                    //时间晚于现在的时间，加入推送列表
                    [[EMNotificationCenter sharedInstance] setOrUpdateLocalNotificationWithSchedule:model];
                }
            }
        }
        if (daySchedules.count > 0) {
            [scheduleArray addObject:daySchedules];
        }
    }
    
    [EMScheduleModel clearTable];
    [EMScheduleModel createObjects:allSchedules];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleUndoneSchedules:count:)]) {
        [self.delegate service:self handleUndoneSchedules:scheduleArray count:count];
    }
}

- (void)handleRatioScheduleData:(NSArray *)data
{
    NSInteger exploitCount = 0;
    NSInteger maintainCount = 0;
    NSInteger otherCount = 0;
    
    for (NSDictionary *dayScheduleDic in data) {
        NSString *dateStr = dayScheduleDic[@"date"] ?: @"";
        
        NSArray *dayScheduleDicts = dayScheduleDic[@"daySchedules"];
        for (NSDictionary *scheduleDic in dayScheduleDicts) {
            EMScheduleModel *model = [self scheduleFromDictionary:scheduleDic date:dateStr];
            switch ([model.scheduleType integerValue]) {
                case EMScheduleTypeExploit:
                {
                    exploitCount++;
                }
                    break;
                    
                case EMScheduleTypeMaintain:
                {
                    maintainCount++;
                }
                    break;
                    
                case EMScheduleTypeOther:
                {
                    otherCount++;
                }
                    break;
            }
        }
    }
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleMonthScheduleCountOfExploit:maintain:other:)]) {
        [self.delegate service:self handleMonthScheduleCountOfExploit:exploitCount maintain:maintainCount other:otherCount];
    }
}


#pragma mark - FJSRequestDelegate
- (void)handleApiRequestDidSuccess:(__kindof FJSBaseApi *)request
{
    FJSLog(@"Api class => %@", request.class);
    FJSLog(@"response => %@", request.responseString);
    FJSLog(@"responseObject => %@", request.responseObject);
    NSArray *data = request.responseObject[@"data"];
    if (request.class == [EMGetMonthScheduleApi class]) {
        [self handleMonthScheduleData:data];
    }
    else if (request.class == [EMGetPeriodScheduleApi class]) {
        if (request.tag == kGetScheduleTagPeriod) {
            [self handlePeriodScheduleData:data];
        }
        else if (request.tag == kGetScheduleTagMonth) {
            [self handleMonthScheduleData:data];
        }
        else if (request.tag == kGetScheduleTagRatio) {
            [self handleRatioScheduleData:data];
        }
    }
    else if (request.class == [EMGetDailyScheduleApi class]) {
        [self handleDailyScheduleData:data];
    }
    else if (request.class == [EMScheduleFashUpdateApi class]) {
        [self handleScheduleFastUpdateApi];
    }
    else if (request.class == [EMGetUndoneSchedulesApi class]) {
        [self handleUndoneScheduleApi:data];
    }
}

- (void)handleApiRequestDidFail:(__kindof FJSBaseApi *)request
{
    FJSLog(@"Api class => %@", request.class);
    FJSLog(@"response => %@", request.responseString);
    FJSLog(@"responseObject => %@", request.responseObject);
}


@end
