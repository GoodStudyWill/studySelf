//
//  EMScheduleFashUpdateApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/11.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleFashUpdateApi.h"
#import "EMUserManager.h"

@interface EMScheduleFashUpdateApi ()

@property (nonatomic, copy) NSString *startDate;
@property (nonatomic, copy) NSString *schduleID;

@end

@implementation EMScheduleFashUpdateApi

- (instancetype)initWithStartDate:(NSString *)startDate scheduleID:(NSString *)scheduleID
{
    self = [super init];
    if (self) {
        _startDate = startDate;
        _schduleID = scheduleID;
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"plan/fastUpdate.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{@"userId"       : [[EMUserManager sharedInstance] userID] ?: @"",
                            @"startDate"    : _startDate ?: @"",
                            @"scheduleId"   : _schduleID ?: @"",
                            };
    
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
