//
//  EMOperateScheduleApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/11/2.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMOperateScheduleApi.h"
#import "EMUserManager.h"

@interface EMOperateScheduleApi ()

@property (nonatomic, copy, readwrite) NSString *scheduleID;
@property (nonatomic, copy, readwrite) NSString *status;
@property (nonatomic, copy, readwrite) NSString *remark;
@property (nonatomic, copy) NSString *operateType;

@end

@implementation EMOperateScheduleApi

- (instancetype)initWithScheduleID:(NSString *)scheduleID
                       operateType:(NSString *)operateType
                            status:(NSString *)status
                            remark:(NSString *)remark
{
    self = [super init];
    if (self) {
        _scheduleID = scheduleID;
        _operateType = operateType;
        _status = status;
        _remark = remark;
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"plan/operateSchedule.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{@"userId"       : [[EMUserManager sharedInstance] userID] ?: @"",
                            @"scheduleId"   : _scheduleID ?: @"",
                            @"operateType"  : _operateType ?: @"",
                            @"status"       : _status ?: @"",
                            @"remark"       : _remark ?: @"",
                            };
    
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}


@end
