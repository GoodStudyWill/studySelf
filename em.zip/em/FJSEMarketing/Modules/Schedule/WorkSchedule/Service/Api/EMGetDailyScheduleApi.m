//
//  EMGetDailyScheduleApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMGetDailyScheduleApi.h"

@interface EMGetDailyScheduleApi ()

@property (nonatomic, copy) NSString *date;

@end

@implementation EMGetDailyScheduleApi

- (instancetype)initWithDate:(NSString *)date
{
    self = [super init];
    if (self) {
        _date = date;
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"plan/getMonthSchedule.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{@"queryStartDay" : self.date ?: @"",
                            @"queryEndDay" : self.date ?: @""
                            };
    
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
