//
//  EMGetDailyScheduleApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>

@interface EMGetDailyScheduleApi : FJSApi

- (instancetype)initWithDate:(NSString *)date;

@end
