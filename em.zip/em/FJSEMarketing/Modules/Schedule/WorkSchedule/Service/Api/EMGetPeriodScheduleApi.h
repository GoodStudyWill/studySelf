//
//  EMGetPeriodScheduleApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/31.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>

@interface EMGetPeriodScheduleApi : FJSApi

- (instancetype)initWithStartDate:(NSString *)startDate endDate:(NSString *)endDate;

@end
