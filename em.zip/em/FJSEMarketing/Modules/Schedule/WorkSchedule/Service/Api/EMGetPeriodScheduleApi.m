//
//  EMGetPeriodScheduleApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/31.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMGetPeriodScheduleApi.h"

@interface EMGetPeriodScheduleApi ()

@property (nonatomic, copy) NSString *startDate;
@property (nonatomic, copy) NSString *endDate;

@end

@implementation EMGetPeriodScheduleApi

- (instancetype)initWithStartDate:(NSString *)startDate endDate:(NSString *)endDate
{
    self = [super init];
    if (self) {
        _startDate = startDate;
        _endDate = endDate;
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"plan/getMonthSchedule.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{@"queryStartDay" : self.startDate ?: @"",
                            @"queryEndDay" : self.endDate ?: @""
                            };
    
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}


@end
