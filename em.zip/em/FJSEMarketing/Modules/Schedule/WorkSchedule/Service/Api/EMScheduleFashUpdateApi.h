//
//  EMScheduleFashUpdateApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/11.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>

@interface EMScheduleFashUpdateApi : FJSApi

- (instancetype)initWithStartDate:(NSString *)startDate scheduleID:(NSString *)scheduleID;

@end
