//
//  EMOperateScheduleApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/11/2.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>

@interface EMOperateScheduleApi : FJSApi

@property (nonatomic, readonly) NSString *scheduleID;
@property (nonatomic, readonly) NSString *status;
@property (nonatomic, readonly) NSString *remark;
@property (nonatomic, copy) NSString *callback;

- (instancetype)initWithScheduleID:(NSString *)scheduleID
                       operateType:(NSString *)operateType
                            status:(NSString *)status
                            remark:(NSString *)remark;

@end
