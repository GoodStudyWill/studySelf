//
//  EMGetUndoneSchedulesApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/15.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMGetUndoneSchedulesApi.h"
#import "NSDate+FJSExtension.h"

@interface EMGetUndoneSchedulesApi ()

@property (nonatomic, copy) NSString *beforeDateStr;
@property (nonatomic, copy) NSString *aWeeksLaterDateStr;
@end

@implementation EMGetUndoneSchedulesApi

- (instancetype)init
{
    self = [super init];
    if (self) {
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
        NSDateComponents *adcomps = [[NSDateComponents alloc] init];
        [adcomps setYear:0];
        [adcomps setMonth:-6];
        [adcomps setDay:0];
        NSDate *beforeDate = [calendar dateByAddingComponents:adcomps toDate:[NSDate date] options:0];
        self.beforeDateStr = [beforeDate fjs_dateInFormat:@"yyyy-MM-dd"];
        
        NSDateComponents *afterComps = [[NSDateComponents alloc] init];
        [afterComps setYear:0];
        [afterComps setMonth:0];
        [afterComps setDay:+7];
        NSDate *aWeeksLaterDate = [calendar dateByAddingComponents:afterComps toDate:[NSDate date] options:0];
        self.aWeeksLaterDateStr = [aWeeksLaterDate fjs_dateInFormat:@"yyyy-MM-dd"];
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"plan/getMonthSchedule.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{@"queryStartDay"    : self.beforeDateStr ?: @"",
                            @"queryEndDay"      : [NSDate fjs_todayInFormat:@"yyyy-MM-dd"] ?: @""
                            };
    
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
