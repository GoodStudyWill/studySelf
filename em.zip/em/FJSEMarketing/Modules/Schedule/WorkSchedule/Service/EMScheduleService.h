//
//  EMScheduleService.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/20.
//  Copyright © 2017年 pingan. All rights reserved.
//

//#import <Foundation/Foundation.h>
#import "EMBaseService.h"

@class EMScheduleService;
@class EMScheduleModel;

@protocol EMScheduleServiceDelegate <NSObject>

@optional

/**
 获取某天的日程的回调

 @param service service
 @param schedules 某一天所在那个月的所有日程
 */
- (void)service:(EMScheduleService *)service handleOneDaySchedules:(NSArray *)schedules;

/**
 获取某个时间段的日程的回调

 @param service service
 @param schedules 某个时间段的所有日程
 */
- (void)service:(EMScheduleService *)service handlePeriodSchedules:(NSArray *)schedules;

- (void)service:(EMScheduleService *)service handleMonthSchedules:(NSDictionary *)schedulesDic todaySchedules:(NSArray *)todaySchedules;

- (void)updateScheduleTime:(EMScheduleService *)service;

- (void)service:(EMScheduleService *)service handleUndoneSchedules:(NSArray *)schedules count:(NSInteger)count;

- (void)service:(EMScheduleService *)service handleMonthScheduleCountOfExploit:(NSInteger)exploitCount maintain:(NSInteger)maintainCount other:(NSInteger)otherCount;

- (void)service:(EMScheduleService *)service handleAllSchedules:(NSDictionary *)allSchedules;

@end


@interface EMScheduleService : EMBaseService

@property (nonatomic, weak) id<EMScheduleServiceDelegate> delegate;

/**
 获取某天的日程

 @param date 日期
 */
- (void)getScheduleFor:(NSString *)date;

/**
 获取某个时间段的日程

 @param startDate 开始时间
 @param endDate 结束时间
 */
- (void)getSchedulesFrom:(NSString *)startDate to:(NSString *)endDate;

- (void)getScheduleForMonthDay:(NSString *)date;


- (void)updateScheduleTime:(EMScheduleModel *)schedule;

- (void)getUndoneSchedulesInNetwork;

- (void)getUndoneSchedules;

- (void)getSchedulesRatioOfThisMonth;

- (void)getAllSchdulesEvent;

@end
