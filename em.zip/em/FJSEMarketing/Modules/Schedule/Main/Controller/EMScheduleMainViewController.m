//
//  EMScheduleMainViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleMainViewController.h"
#import "EMScheduleMainViewController+Extension.h"
#import "EMUndoneScheduleCenter.h"

NSInteger const kChangViewIntoScheduleDayFlag = 9999;

@interface EMScheduleMainViewController ()<EMSegmentViewDelegate, EMTargetViewControllerDelegate>

@property (nonatomic, strong) UIViewController *currentViewController;

@end

@implementation EMScheduleMainViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.index = 0;
    [self initView];
//    [self.view addSubview:self.segmentView];
//    [self addChildViewController:self.scheduleViewController];
//    [self.contentView addSubview:self.scheduleViewController.view];
    self.currentViewController = self.scheduleViewController;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self setupNavigationBar];
    _flag = kChangViewIntoScheduleDayFlag;
}

- (void)changeViewIntoScheduleDay
{
    if (_flag == kChangViewIntoScheduleDayFlag) {
        [self.segmentView selectIndex:0];
        [self.scheduleViewController refreshViewInto:EMScheduleViewTypeDay];
    }
}

#pragma mark - EMSegmentViewDelegate
- (void)segmentViewDidSelectedAtIndex:(NSInteger)index
{
    if (index == 0) {
        [[EMUndoneScheduleCenter sharedInstance] refresh];
        [self changeFromViewController:self.currentViewController toViewController:self.scheduleViewController];
    }
    else if (index == 1) {
        [self changeFromViewController:self.currentViewController toViewController:self.targetViewController];
    }
    
    self.index = index;
    [self changeNewItem:index];
}

#pragma mark - EMTargetViewControllerDelegate
- (void)changeNavigationRightItem:(NSInteger)status aimYear:(NSString *)aimYear
{
    self.aimYear = aimYear;
    self.navigationBarStatus = status;
    [self changeNewItem:1];
    _index = 1;
}

#pragma mark - Setter & getter
- (EMSegmentView *)segmentView
{
    if (!_segmentView) {
        _segmentView = [[EMSegmentView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 45)
                                                                leftTitle:@"工作计划"
                                                               rightTitle:@"月度目标"];
        _segmentView.delegate = self;
    }
    return _segmentView;
}

- (UIView *)contentView
{
    if (!_contentView) {
        _contentView = [UIView new];
    }
    return _contentView;
}

- (EMScheduleViewController *)scheduleViewController
{
    if (!_scheduleViewController) {
        _scheduleViewController = [[EMScheduleViewController alloc] initWithNibName:@"EMScheduleViewController" bundle:nil];
        _scheduleViewController.type = _flag == kChangViewIntoScheduleDayFlag ? EMScheduleViewTypeDay : EMScheduleViewTypeWeek;
        [_scheduleViewController setFrame:self.contentViewFrame];
    }
    return _scheduleViewController;
}

- (EMTargetViewController *)targetViewController
{
    if (!_targetViewController) {
        _targetViewController = [[EMTargetViewController alloc] initWithNibName:@"EMTargetViewController" bundle:nil];
        _targetViewController.targetDelegate = self;
        [_targetViewController setFrame:self.contentViewFrame];
    }
    return  _targetViewController;
}

- (void)changeFromViewController:(UIViewController *)fromViewController toViewController:(UIViewController *)toViewController
{
    if (fromViewController == toViewController) {
        return;
    }
    [self addChildViewController:toViewController];
    [self transitionFromViewController:fromViewController toViewController:toViewController duration:1.0 options:UIViewAnimationOptionCurveEaseOut animations:^{
        
    } completion:^(BOOL finished) {
        self.currentViewController = toViewController;
        if (finished) {
            [toViewController didMoveToParentViewController:self];
            [fromViewController willMoveToParentViewController:nil];
            [fromViewController removeFromParentViewController];
        }
    }];
}

@end
