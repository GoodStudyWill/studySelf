//
//  EMScheduleMainViewController.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "EMScheduleViewController.h"
#import "EMTargetViewController.h"
#import "EMSegmentView.h"

FOUNDATION_EXPORT NSInteger const kChangViewIntoScheduleDayFlag;

@interface EMScheduleMainViewController : UIViewController

@property (nonatomic, strong) EMScheduleViewController  *scheduleViewController;
@property (nonatomic, strong) EMTargetViewController    *targetViewController;

@property (nonatomic, strong) EMSegmentView *segmentView;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, assign) CGRect contentViewFrame;

@property (nonatomic, assign) NSInteger navigationBarStatus;

@property (nonatomic, copy) NSString *aimYear;

@property (nonatomic, assign) NSInteger index;

@property (nonatomic, assign) EMScheduleViewType scheduleViewType;

@property (nonatomic, assign) NSInteger flag;

- (void)changeViewIntoScheduleDay;

@end
