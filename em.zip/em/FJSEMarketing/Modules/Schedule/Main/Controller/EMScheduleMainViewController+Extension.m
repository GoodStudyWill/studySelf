//
//  EMScheduleMainViewController+Extension.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleMainViewController+Extension.h"
#import "FJSWebViewController.h"
#import "FJSDatePicker.h"
#import "EMUndoneScheduleCenter.h"
#import "EMUndoneScheduleViewController.h"

@interface EMScheduleMainViewController ()

@end

@implementation EMScheduleMainViewController (Extension)

#pragma mark - Setup navigationBar
- (void)setupNavigationBar
{
    self.navigationController.navigationBar.barTintColor = UIColorFromHex(0x00a0ea);
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    self.view.backgroundColor = UIColorFromHex(0xeeeeee);
    
    UIBarButtonItem *newItem = [[UIBarButtonItem alloc] initWithTitle:@"新建"
                                                                       style:UIBarButtonItemStyleDone
                                                                      target:self
                                                                      action:@selector(handleNewScheduleItemAction:)];
    [newItem setTitleTextAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:14]} forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = newItem;
    [self changeNewItem:self.index];
}

- (void)handleScheduleItemAction:(id)sender
{
    FJSLog(@"schedule....");
    self.navigationItem.leftBarButtonItem.enabled = NO;
    EMUndoneScheduleViewController *viewController = [[EMUndoneScheduleViewController alloc] init];
    viewController.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:viewController animated:YES];
}

///新建工作计划
- (void)handleNewScheduleItemAction:(id)sender
{
    self.navigationItem.rightBarButtonItem.enabled = NO;
    FJSWebViewController *webViewController = [[FJSWebViewController alloc] initWithUrlString:kEMHtmlURLSchedule];
    [webViewController showLeftBarButtonItemWithImage:@"icon_back"];
    webViewController.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:webViewController animated:YES];
}

///新建月度目标
- (void)handleNewTargetItemAction:(id)sender
{
    self.navigationItem.rightBarButtonItem.enabled = NO;
    NSString *urlStr = [NSString stringWithFormat:@"%@?aimYear=%@&status=%ld", kEMHtmlURLTargetSet, self.aimYear, self.navigationBarStatus];
    FJSWebViewController *webViewController = [[FJSWebViewController alloc] initWithUrlString:urlStr];
    [webViewController showLeftBarButtonItemWithImage:@"icon_back"];
    webViewController.hidesBottomBarWhenPushed = YES;
    webViewController.delegate = self.targetViewController;
    [self.navigationController pushViewController:webViewController animated:YES];
}

- (void)changeNewItem:(NSInteger)index
{
    if (index == 0) {
        self.navigationItem.rightBarButtonItem.title = @"新建";
        self.navigationItem.rightBarButtonItem.enabled = YES;
        self.navigationItem.rightBarButtonItem.action = @selector(handleNewScheduleItemAction:);
        
        UIButton *scheduleBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 16, 15)];
        [scheduleBtn setImage:[UIImage imageNamed:@"icon_schedule"] forState:UIControlStateNormal];
        [scheduleBtn addTarget:self action:@selector(handleScheduleItemAction:) forControlEvents:UIControlEventTouchUpInside];
        
        NSInteger undoneCount = [[EMUndoneScheduleCenter sharedInstance] undoneCount];
        if (undoneCount > 0) {
            UIImageView *reddotView = [[UIImageView alloc] initWithFrame:CGRectMake(10, -5, 17, 14)];
            reddotView.image = [UIImage imageNamed:@"icon_msgReddot"];
            [scheduleBtn addSubview:reddotView];
            
            UILabel *countLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 17, 14)];
            countLabel.text = undoneCount > 9 ? @"9+" : [NSString stringWithFormat:@"%ld", undoneCount];
            countLabel.textColor = [UIColor whiteColor];
            countLabel.textAlignment = NSTextAlignmentCenter;
            countLabel.font = [UIFont systemFontOfSize:10];
            [reddotView addSubview:countLabel];
        }
        
        UIBarButtonItem *scheduleItem = [[UIBarButtonItem alloc] initWithCustomView:scheduleBtn];
        
        self.navigationItem.leftBarButtonItem = scheduleItem;

    }
    else if (index == 1) {
        self.navigationItem.leftBarButtonItem = nil;
        switch (self.navigationBarStatus) {
            case 1:
            {
                self.navigationItem.rightBarButtonItem.title = @"修改目标";
                self.navigationItem.rightBarButtonItem.enabled = YES;
            }
                break;
                
            case 2:
            {
                self.navigationItem.rightBarButtonItem.title = @"制定目标";
                self.navigationItem.rightBarButtonItem.enabled = NO;
            }
                break;
                
            case 3:
            {
                self.navigationItem.rightBarButtonItem.title = @"制定目标";
                self.navigationItem.rightBarButtonItem.enabled = YES;
            }
                break;
                
            case 4:
            {
                self.navigationItem.rightBarButtonItem.title = @"修改目标";
                self.navigationItem.rightBarButtonItem.enabled = YES;
            }
                break;
                
            default:
                break;
        }
        self.navigationItem.rightBarButtonItem.action = @selector(handleNewTargetItemAction:);
    }
}

#pragma mark - Init view
- (void)initView
{
    self.view.frame = CGRectMake(0, 64, SCREEN_WIDTH, SCREEN_HEIGHT - self.tabBarController.tabBar.height - 64);
    [self.view addSubview:self.segmentView];
    [self.view addSubview:self.contentView];
    
    [self.contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view).with.offset(10);
        make.top.equalTo(self.segmentView.mas_bottom).with.offset(5);
        make.bottom.equalTo(self.view).with.offset(-5);
        make.width.equalTo(@(SCREEN_WIDTH - 20));
    }];
    [self.view layoutIfNeeded];
    self.contentViewFrame = self.contentView.bounds;
    
    [self addChildViewController:self.scheduleViewController];
    [self.contentView addSubview:self.scheduleViewController.view];
}

@end
