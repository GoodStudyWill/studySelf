//
//  EMScheduleMainViewController+Extension.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleMainViewController.h"

@interface EMScheduleMainViewController (Extension)

- (void)setupNavigationBar;

- (void)initView;

- (void)changeNewItem:(NSInteger)index;

@end
