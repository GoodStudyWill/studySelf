//
//  EMScheduleHandler.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/7.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMScheduleHandler.h"
#import "EMUserManager.h"
#import "EMScheduleModel.h"
#import "EMUndoneScheduleCenter.h"
#import "EMNotificationCenter.h"
#import "NSDate+FJSExtension.h"

@implementation EMScheduleHandler

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)targetStatus:(NSDictionary *)params
{
    NSInteger status = [params[@"status"] integerValue];
    NSString *aimYear = params[@"aimYear"];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(changeTargetStatus:aimYear:)]) {
        [self.delegate changeTargetStatus:status aimYear:aimYear];
    }
}

- (void)getLeader:(NSDictionary *)params
{
    NSString *leader = [[EMUserManager sharedInstance] leader];
    NSDictionary *callBackParams = @{@"leader" : leader};
    
    NSMutableDictionary *callBackDict = [NSMutableDictionary dictionaryWithDictionary:params];
    [callBackDict setObject:callBackParams forKey:@"params"];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callBackLeader:)]) {
        [self.delegate handler:self callBackLeader:callBackDict];
    }
}

- (void)saveMyPlan:(NSDictionary *)params
{
    FJSLog(@"saveMyPlan...");
    NSDictionary *data = params[@"data"];
    NSInteger type = [params[@"type"] integerValue];
    
    EMScheduleModel *model = [EMScheduleModel new];
    model.agencyCompanyName = data[@"agencyCompanyName"];
    model.date = data[@"date"];
    model.matter = data[@"matter"];
    model.primaryID = data[@"primaryId"];
    model.remark = data[@"remark"];
    model.reminderTimeType = data[@"reminderTimeType"];
    model.scheduleId = data[@"scheduleId"];
    model.scheduleType = data[@"scheduleType"];
    model.status = data[@"status"];
    
    model.startDate = [NSString stringWithFormat:@"%@ %@", data[@"date"], data[@"startDate"]];
    
    NSDate *scheduleDate = [NSDate fjs_dateFromString:model.startDate inFormat:@"yyyy-MM-dd HH:mm"];
    NSComparisonResult result = [[NSDate date] compare:scheduleDate];
    if (result == NSOrderedDescending) {
        [[EMUndoneScheduleCenter sharedInstance] isScheduleChangeStatus:model isDelete:type==3];
    }
    
    if (type == 1 || type == 2) {
        //新建或修改
        [model createOrUpdate];
        [[EMNotificationCenter sharedInstance] setOrUpdateLocalNotificationWithSchedule:model];
    }
    else if (type == 3) {
        //删除
        [model deleteObject];
        [[EMNotificationCenter sharedInstance] removeLocalNotificationWithScheduleID:model.scheduleId];
    }
    
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshSchedule" object:model.date];
    });
    
}

@end
