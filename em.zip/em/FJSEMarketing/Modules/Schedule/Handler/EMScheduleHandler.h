//
//  EMScheduleHandler.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/7.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@class EMScheduleHandler;
@class EMScheduleModel;

@protocol EMScheduleHandlerDelegate <NSObject>

@optional

- (void)changeTargetStatus:(NSInteger)status aimYear:(NSString *)aimYear;

- (void)handler:(EMScheduleHandler *)handler callBackLeader:(NSDictionary *)params;

- (void)refreshSchedules:(NSString *)date;

@end

@interface EMScheduleHandler : NSObject

@property (nonatomic, weak) id<EMScheduleHandlerDelegate> delegate;

- (void)targetStatus:(NSDictionary *)params;

- (void)getLeader:(NSDictionary *)params;

- (void)saveMyPlan:(NSDictionary *)params;

@end
