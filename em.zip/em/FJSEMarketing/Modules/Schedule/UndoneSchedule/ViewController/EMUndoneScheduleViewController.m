//
//  EMUndoneScheduleViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/15.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMUndoneScheduleViewController.h"
#import "EMScheduleService.h"
#import "EMScheduleModel.h"
#import "NSDate+FJSExtension.h"
#import "EMScheduleTableViewCell.h"
#import "FJSWebViewController.h"
#import "UIBarButtonItem+FJSUIKit.h"
#import "EMUndoneScheduleCenter.h"

@interface EMUndoneScheduleViewController ()<EMScheduleServiceDelegate, UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) EMScheduleService *service;

@property (nonatomic, strong) UITableView *tableView;

@property (nonatomic, strong) NSMutableArray *schedules;

@property (nonatomic, strong) UIView *noUndoneScheduleView;

@end

@implementation EMUndoneScheduleViewController

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.title = @"我的计划";
//        self.trackName = @"待反馈计划";
        self.view.backgroundColor = UIColorFromHex(0xeeeeee);
        self.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-64);
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.tableView];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.service getUndoneSchedules];
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem showLeftBarButtonItemWithTitle:@"" orButtonImage:@"icon_back" target:self selector:@selector(clickLeftBarButton:)];
}

- (void)clickLeftBarButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - EMScheduleServiceDelegate
- (void)service:(EMScheduleService *)service handleUndoneSchedules:(NSArray *)schedules count:(NSInteger)count
{
    self.schedules = [schedules mutableCopy];
    [self.tableView reloadData];
    [EMUndoneScheduleCenter sharedInstance].undoneCount = count;
    
    BOOL hasUndoneSchedule = self.schedules.count > 0;
    self.tableView.hidden = !hasUndoneSchedule;
    self.noUndoneScheduleView.hidden = hasUndoneSchedule;
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 30;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    EMScheduleModel *model = nil;
    NSArray *daySchedules = self.schedules[section];
    model = daySchedules.firstObject;
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 355, 30)];
    headerView.backgroundColor = UIColorFromHex(0xf9f9f9);
    
    NSDate *date = [NSDate fjs_dateFromString:model.startDate inFormat:@"yyyy-MM-dd HH:mm"];
    UILabel *weekLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 150, 30)];
    weekLabel.text = [date fjs_dateInFormat:@"yyyy年M月d日"];
    weekLabel.textColor = UIColorFromHex(0x999999);
    weekLabel.font = [UIFont systemFontOfSize:13];
    [headerView addSubview:weekLabel];
    
    return headerView;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    EMScheduleTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    EMScheduleModel *schedule = cell.schedule;
    if (schedule.scheduleId && schedule.scheduleId.length > 0) {
        NSString *urlStr = [NSString stringWithFormat:@"%@%@", kEMHtmlURLSchedule, schedule.scheduleId];
        FJSWebViewController *webViewController = [[FJSWebViewController alloc] initWithUrlString:urlStr];
        [webViewController showLeftBarButtonItemWithImage:@"icon_back"];
        webViewController.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:webViewController animated:YES];
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.schedules.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSArray *daySchedules = self.schedules[section];
    return daySchedules.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *scheduleCellIdentifier = @"ScheduleCell";
    EMScheduleTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:scheduleCellIdentifier];
    if (cell == nil)
    {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"EMScheduleTableViewCell" owner:nil options:nil] lastObject];
    }
    
    NSArray *daySchedules = self.schedules[indexPath.section];
    cell.schedule = daySchedules[indexPath.row];
    
    return cell;
}


#pragma mark - Getter
- (EMScheduleService *)service
{
    if (!_service) {
        _service = [EMScheduleService new];
        _service.delegate = self;
    }
    return _service;
}

- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(10, 0, SCREEN_WIDTH-20, SCREEN_HEIGHT - 64)];
        _tableView.separatorColor = UIColorFromHex(0xdddddd);
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    }
    return _tableView;
}

- (NSMutableArray *)schedules
{
    if (!_schedules) {
        _schedules = [NSMutableArray array];
    }
    return _schedules;
}

- (UIView *)noUndoneScheduleView
{
    if (!_noUndoneScheduleView) {
        _noUndoneScheduleView  = [UIView new];
        [self.view addSubview:_noUndoneScheduleView];
        
        UIImageView *tipImageView = [UIImageView new];
        tipImageView.image = [UIImage imageNamed:@"icon_nojob"];
        [_noUndoneScheduleView addSubview:tipImageView];
        
        UILabel *tipLabel = [UILabel new];
        tipLabel.text = @"暂无待反馈日程";
        tipLabel.font = [UIFont systemFontOfSize:14];
        tipLabel.textColor = UIColorFromHex(0x666666);
        tipLabel.textAlignment = NSTextAlignmentCenter;
        [_noUndoneScheduleView addSubview:tipLabel];
        
        [_noUndoneScheduleView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(self.view);
        }];
        
        [tipImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(self.view);
            make.size.mas_equalTo(CGSizeMake(124, 90));
        }];
        
        [tipLabel mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(tipImageView.mas_bottom).with.offset(10);
            make.width.equalTo(tipImageView);
            make.left.equalTo(tipImageView);
        }];
    }
    return _noUndoneScheduleView;
}



@end
