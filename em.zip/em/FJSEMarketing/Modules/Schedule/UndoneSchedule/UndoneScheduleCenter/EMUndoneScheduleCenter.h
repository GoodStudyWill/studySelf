//
//  EMUndoneScheduleCenter.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/15.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@class EMScheduleModel;

@interface EMUndoneScheduleCenter : NSObject

@property (nonatomic, assign) NSInteger undoneCount;

+ (EMUndoneScheduleCenter *)sharedInstance;

- (void)loadData;

- (void)refresh;

- (void)isScheduleChangeStatus:(EMScheduleModel *)schedule isDelete:(BOOL)isDelete;

- (void)clear;



@end
