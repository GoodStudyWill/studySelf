//
//  EMUndoneScheduleCenter.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/15.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMUndoneScheduleCenter.h"
#import "EMScheduleService.h"
#import "EMScheduleModel.h"
#import "EMScheduleConstant.h"

@interface EMUndoneScheduleCenter ()<EMScheduleServiceDelegate>

@property (nonatomic, strong) EMScheduleService *service;

@end

@implementation EMUndoneScheduleCenter

+ (EMUndoneScheduleCenter *)sharedInstance
{
    static EMUndoneScheduleCenter *center;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        center = [[EMUndoneScheduleCenter alloc] init];
    });
    return center;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (void)loadData
{
    [self.service getUndoneSchedulesInNetwork];
}

- (void)refresh
{
    [self.service getUndoneSchedules];
}

- (void)isScheduleChangeStatus:(EMScheduleModel *)schedule isDelete:(BOOL)isDelete
{
    EMScheduleModel *scheduleInDB = [EMScheduleModel retrieveByPrimaryKey:schedule.scheduleId];
    BOOL isScheduleDone = isDelete && scheduleInDB.status.integerValue != EMScheduleStatusDone && scheduleInDB.status.integerValue != EMScheduleStatusUnhandled;
    if (isScheduleDone) {
        _undoneCount--;
        return;
    }
    
    if (schedule.status.integerValue != scheduleInDB.status.integerValue) {
        if (schedule.status.integerValue == EMScheduleStatusDone || scheduleInDB.status.integerValue == EMScheduleStatusUnhandled) {
            _undoneCount--;
        } else {
            _undoneCount++;
        }
    }
}

- (void)clear
{
    self.undoneCount = 0;
}

#pragma mark - EMScheduleServiceDelegate
- (void)service:(EMScheduleService *)service handleUndoneSchedules:(NSArray *)schedules count:(NSInteger)count
{
    FJSLog(@"self.undoneCount = %ld", count);
    self.undoneCount = count;
}

#pragma mark - Getter
- (EMScheduleService *)service
{
    if (!_service) {
        _service = [EMScheduleService new];
        _service.delegate = self;
    }
    return _service;
}

@end
