//
//  EMMessageService.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/24.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMMessageService.h"
#import "EMMessageModel.h"
#import "EMMessageCellFrame.h"
#import "EMMessageApi.h"
#import "EMNoticeApi.h"
#import "EMSubmitMessageReadApi.h"
#import "EMFileDownloadApi.h"

//每页消息数限制
static NSString * const kMessageLimit = @"10";

@interface EMMessageService () <FJSRequestDelegate>

//页数
@property (nonatomic, assign) NSUInteger messagePageNum;
@property (nonatomic, assign) NSUInteger noticePageNum;

@property (nonatomic, strong) NSMutableArray *messageArray;
@property (nonatomic, strong) NSMutableArray *noticeArray;

@property (nonatomic, assign) EMRequestMessageType requestType;

@property (nonatomic, copy  ) NSString *fileName;

@end

@implementation EMMessageService

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.messagePageNum = 1;
        self.noticePageNum = 1;
        self.requestType = EMRequestMessageTypeMessage;
        self.messageArray = [NSMutableArray array];
        self.noticeArray = [NSMutableArray array];
    }
    return self;
}

#pragma mark - Request
- (void)loadDataWithType:(EMRequestMessageType)type
{
    if (type == EMRequestMessageTypeMessage) {
        [self loadMessageData];
    }
    else if (type == EMRequestMessageTypeNotice) {
        [self loadNoticeData];
    }
}

- (void)loadMessageData
{
    NSString *pageNum = [NSString stringWithFormat:@"%lu", self.messagePageNum];
    self.messagePageNum++;
    EMMessageApi *api = [[EMMessageApi alloc] initWithLimit:kMessageLimit pageNum:pageNum];
    api.delegate = self;
    [api start];
}

- (void)loadNoticeData
{
    NSString *pageNum = [NSString stringWithFormat:@"%lu", self.noticePageNum];
    self.noticePageNum++;
    EMNoticeApi *api = [[EMNoticeApi alloc] initWithLimit:kMessageLimit pageNum:pageNum];
    api.delegate = self;
    [api start];
}

- (void)refreshDataWithType:(EMRequestMessageType)type
{
    if (type == EMRequestMessageTypeMessage) {
        self.messagePageNum = 1;
        [self.messageArray removeAllObjects];
        [self loadMessageData];
    } else if (type == EMRequestMessageTypeNotice) {
        self.noticePageNum = 1;
        [self.noticeArray removeAllObjects];
        [self loadNoticeData];
    }
}

- (void)readMessage:(EMMessageModel *)message
{
    //从用户角度出发，不用管返回，直接去掉未读小红点
    EMSubmitMessageReadApi *api = [[EMSubmitMessageReadApi alloc] initWithType:[NSString stringWithFormat:@"%lu", message.requestType] primaryID:message.primaryId];
    api.delegate = self;
    [api start];
}

- (void)getFileWithFileID:(NSString *)fileID fileName:(NSString *)fileName
{
    self.fileName = fileName;
    EMFileDownloadApi *api = [[EMFileDownloadApi alloc] initWithFileID:fileID fileName:fileName];
    api.delegate = self;
    [api start];
}

#pragma mark - Handle api
- (void)handleMessageData:(NSArray *)data
{
    NSMutableArray *messages = [self messagesFromData:data type:EMRequestMessageTypeMessage];
    [self.messageArray addObjectsFromArray:messages];
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleMessageData:)]) {
        [self.delegate service:self handleMessageData:self.messageArray];
    }
}

- (void)handleNoticeData:(NSArray *)data
{
    NSMutableArray *messages = [self messagesFromData:data type:EMRequestMessageTypeNotice];
    [self.noticeArray addObjectsFromArray:messages];
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleNoticeData:)]) {
        [self.delegate service:self handleNoticeData:self.noticeArray];
    }
}

- (void)handleFileDownload:(NSData *)data
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
//    NSString *cachePath = [[paths objectAtIndex:0] stringByAppendingFormat:@"/Caches"];
    NSString *path = [NSString stringWithFormat:@"%@/%@", documentsDirectory, self.fileName];
    NSError *error;
    BOOL written = [data writeToFile:path options:0 error:&error];
    if (!written)
    {
        FJSLog(@"Write failed: %@", [error localizedDescription]);
    }
    FJSLog(@"Write success!");
    
    NSURL *fileURL = [NSURL fileURLWithPath:path];
    if (self.delegate && [self.delegate respondsToSelector:@selector(service:handleFileURL:)]) {
        [self.delegate service:self handleFileURL:fileURL];
    }
}

#pragma mark - Transform data
- (NSMutableArray *)messagesFromData:(NSArray *)data type:(EMRequestMessageType)type
{
    NSMutableArray *dataModels = [NSMutableArray arrayWithCapacity:data.count];
    for (NSDictionary *dataDict in data) {
        EMMessageModel *model = [[EMMessageModel alloc] init];
        model.requestType = type;
        model.content = dataDict[@"content"];
        model.messageType = dataDict[@"messageType"];
        model.messageTitle = dataDict[@"messageTitle"];
        model.publishTime = dataDict[@"publishTime"];
        model.readMark = dataDict[@"readMark"];
        model.primaryId = dataDict[@"primaryId"];
        model.attachmentList = dataDict[@"attachmentList"];
        
        EMMessageCellFrame *cellFrame = [[EMMessageCellFrame alloc] init];
        cellFrame.model = model;
        [dataModels addObject:cellFrame];
    }
    
    return dataModels;
}

#pragma mark - FJSRequestDelegate
- (void)handleApiRequestDidSuccess:(__kindof FJSBaseApi*)request
{
    FJSLog(@"Api class => %@", request.class);
    FJSLog(@"response => %@", request.responseString);
    FJSLog(@"responseObject => %@", request.responseObject);
    if (request.class == [EMMessageApi class]) {
        NSArray *data = request.responseObject[@"data"];
        [self handleMessageData:data];
    }
    else if (request.class == [EMNoticeApi class]) {
        NSArray *data = request.responseObject[@"data"];
        [self handleNoticeData:data];
    }
    else if (request.class == [EMFileDownloadApi class]) {
        [self handleFileDownload:request.responseData];
    }
}

- (void)handleApiRequestDidFail:(__kindof FJSBaseApi *)request
{
    FJSLog(@"Api class => %@", request.class);
    FJSLog(@"response => %@", request.responseString);
    //由于下载文件接口contentType不固定，按照返回文件类型改变
    if (request.class == [EMFileDownloadApi class]) {
        [self handleFileDownload:request.responseData];
    }
}

- (void)handleApiResponseData:(__kindof FJSBaseApi *)request
{
    if (request.class == [EMFileDownloadApi class]) {
        [self handleFileDownload:request.responseData];
    }
}

@end
