//
//  EMMessageService.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/24.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMBaseService.h"

@class EMMessageService;
@class EMMessageModel;

@protocol EMMessageServiceDelegate <NSObject>

- (void)service:(EMMessageService *)service handleMessageData:(NSArray *)messageData;

- (void)service:(EMMessageService *)service handleNoticeData:(NSArray *)noticeData;

- (void)service:(EMMessageService *)service handleFileURL:(NSURL *)fileURL;

@end

@interface EMMessageService : EMBaseService

@property (nonatomic, weak) id<EMMessageServiceDelegate> delegate;

/**
 获取消息数据

 @param type 消息类型
 */
- (void)loadDataWithType:(EMRequestMessageType)type;

/**
 上拉刷新数据

 @param type 消息类型
 */
- (void)refreshDataWithType:(EMRequestMessageType)type;

/**
 标记消息为已读

 @param message 消息
 */
- (void)readMessage:(EMMessageModel *)message;

/**
 获取文件

 @param fileID 文件ID
 @param fileName 文件名
 */
- (void)getFileWithFileID:(NSString *)fileID fileName:(NSString *)fileName;

@end
