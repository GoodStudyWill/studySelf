//
//  EMSubmitMessageReadApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/27.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMSubmitMessageReadApi.h"

@interface EMSubmitMessageReadApi ()

@property (nonatomic, copy) NSString *type;
@property (nonatomic, copy) NSString *primaryID;

@end

@implementation EMSubmitMessageReadApi

- (instancetype)initWithType:(NSString *)type primaryID:(NSString *)primaryID
{
    self = [super init];
    if (self) {
        _type = type;
        _primaryID = primaryID;
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"mssg/submitMessageAndNoticeRead.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{
                            @"type"      : self.type,
                            @"primaryId" : self.primaryID,
                            };
    
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
