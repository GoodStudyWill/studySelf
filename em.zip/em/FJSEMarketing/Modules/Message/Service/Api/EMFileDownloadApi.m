//
//  EMFileDownloadApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/27.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMFileDownloadApi.h"

@interface EMFileDownloadApi ()

@property (nonatomic, copy) NSString *fileID;
@property (nonatomic, copy) NSString *fileName;

@end

@implementation EMFileDownloadApi

- (instancetype)initWithFileID:(NSString *)fileID fileName:(NSString *)fileName
{
    self = [super init];
    if (self) {
        _fileID = fileID;
        _fileName = fileName;
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"file/getFileDownloadUrl.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{
                            @"fileId"   : _fileID ?: @"",
                            @"fileName" : _fileName ?: @"",
                            };
    
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

- (FJSResponseSerializerType)responseSerializerType
{
    return FJSResponseSerializerTypeHTTP;
}

- (BOOL)encryptRequest
{
    return NO;
}


@end
