//
//  EMSubmitMessageReadApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/27.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>

@interface EMSubmitMessageReadApi : FJSApi

/**
 初始化

 @param type 消息类型，1消息，2公告
 @param primaryID 消息主键ID
 @return 对象
 */
- (instancetype)initWithType:(NSString *)type primaryID:(NSString *)primaryID;

@end
