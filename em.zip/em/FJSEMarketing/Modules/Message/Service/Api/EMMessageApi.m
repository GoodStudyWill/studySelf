//
//  EMMessageApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/27.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMMessageApi.h"

@interface EMMessageApi ()

@property (nonatomic, copy) NSString *limit;
@property (nonatomic, copy) NSString *pageNum;

@end

@implementation EMMessageApi

- (instancetype _Nonnull)initWithLimit:(nonnull NSString *)limit
                               pageNum:(nonnull NSString *)pageNum
{
    self = [super init];
    if (self) {
        _limit = limit;
        _pageNum = pageNum;
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"mssg/getLimitMessageAndNoticeList.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{
                            @"type"     : [NSString stringWithFormat:@"%lu", EMRequestMessageTypeMessage],
                            @"limit"    : self.limit,
                            @"num"      : self.pageNum,
                            };
    
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
