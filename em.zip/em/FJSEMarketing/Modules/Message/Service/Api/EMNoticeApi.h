//
//  EMNoticeApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/27.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>

@interface EMNoticeApi : FJSApi

- (instancetype _Nonnull)initWithLimit:(nonnull NSString *)limit
                               pageNum:(nonnull NSString *)pageNum;

@end
