//
//  EMMessageCellFrame.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/26.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@class EMMessageModel;

@interface EMMessageCellFrame : NSObject

@property (nonatomic, strong) EMMessageModel *model;

@property (nonatomic, assign) CGFloat height;
@property (nonatomic, assign) CGFloat labelHeight;

@property (nonatomic, copy)   NSString *imageName;

@property (nonatomic, copy)   NSString *dateString;

@end
