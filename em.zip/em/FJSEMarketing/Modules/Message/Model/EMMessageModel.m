//
//  EMMessageModel.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/19.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMMessageModel.h"

NSString * const kMessageAttachmentFileID = @"fileId";
NSString * const kMessageAttachmentFileName = @"fileName";

@implementation EMMessageModel

@end
