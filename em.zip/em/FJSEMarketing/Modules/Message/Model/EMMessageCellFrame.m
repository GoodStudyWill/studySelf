//
//  EMMessageCellFrame.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/26.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMMessageCellFrame.h"
#import "NSDate+FJSExtension.h"
#import "NSString+FJSExtension.h"
#import "EMMessageModel.h"

@implementation EMMessageCellFrame

- (void)setModel:(EMMessageModel *)model
{
    _model = model;
    
    [self calculateCellHeight];
    [self transformDateString];
}

- (void)calculateCellHeight
{
    CGFloat titleViewHeight = 42;
    
    CGFloat cellHeight = 0;
    CGFloat labelWidth = 0;
    CGFloat attachmentHeight = 0;
    if (_model.requestType == EMRequestMessageTypeMessage) {
        cellHeight = titleViewHeight + 15 + 15 + 15 + 15;
        labelWidth = 355 - 40 - 20;
    }
    else {
        cellHeight = titleViewHeight + 75;
        labelWidth = 355 - 15 - 15;
        if (_model.attachmentList.count) {
            attachmentHeight = 1 + 15 + 15 + 30 * _model.attachmentList.count;
        }
    }
    
    _labelHeight = [_model.content fjs_heightForFont:[UIFont systemFontOfSize:14] width:labelWidth];
    
    _height = cellHeight + _labelHeight + attachmentHeight;
}

- (void)transformDateString
{
    _dateString = [NSDate fjs_dateStringFromString:_model.publishTime intoFormat:@"M月d日 HH:mm"];
}

- (void)setIconName
{
    
}

@end
