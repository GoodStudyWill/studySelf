//
//  EMMessageModel.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/19.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString * const kMessageAttachmentFileID;
FOUNDATION_EXPORT NSString * const kMessageAttachmentFileName;

@interface EMMessageModel : NSObject

@property (nonatomic, assign) EMRequestMessageType requestType;

//消息标题
@property (nonatomic, copy) NSString *messageTitle;

//是否已读, 1未读, 2已读
@property (nonatomic, copy) NSString *readMark;

//消息类型
@property (nonatomic, copy) NSString *messageType;

//消息发布时间
@property (nonatomic, copy) NSString *publishTime;

//消息内容
@property (nonatomic, copy) NSString *content;

//消息ID
@property (nonatomic, copy) NSString *primaryId;

//附件列表，附件为dictionary，key为`kMessageAttachmentFileID`和`kMessageAttachmentFileName`
@property (nonatomic, copy) NSArray *attachmentList;

@end
