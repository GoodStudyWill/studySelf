//
//  EMMessageViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/24.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <QuickLook/QuickLook.h>
#import "EMMessageViewController.h"
#import "EMMessageService.h"
#import "EMSegmentView.h"
#import "EMMessageModel.h"
#import "EMMessageCellFrame.h"
#import "EMMessageTableViewCell.h"
#import "EMNoticeTableViewCell.h"
#import "FJSActivityIndicatorView.h"
#import "UIBarButtonItem+FJSUIKit.h"

@interface EMMessageViewController ()<EMSegmentViewDelegate, EMMessageServiceDelegate, UITableViewDelegate, UITableViewDataSource, UIScrollViewDelegate, QLPreviewControllerDelegate, QLPreviewControllerDataSource>

@property (nonatomic, strong) EMMessageService *service;

@property (nonatomic, strong) EMSegmentView *segmentView;

@property (nonatomic, strong) UITableView *messageTableView;
@property (nonatomic, strong) UITableView *noticeTableView;

@property (nonatomic, copy  ) NSArray *messages;    //消息集合
@property (nonatomic, copy  ) NSArray *notices;     //公告集合

@property (nonatomic, assign) NSInteger refreshTag;

@property (nonatomic, strong) NSURL *fileURL;

@property (nonatomic, strong) FJSActivityIndicatorView *messageDownIndicator;
@property (nonatomic, strong) FJSActivityIndicatorView *messageUpIndicator;

@property (nonatomic, strong) FJSActivityIndicatorView *noticeDownIndicator;
@property (nonatomic, strong) FJSActivityIndicatorView *noticeUpIndicator;

@property (nonatomic, strong) UINavigationController *previewNaviController;

@end

@implementation EMMessageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.trackName = @"消息";
    [self setupNavigationBar];
    [self setupView];
    [self layoutConstraints];
    
    [self loadData];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem showLeftBarButtonItemWithTitle:@"" orButtonImage:@"icon_back" target:self selector:@selector(clickLeftBarButton:)];
}

- (void)clickLeftBarButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UI
- (void)setupView
{
    self.view.backgroundColor = UIColorFromHex(0xeeeeee);
    self.view.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 64);
    [self.view addSubview:self.segmentView];
}

- (void)setupNavigationBar
{
    self.title = @"消息中心";
    
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName : [UIColor whiteColor]};
}

- (void)layoutConstraints
{
    [self.messageTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.segmentView.mas_bottom);
        make.bottom.equalTo(self.view);
        make.centerX.equalTo(self.view);
        make.width.equalTo(@(SCREEN_WIDTH-20));
    }];
    
    [self.noticeTableView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.segmentView.mas_bottom);
        make.bottom.equalTo(self.view);
        make.centerX.equalTo(self.view);
        make.width.equalTo(@(SCREEN_WIDTH-20));
    }];
}

#pragma mark - Load data
- (void)loadData
{
    [self.service loadDataWithType:EMRequestMessageTypeMessage];
    [self.service loadDataWithType:EMRequestMessageTypeNotice];
    [EMHudManager showLoadingWithText:nil inView:self.view];
}

- (void)getFileWithFileID:(NSString *)fileID fileName:(NSString *)fileName
{
    [EMHudManager showLoadingWithText:nil inView:self.view];
    [self.service getFileWithFileID:fileID fileName:fileName];
}

#pragma mark - EMSegmentViewDelegate
- (void)segmentViewDidSelectedAtIndex:(NSInteger)index
{
    if (index) {
        //公告
        self.messageTableView.hidden = YES;
        self.noticeTableView.hidden = NO;
    }
    else {
        //消息
        self.messageTableView.hidden = NO;
        self.noticeTableView.hidden = YES;
    }
}

#pragma mark - EMMessageServiceDelegate
- (void)service:(EMMessageService *)service handleMessageData:(NSArray *)messageData
{
    if (_refreshTag == 1) {
        //上拉刷新结束
        if (self.messages.count == messageData.count) {
            [self.messageUpIndicator changeStatus:NO];
        }
        [self.messageUpIndicator stopAnimating];
    }
    else if (_refreshTag == 2) {
        //下拉刷新结束
        [self.messageUpIndicator changeStatus:YES];
        [self.messageDownIndicator stopAnimating];
        [self.messageTableView setContentInset:UIEdgeInsetsMake(0, 0, 0, 0)];
    }
    self.messages = messageData;
    [self.messageTableView reloadData];
    
    [EMHudManager hideLoadingForView:self.view];
    
    CGRect upFrame = CGRectZero;
    if (self.messageTableView.contentSize.height < self.messageTableView.height) {
        upFrame = CGRectMake(0, 20 + self.messageTableView.height, SCREEN_WIDTH-20, 30);
    } else {
        upFrame = CGRectMake(0, 20 + self.messageTableView.contentSize.height, SCREEN_WIDTH-20, 30);
    }
    self.messageUpIndicator.frame = upFrame;
    _refreshTag = 0;
}

- (void)service:(EMMessageService *)service handleNoticeData:(NSArray *)noticeData
{
    if (_refreshTag == 1) {
        //上拉刷新结束
        if (self.notices.count == noticeData.count) {
            [self.noticeUpIndicator changeStatus:NO];
        }
        [self.noticeUpIndicator stopAnimating];
    }
    else if (_refreshTag == 2) {
        //下拉刷新结束
        [self.noticeUpIndicator changeStatus:YES];
        [self.noticeDownIndicator stopAnimating];
        [self.noticeTableView setContentInset:UIEdgeInsetsMake(0, 0, 0, 0)];
    }
    self.notices = noticeData;
    [self.noticeTableView reloadData];
    
    [EMHudManager hideLoadingForView:self.view];
    
    CGRect upFrame = CGRectZero;
    if (self.noticeTableView.contentSize.height < self.noticeTableView.height) {
        upFrame = CGRectMake(0, 20 + self.noticeTableView.height, SCREEN_WIDTH-20, 30);
    } else {
        upFrame = CGRectMake(0, 20 + self.noticeTableView.contentSize.height, SCREEN_WIDTH-20, 30);
    }
    self.noticeUpIndicator.frame = upFrame;
    _refreshTag = 0;
}

- (void)service:(EMMessageService *)service handleFileURL:(NSURL *)fileURL
{
    if ([QLPreviewController canPreviewItem:(id<QLPreviewItem>)fileURL]) {
        self.fileURL = fileURL;
        QLPreviewController *qlViewController = [[QLPreviewController alloc] init];
        qlViewController.view.frame = CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height - 64);
        qlViewController.delegate = self;
        qlViewController.dataSource = self;
        
        self.previewNaviController = [[UINavigationController alloc] initWithRootViewController:qlViewController];
        self.previewNaviController.navigationBar.barTintColor = UIColorFromHex(0x00a0ea);
        [self.previewNaviController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
        
        UIBarButtonItem *backBtn = [UIBarButtonItem showLeftBarButtonItemWithTitle:nil orButtonImage:@"icon_back" target:self selector:@selector(previewControllerBackAction:)];
        qlViewController.navigationItem.leftBarButtonItem = backBtn;
        [EMHudManager hideLoadingForView:self.view];
        
        if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"10")) {
            [self presentViewController:self.previewNaviController animated:YES completion:nil];
        } else {
            [self.navigationController pushViewController:qlViewController animated:YES];
        }
    }
}

- (void)previewControllerBackAction:(id)sender
{
    [self.previewNaviController dismissViewControllerAnimated:YES completion:nil];
    self.previewNaviController = nil;
}

#pragma mark - UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    EMMessageCellFrame *cellFrame = nil;
    if (tableView == self.messageTableView) {
        cellFrame = self.messages[indexPath.row];
    }
    else {
        cellFrame = self.notices[indexPath.row];
    }
    return cellFrame.height;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    BOOL isMessage = tableView == self.messageTableView;
    EMMessageCellFrame *cellFrame = isMessage ? self.messages[indexPath.row] : self.notices[indexPath.row];
    EMMessageModel *model = cellFrame.model;
    if ([model.readMark isEqualToString:@"1"]) {
        model.readMark = @"2";
        [self.service readMessage:model];
        if (tableView == self.messageTableView) {
            EMMessageTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
            [cell read];
        }
        else {
            EMNoticeTableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
            [cell read];
        }
        
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.messageTableView) {
        return self.messages.count;
    }
    else {
        return self.notices.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.messageTableView) {
        static NSString *messageCellIdentifier = @"messageCellIdentifier";
        
        EMMessageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:messageCellIdentifier];
        if (cell == nil)
        {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"EMMessageTableViewCell" owner:nil options:nil] lastObject];
        }
        
        cell.cellFrame = self.messages[indexPath.row];
        
        return cell;
    }
    else {
        EMNoticeTableViewCell *cell = [[[NSBundle mainBundle] loadNibNamed:@"EMNoticeTableViewCell" owner:nil options:nil] lastObject];
        
        cell.cellFrame = self.notices[indexPath.row];
        __weak EMMessageViewController *weakSelf = self;
        [cell handleClickAttachmentAction:^(NSString *fileID, NSString *fileName) {
            FJSLog(@"fileID => %@ fileName => %@", fileID, fileName);
            [weakSelf getFileWithFileID:fileID fileName:fileName];
            
        }];
        
        return cell;
    }
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.contentOffset.y + scrollView.bounds.size.height > scrollView.contentSize.height) {
        //上拉加载更多
        _refreshTag = 1;
        if (scrollView == self.messageTableView) {
            [self.messageUpIndicator startAnimating];
        } else {
            [self.noticeUpIndicator startAnimating];
        }
    }
    else if (scrollView.contentOffset.y < -50) {
        //下拉刷新
        _refreshTag = 2;
        if (scrollView == self.messageTableView) {
            [self.messageDownIndicator changeStatus:YES];
        } else {
            [self.noticeDownIndicator changeStatus:YES];
        }
    }
    else {
        if (scrollView == self.messageTableView) {
            [self.messageDownIndicator changeStatus:NO];
        } else {
            [self.noticeDownIndicator changeStatus:NO];
        }
    }
}

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView
{
    if (_refreshTag == 1) {
        //上拉加载更多
        EMRequestMessageType type = scrollView == self.messageTableView ? EMRequestMessageTypeMessage : EMRequestMessageTypeNotice;
        [self.service loadDataWithType:type];
    }
    else if (_refreshTag == 2) {
        //下拉刷新
        EMRequestMessageType type = scrollView == self.messageTableView ? EMRequestMessageTypeMessage : EMRequestMessageTypeNotice;
        [self.service refreshDataWithType:type];
        if (scrollView == self.messageTableView) {
            [self.messageDownIndicator startAnimating];
            [scrollView setContentInset:UIEdgeInsetsMake(51, 0, 0, 0)];
        } else {
            [self.noticeDownIndicator startAnimating];
            [scrollView setContentInset:UIEdgeInsetsMake(51, 0, 0, 0)];
        }
    }
}

#pragma mark - QLPreviewController 代理方法
- (NSInteger)numberOfPreviewItemsInPreviewController:(QLPreviewController *)controller
{
    return 1;
}

- (id<QLPreviewItem>)previewController:(QLPreviewController *)controller previewItemAtIndex:(NSInteger)index{
    return self.fileURL;
}

#pragma mark - Setter & getter
- (EMMessageService *)service
{
    if (!_service) {
        _service = [[EMMessageService alloc] init];
        _service.delegate = self;
    }
    return _service;
}

- (EMSegmentView *)segmentView
{
    if (!_segmentView) {
        _segmentView = [[EMSegmentView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 45)
                                                  leftTitle:@"消息"
                                                 rightTitle:@"公告"];
        _segmentView.delegate = self;
    }
    return _segmentView;
}

- (UITableView *)messageTableView
{
    if (!_messageTableView) {
        _messageTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _messageTableView.backgroundColor = UIColorFromHex(0xf9f9f9);
        _messageTableView.delegate = self;
        _messageTableView.dataSource = self;
        _messageTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _messageTableView.showsVerticalScrollIndicator = NO;
        [self.view addSubview:_messageTableView];
    }
    return _messageTableView;
}

- (UITableView *)noticeTableView
{
    if (!_noticeTableView) {
        _noticeTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _noticeTableView.backgroundColor = UIColorFromHex(0xf9f9f9);
        _noticeTableView.delegate = self;
        _noticeTableView.dataSource = self;
        _noticeTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _noticeTableView.showsVerticalScrollIndicator = NO;
        [self.view addSubview:_noticeTableView];
        
        _noticeTableView.hidden = YES;
    }
    return _noticeTableView;
}

- (FJSActivityIndicatorView *)messageDownIndicator
{
    if (!_messageDownIndicator) {
        _messageDownIndicator  = [[FJSActivityIndicatorView alloc] initWithFrame:CGRectMake(0, -30, SCREEN_WIDTH-20, 30) style:FJSActivityIndicatorViewStyleDown];
        [self.messageTableView addSubview:_messageDownIndicator];
    }
    return _messageDownIndicator;
}

- (FJSActivityIndicatorView *)messageUpIndicator
{
    if (!_messageUpIndicator) {
        _messageUpIndicator = [[FJSActivityIndicatorView alloc] initWithFrame:CGRectMake(0, 20 + self.messageTableView.contentSize.height, SCREEN_WIDTH-20, 30) style:FJSActivityIndicatorViewStyleUp];
        [self.messageTableView addSubview:_messageUpIndicator];
    }
    return _messageUpIndicator;
}

- (FJSActivityIndicatorView *)noticeDownIndicator
{
    if (!_noticeDownIndicator) {
        _noticeDownIndicator = [[FJSActivityIndicatorView alloc] initWithFrame:CGRectMake(0, -30, SCREEN_WIDTH-20, 30) style:FJSActivityIndicatorViewStyleDown];
        [self.noticeTableView addSubview:_noticeDownIndicator];
    }
    return _noticeDownIndicator;
}

- (FJSActivityIndicatorView *)noticeUpIndicator
{
    if (!_noticeUpIndicator) {
        _noticeUpIndicator = [[FJSActivityIndicatorView alloc] initWithFrame:CGRectMake(0, 20 + self.noticeTableView.contentSize.height, SCREEN_WIDTH-20, 30) style:FJSActivityIndicatorViewStyleUp];
        [self.noticeTableView addSubview:_noticeUpIndicator];
    }
    return _noticeUpIndicator;
}


@end
