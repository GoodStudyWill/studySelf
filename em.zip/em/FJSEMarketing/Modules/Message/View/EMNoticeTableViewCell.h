//
//  EMNoticeTableViewCell.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/27.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@class EMMessageCellFrame;

typedef void (^EMNoticeAttachmentBlock)(NSString *fileID, NSString *fileName);

@interface EMNoticeTableViewCell : UITableViewCell

@property (nonatomic, strong) EMMessageCellFrame *cellFrame;

- (void)handleClickAttachmentAction:(EMNoticeAttachmentBlock)block;

- (void)read;

@end
