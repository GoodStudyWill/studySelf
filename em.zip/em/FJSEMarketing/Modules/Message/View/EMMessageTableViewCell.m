//
//  EMMessageTableViewCell.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/24.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMMessageTableViewCell.h"
#import "EMMessageCellFrame.h"
#import "EMMessageModel.h"

@interface EMMessageTableViewCell ()
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UIImageView *redDotImageView;

@property (weak, nonatomic) IBOutlet UIImageView *iconImageView;

@end

@implementation EMMessageTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setCellFrame:(EMMessageCellFrame *)cellFrame
{
    _cellFrame = cellFrame;
    
    EMMessageModel *model = _cellFrame.model;
    
    self.dateLabel.text = _cellFrame.dateString;
    self.titleLabel.text = model.messageTitle;
    self.contentLabel.text = model.content;
    self.redDotImageView.hidden = [model.readMark isEqualToString:@"2"] ? YES : NO;
    
    CGRect contentFrame = self.contentLabel.frame;
    contentFrame.size.height = _cellFrame.labelHeight;
    self.contentLabel.frame = contentFrame;
    
    NSString *imageName = nil;
    switch (model.messageType.integerValue) {
        case EMMessageTypePersonMsgApproval:
        case EMMessageTypeAddNewAgencyApproved:
        case EMMessageTypeMaintainAgencyApproved:
        case EMMessageTypeMonthlyAimApproved:
        {
            imageName = @"icon_success_s";
        }
            break;
            
        case EMMessageTypeMonthlyAimAlter:
        case EMMessageTypeAddNewAgencyRejection:
        case EMMessageTypeMaintainAgencyRejection:
        case EMMessageTypeMonthlyAimRejection:
        {
            imageName = @"icon_x_s";
        }
            break;
            
        default:
        {
            imageName = @"icon_!_s";
        }
            break;
    }
    
    self.iconImageView.image = [UIImage imageNamed:imageName];
}

- (void)read
{
    self.redDotImageView.hidden = YES;
}

@end
