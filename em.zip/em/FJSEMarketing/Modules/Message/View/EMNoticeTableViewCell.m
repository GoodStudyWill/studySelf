//
//  EMNoticeTableViewCell.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/27.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMNoticeTableViewCell.h"
#import "EMMessageCellFrame.h"
#import "EMMessageModel.h"

@interface EMNoticeTableViewCell ()

@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIImageView *redDotImageView;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

@property (nonatomic, copy) EMNoticeAttachmentBlock attachmentBlock;


@end

@implementation EMNoticeTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)setCellFrame:(EMMessageCellFrame *)cellFrame
{
    _cellFrame = cellFrame;
    
    EMMessageModel *model = _cellFrame.model;
    
    self.dateLabel.text = _cellFrame.dateString;
    self.titleLabel.text = model.messageTitle;
    self.contentLabel.text = model.content;
    self.redDotImageView.hidden = [model.readMark isEqualToString:@"2"] ? YES : NO;
    
    CGRect contentFrame = self.contentLabel.frame;
    contentFrame.size.height = _cellFrame.labelHeight;
    self.contentLabel.frame = contentFrame;
    
    if (model.attachmentList && model.attachmentList.count > 0) {
        CGFloat attachmentHeight = 1 + 15 + 15 + 30 * model.attachmentList.count;
        UIView *attachmentView = [[UIView alloc] initWithFrame:CGRectMake(0, _cellFrame.height-attachmentHeight, 355, attachmentHeight)];
        [self addSubview:attachmentView];
        
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH-20, 1)];
        lineView.backgroundColor = UIColorFromHex(0xeeeeee);
        [attachmentView addSubview:lineView];
        
        for (NSInteger i = 0; i < model.attachmentList.count; i++) {
            NSDictionary *attachDic = model.attachmentList[i];
            
            NSString *attachStr = @"附件: ";
            NSString *attachName = attachDic[kMessageAttachmentFileName];
            NSMutableAttributedString *attrStr = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@%@", attachStr, attachName]];
            [attrStr addAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:14],
                                     NSForegroundColorAttributeName : UIColorFromHex(0xffa32c),
                                    }
                               range:NSMakeRange(attachStr.length, attrStr.length-attachStr.length)];
            [attrStr addAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:12],
                                     NSForegroundColorAttributeName : UIColorFromHex(0x999999),
                                    }
                               range:NSMakeRange(0, attachStr.length)];
            
            UIButton *attachButton = [[UIButton alloc] initWithFrame:CGRectMake(15, 15+30*i, 325, 25)];
            [attachButton setAttributedTitle:attrStr forState:UIControlStateNormal];
            attachButton.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
            attachButton.tag = i;
            [attachButton addTarget:self action:@selector(handleAttachmentAction:) forControlEvents:UIControlEventTouchUpInside];
            [attachmentView addSubview:attachButton];
        }
    }
}

- (void)handleClickAttachmentAction:(EMNoticeAttachmentBlock)block
{
    self.attachmentBlock = block;
}

- (void)read
{
    self.redDotImageView.hidden = YES;
}

#pragma mark - Action
- (void)handleAttachmentAction:(UIButton *)sender
{
    if (self.attachmentBlock) {
        NSDictionary *attachDic = self.cellFrame.model.attachmentList[sender.tag];
        NSString *fileID = attachDic[kMessageAttachmentFileID];
        NSString *fileName = attachDic[kMessageAttachmentFileName];
        self.attachmentBlock(fileID, fileName);
    }
}


@end
