//
//  EMMessageTableViewCell.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/24.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@class EMMessageCellFrame;

@interface EMMessageTableViewCell : UITableViewCell

@property (nonatomic, strong) EMMessageCellFrame *cellFrame;

/**
 已读
 */
- (void)read;

@end
