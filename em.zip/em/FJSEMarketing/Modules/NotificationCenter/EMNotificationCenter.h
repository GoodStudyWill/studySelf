//
//  EMNotificationCenter.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT NSString * const EMNotificationCenterNewScheduleComment;

FOUNDATION_EXPORT NSString * const EMNotificationCenterKeyScheduleID;           //通知所带的scheduleID
FOUNDATION_EXPORT NSString * const EMNotificationCenterKeyScheduleDate;         //通知所带的schedule日期
FOUNDATION_EXPORT NSString * const EMNotificationCenterKeyScheduleCommentRead;  //通知所带的schedule是否已读

@class EMScheduleModel;

@interface EMNotificationCenter : NSObject

@property (nonatomic, copy) NSString *deviceToken;

/**
 单例

 @return 单例
 */
+ (EMNotificationCenter *)sharedInstance;

#pragma mark - Local notification
/**
 设置或升级本地日程推送

 @param schedule 日程
 */
- (void)setOrUpdateLocalNotificationWithSchedule:(EMScheduleModel *)schedule;

/**
 移除本地日程推送

 @param scheduleID 日程ID
 */
- (void)removeLocalNotificationWithScheduleID:(NSString *)scheduleID;

/**
 清空本地推送
 */
- (void)clearNotifications;

/**
 展示本地日程推送弹框

 @param notification 本地推送
 */
- (void)showLocalNotification:(UILocalNotification *)notification;

#pragma mark - Push notification
/**
 初始化远程推送设置
 */
- (void)initPushNotificationConfig;

/**
 展示本地缓存的最新一条远程推送弹框
 */
- (void)showPushNotificationAlertViewWithMessage;

/**
 通知刷新点评

 @param schedule 工作计划
 */
- (void)postAppraiseNotification:(EMScheduleModel *)schedule;

@end
