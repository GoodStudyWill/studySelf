//
//  EMNotificationCenter.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMNotificationCenter.h"
#import "EMScheduleModel.h"
#import "NSDate+FJSExtension.h"
#import "PushManager.h"
#import "FJSAlertView.h"
#import "EMUserManager.h"
#import "UIApplication+FJSExtension.h"
#import "FJSWebViewController.h"
#import "UIBarButtonItem+FJSUIKit.h"

static NSString * const kEMNotificationKeyScheduleID           = @"kEMNotificationKeyScheduleID";
static NSString * const kEMNotificationKeyScheduleType         = @"kEMNotificationKeyScheduleType";
static NSString * const kEMNotificationKeyScheduleCompany      = @"kEMNotificationKeyScheduleCompany";
static NSString * const kEMNotificationKeyScheduleStartDate    = @"kEMNotificationKeyScheduleStartDate";

static NSString * const kEMNotificationPushMessageTitle     = @"kEMNotificationPushMessageTitle";
static NSString * const kEMNotificationPushMessageContent   = @"kEMNotificationPushMessageContent";
static NSString * const kEMNotificationPushMessageExtention = @"kEMNotificationPushMessageExtention";

NSString * const EMNotificationCenterNewScheduleComment      = @"EMNotificationCenterNewScheduleComment";
NSString * const EMNotificationCenterKeyScheduleID           = @"EMNotificationCenterKeyScheduleID";
NSString * const EMNotificationCenterKeyScheduleDate         = @"EMNotificationCenterKeyScheduleDate";
NSString * const EMNotificationCenterKeyScheduleCommentRead  = @"EMNotificationCenterKeyScheduleCommentRead";


@interface EMNotificationCenter ()<PushManagerDelegate, DeviceTokenDelegate>

//远程推送消息缓存, 只缓存最新一条消息
@property (nonatomic, strong) NSMutableDictionary *pushMessageDict;

@end

@implementation EMNotificationCenter

+ (EMNotificationCenter *)sharedInstance
{
    static EMNotificationCenter *manager;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        manager = [[EMNotificationCenter alloc] init];
    });
    return manager;
}

#pragma mark - Local notification
///设置本地日程推送
- (void)setLocalNotificationWithSchedule:(EMScheduleModel *)schedule
{
    if ([self hasNotification:schedule.scheduleId]) {
        return;
    }
    UILocalNotification *notification = [[UILocalNotification alloc] init];
    
    NSDate *date = [NSDate fjs_dateFromString:schedule.startDate inFormat:@"yyyy-MM-dd HH:mm"];
    NSDate *nowDate = [NSDate date];
    NSTimeInterval timeInterval = [date timeIntervalSinceDate:nowDate];
    timeInterval -= [self timeIntervalBeforeScheduleHappen:schedule.reminderTimeType.integerValue];
    if (timeInterval < 0) {
        return;
    }
    
    notification.fireDate = [NSDate dateWithTimeIntervalSinceNow:timeInterval];
    notification.timeZone = [NSTimeZone defaultTimeZone];
    
    NSString *alertBody = schedule.agencyCompanyName;
    if (!alertBody || alertBody.length == 0) {
        alertBody = schedule.matter;
    }
    
    notification.alertBody = alertBody;
    
    if (SYSTEM_VERSION_GREATER_THAN(@"8.2")) {
        //本地推送为日程提醒推送，iOS8.2以上才支持推送标题
        notification.alertTitle = @"日程提醒";
    }
    
    notification.soundName = UILocalNotificationDefaultSoundName;
    NSDictionary *info = @{kEMNotificationKeyScheduleID         : schedule.scheduleId,
                           kEMNotificationKeyScheduleType       : schedule.scheduleType,
                           kEMNotificationKeyScheduleCompany    : alertBody,
                           kEMNotificationKeyScheduleStartDate  : schedule.startDate};
    notification.userInfo = info;
    
    [[UIApplication sharedApplication] scheduleLocalNotification:notification];
}

///设置或升级本地日程推送
- (void)setOrUpdateLocalNotificationWithSchedule:(EMScheduleModel *)schedule
{
    [self removeLocalNotificationWithScheduleID:schedule.scheduleId];
    [self setLocalNotificationWithSchedule:schedule];
}


/// 移除本地日程推送
- (void)removeLocalNotificationWithScheduleID:(NSString *)scheduleID
{
    for (UILocalNotification *notification in [[UIApplication sharedApplication] scheduledLocalNotifications]) {
        NSString *notiScheduleID = notification.userInfo[kEMNotificationKeyScheduleID];
        if ([scheduleID isEqualToString:notiScheduleID]) {
            [[UIApplication sharedApplication] cancelLocalNotification:notification];
            return;
        }
    }
}

///清空本地推送
- (void)clearNotifications
{
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
}

///展示本地日程推送弹框
- (void)showLocalNotification:(UILocalNotification *)notification
{
    NSString *company = notification.userInfo[kEMNotificationKeyScheduleCompany];
    NSString *startDate = notification.userInfo[kEMNotificationKeyScheduleStartDate];
    EMScheduleType scheduleType = [notification.userInfo[kEMNotificationKeyScheduleType] integerValue];
    
    FJSAlertView *alertView = [[FJSAlertView alloc] initWithScheduleCompanyName:company scheduleType:scheduleType startDate:startDate];
    [alertView setMaskViewTapToClose];
    [alertView show];
}

///是否有加入推送列表
- (BOOL)hasNotification:(NSString *)scheduleID
{
    for (UILocalNotification *notification in [[UIApplication sharedApplication] scheduledLocalNotifications]) {
        NSString *notiScheduleID = notification.userInfo[kEMNotificationKeyScheduleID];
        if ([scheduleID isEqualToString:notiScheduleID]) {
            return YES;
        }
    }
    return NO;
}

///在日程发生前多长时间推送
- (NSTimeInterval)timeIntervalBeforeScheduleHappen:(EMScheduleRemindTimeType)type
{
    switch (type) {
        case EMScheduleRemindTimeTypeOnTime:
        {
            return 0;
        }
            
        case EMScheduleRemindTimeTypeFiveMinsAgo:
        {
            return 5*60;
        }
            
        case EMScheduleRemindTimeTypeFifteenMinsAgo:
        {
            return 15*60;
        }
            
        case EMScheduleRemindTimeTypeHalfHourAgo:
        {
            return 30*60;
        }
            
        case EMScheduleRemindTimeTypeAnHourAgo:
        {
            return 60*60;
        }
            
        case EMScheduleRemindTimeTypeTwoHoursAgo:
        {
            return 2*60*60;
        }
            
        case EMScheduleRemindTimeTypeADayAgo:
        {
            return 24*60*60;
        }
            
        case EMScheduleRemindTimeTypeTwoDaysAgo:
        {
            return 2*24*60*60;
        }
            
        case EMScheduleRemindTimeTypeAWeekAgo:
        {
            return 7*24*60*60;
        }
    }
}

#pragma mark - Push notification
///初始化远程推送设置
- (void)initPushNotificationConfig
{
    [PushManager setDebugMode:YES];
    [PushManager startPushServicePushDelegate:self tokenDelegate:self];
    [PushManager setRemoteNotificationActionIMPInSDK:YES];
    [PushManager ignoreGPS:NO];
}

///展示本地缓存的最新一条远程推送弹框
- (void)showPushNotificationAlertViewWithMessage
{
    if (!self.pushMessageDict || self.pushMessageDict.count == 0) {
        return;
    }
    
    NSString *title = self.pushMessageDict[kEMNotificationPushMessageTitle];
    NSString *content = self.pushMessageDict[kEMNotificationPushMessageContent];
    NSDictionary *extention = self.pushMessageDict[kEMNotificationPushMessageExtention];
    
    [self showPushNotificationAlertViewWithTitle:title content:content extention:extention];
    [self.pushMessageDict removeAllObjects];
}

///展示推送弹框
- (void)showPushNotificationAlertViewWithTitle:(NSString *)title content:(NSString *)content extention:(NSDictionary *)extention
{
    NSString *userID = extention[@"userId"];
    if (!userID || ![userID isEqualToString:[EMUserManager sharedInstance].userID]) {
        //userID不匹配，不弹框
        return;
    }
    
    EMMessageType msgType = [extention[@"messageType"] integerValue];
    
    if (msgType == EMMessageTypeScheduleComment) {
        [self handleMessageTypeScheduleComment:extention];
        return;
    }
    
    //判断是否弹框
    BOOL noAlert = msgType == EMMessageTypeMonthlyAimApproved || msgType == EMMessageTypeAddNewAgencyApproved || msgType == EMMessageTypeMaintainAgencyApproved;
    if (noAlert) {
        return;
    }
    
    NSString *buttonTitle = @"知道了";
    FJSAlertViewType alertType = FJSAlertViewTypeWarning;
    NSString *url = nil;
    BOOL gotoUndone = NO;
    switch (msgType) {
        case EMMessageTypeSetWorkPlan:
        {
            buttonTitle = @"立即制定";
            url = kEMHtmlURLSchedule;
        }
            break;
            
        case EMMessageTypeSetMonthlyAim:
        {
            buttonTitle = @"立即制定";
            NSString *aimYear = extention[@"aimYear"];
            url = [NSString stringWithFormat:@"%@?status=3&aimYear=%@", kEMHtmlURLTargetSet, aimYear];
        }
            break;
            
        case EMMessageTypeMonthlyAimAlter:
        case EMMessageTypeMonthlyAimRejection:
        {
            buttonTitle = @"立即修改";
            alertType = FJSAlertViewTypeFailed;
            NSString *aimYear = extention[@"aimYear"];
            url = [NSString stringWithFormat:@"%@?status=1&aimYear=%@", kEMHtmlURLTargetSet, aimYear];
        }
            break;
            
        case EMMessageTypeFeedbackWorkplanCondition:
        {
            buttonTitle = @"立即反馈";
            gotoUndone = YES;
        }
            break;
            
        case EMMessageTypePersonMsgApproval:
        case EMMessageTypeAddNewAgencyApproved:
        case EMMessageTypeMaintainAgencyApproved:
        case EMMessageTypeMonthlyAimApproved:
        {
            alertType = FJSAlertViewTypeSuccess;
        }
            break;
            
        case EMMessageTypeAddNewAgencyRejection:
        case EMMessageTypeMaintainAgencyRejection:
        {
            alertType = FJSAlertViewTypeFailed;
        }
            break;
            
        default:
            break;
    }
    
    FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:alertType title:title detail:content buttonTitle:buttonTitle completionBlock:^{
        if (url) {
            FJSWebViewController *webViewController = [[FJSWebViewController alloc] initWithUrlString:url];
            webViewController.hidesBottomBarWhenPushed = YES;
            webViewController.comeFromPush = YES;
            [webViewController showLeftBarButtonItemWithImage:@"icon_back"];
            [[UIApplication fjs_currentViewController].navigationController pushViewController:webViewController animated:YES];
        } else if (gotoUndone) {
            NSString *currVCClsName = NSStringFromClass([[UIApplication fjs_currentViewController] class]);
            NSString *undoneClsName = @"EMUndoneScheduleViewController";
            Class undoneCls = NSClassFromString(undoneClsName);
            if (![currVCClsName isEqualToString:undoneClsName]) {
                UIViewController *viewController = (UIViewController *)[[undoneCls alloc] init];
                viewController.hidesBottomBarWhenPushed = YES;
                [[UIApplication fjs_currentViewController].navigationController pushViewController:viewController animated:YES];
            }
        }
    }];
    [alertView setMaskViewTapToClose];
    [alertView show];
}

#pragma mark - Handle push message
- (void)handleMessageTypeScheduleComment:(NSDictionary *)content
{
    NSString *scheduleID = content[@"scheduleId"];
    NSString *appraiseIsRead = content[@"appraiseIsRead"];
    
    EMScheduleModel *schedule = [EMScheduleModel retrieveByPrimaryKey:scheduleID];
    if (schedule) {
        schedule.appraiseIsRead = appraiseIsRead;
        [schedule update];
        
        if (![schedule.appraiseIsRead isEqualToString:@"0"]) {
            return;
        }
        
        [self postAppraiseNotification:schedule];
    }
}

- (void)postAppraiseNotification:(EMScheduleModel *)schedule
{
    NSDictionary *scheduleInfo = @{
                                   EMNotificationCenterKeyScheduleID          : [schedule.scheduleId copy] ?: @"",
                                   EMNotificationCenterKeyScheduleDate        : [schedule.date copy] ?: @"",
                                   EMNotificationCenterKeyScheduleCommentRead : [schedule.appraiseIsRead copy] ?: @"",
                                   };
    [[NSNotificationCenter defaultCenter] postNotificationName:EMNotificationCenterNewScheduleComment object:nil userInfo:scheduleInfo];
}

#pragma mark - PushManager delegate
///收到消息后的代理回调方法
-(BOOL)onMessage:(NSString *)title content:(NSString *)content extention:(NSDictionary *)extention
{
    FJSLog(@"\ntitle : %@ \ncontent : %@ \nextention : %@", title, content, [extention description]);
    if (![[EMUserManager sharedInstance] isLogin]) {
        //未登录状态，把消息缓存起来，直到登录状态再进行弹框
        [self.pushMessageDict setObject:title?:@"" forKey:kEMNotificationPushMessageTitle];
        [self.pushMessageDict setObject:content?:@"" forKey:kEMNotificationPushMessageContent];
        [self.pushMessageDict setObject:extention?:@{} forKey:kEMNotificationPushMessageExtention];
        return YES;
    }

    [self showPushNotificationAlertViewWithTitle:title content:content extention:extention];
    
    return YES;
}

///获取DeviceToken
-(void)didReciveDeviceToken:(NSString *)deviceToken
{
    FJSLog(@"didReciveDeviceToken => %@",deviceToken);
    self.deviceToken = deviceToken;
}

#pragma mark - Getter
- (NSMutableDictionary *)pushMessageDict
{
    if (!_pushMessageDict) {
        _pushMessageDict = [NSMutableDictionary dictionary];
    }
    return _pushMessageDict;
}

@end
