//
//  EMGetSpecialistInfoApi.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/9.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>

@interface EMGetSpecialistInfoApi : FJSApi

- (instancetype)initWithFlag:(NSString *)flag userID:(NSString *)userID um:(NSString *)umAccount;

@end
