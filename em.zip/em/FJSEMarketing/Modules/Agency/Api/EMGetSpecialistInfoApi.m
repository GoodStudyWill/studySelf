//
//  EMGetSpecialistInfoApi.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/9.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMGetSpecialistInfoApi.h"

@interface EMGetSpecialistInfoApi ()

@property (nonatomic, copy) NSString *flag;
@property (nonatomic, copy) NSString *userID;
@property (nonatomic, copy) NSString *channelSpecialistUM;

@end

@implementation EMGetSpecialistInfoApi

- (instancetype)initWithFlag:(NSString *)flag userID:(NSString *)userID um:(NSString *)umAccount
{
    self = [super init];
    if (self) {
        _flag = flag;
        _userID = userID;
        _channelSpecialistUM = umAccount;
    }
    return self;
}

#pragma mark - Getter
- (NSString *)requestUrl
{
    return @"agency/getChannelSpectialistInfo.do";
}

- (id)requestArgument
{
    NSDictionary *param = @{@"flag"                 : _flag ?: @"",
                            @"userId"               : _userID ?: @"",
                            @"channelSpectialistUM" : _channelSpecialistUM ?: @"",
                            };
    
    return param;
}

- (FJSRequestMethod)requestMethod
{
    return FJSRequestMethodPOST;
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

@end
