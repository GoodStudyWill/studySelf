//
//  EMAgencyViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/8.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMAgencyViewController.h"
#import "UIBarButtonItem+FJSUIKit.h"
#import "EMGetSpecialistInfoApi.h"
#import "EMUserManager.h"
#import "FJSAlertView.h"
#import "NSString+FJSExtension.h"

@interface EMAgencyViewController ()<FJSRequestDelegate, FJSWebViewControllerDelegate>

@property (nonatomic, strong) WKWebView *webView;

@end

@implementation EMAgencyViewController

@dynamic webView;

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.urlString = kEMHtmlURLAgency;
//        self.trackName = @"我的中介";
    }
    return self;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    self.webView.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - self.tabBarController.tabBar.height - 64);
    [self setupNavigationBar];
    [self refresh];
}

- (void)setupNavigationBar
{
    self.navigationController.navigationBar.barTintColor = UIColorFromHex(0x00a0ea);
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    
    UIBarButtonItem *scheduleItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"icon_search"]
                                                                     style:UIBarButtonItemStylePlain
                                                                    target:self
                                                                    action:@selector(handleLeftItemAction:)];
    
    self.navigationItem.leftBarButtonItem = scheduleItem;
    
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"新增中介"
                                                                style:UIBarButtonItemStyleDone
                                                               target:self
                                                               action:@selector(handleRightItemAction:)];
    [rightItem setTitleTextAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:14]} forState:UIControlStateNormal];
    self.navigationItem.rightBarButtonItem = rightItem;
}

#pragma mark - Action
- (void)handleLeftItemAction:(UIBarButtonItem *)sender
{
    sender.enabled = NO;
    FJSWebViewController *searchViewController = [self webViewControllerWithURL:kEMHtmlURLAgencySearch];
    searchViewController.title = @"搜索";
    [self.navigationController pushViewController:searchViewController animated:YES];
}

- (void)handleRightItemAction:(UIBarButtonItem *)sender
{
    sender.enabled = NO;
    NSString *userID = [[EMUserManager sharedInstance] userID];
    EMGetSpecialistInfoApi *api = [[EMGetSpecialistInfoApi alloc] initWithFlag:@"1" userID:userID um:userID];
    api.delegate = self;
    [api start];
}

#pragma mark - Helper
- (FJSWebViewController *)webViewControllerWithURL:(NSString *)urlStr
{
    FJSWebViewController *webViewController = [[FJSWebViewController alloc] initWithUrlString:urlStr];
    [webViewController  showLeftBarButtonItemWithImage:@"icon_back"];
    webViewController.hidesBottomBarWhenPushed = YES;
    webViewController.delegate = self;
    return webViewController;
}

- (void)showFailedAlertViewWithMsg:(NSString *)msg
{
    FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeFailed title:nil detail:msg buttonTitle:@"确定" completionBlock:nil];
    [alertView show];
}

- (void)apiRequestDidSuccess:(__kindof FJSBaseApi *)request
{
    NSDictionary *data = request.responseObject[@"data"];
    
    NSString *alertMsg = nil;
    if (!data) {
        //不存在UM账号
        alertMsg = @"非渠道专员岗请至业管系统提交新增申请";
        [self showFailedAlertViewWithMsg:alertMsg];
        return;
    }
    
    NSString *personStatusCod = data[@"personStatusCod"];
    if ([personStatusCod isEqualToString:@"PS102"]) {
        //离职
        alertMsg = @"UM账号错误";
        [self showFailedAlertViewWithMsg:alertMsg];
        return;
    }
    
    NSString *partyRoleCode = data[@"partyRoleCode"];
    if (![partyRoleCode isEqualToString:@"PR103"]) {
        //不为渠道专员
        alertMsg = @"请至人管系统添加";
        [self showFailedAlertViewWithMsg:alertMsg];
        return;
    }
    
    NSString *paicUM = data[@"paicUM"];
    NSString *name = data[@"name"];
    NSString *cityId = data[@"cityId"];
    NSString *cityName = data[@"cityName"];
    
    NSString *query = [[NSString stringWithFormat:@"paicUM=%@&name=%@&cityId=%@&cityName=%@", paicUM, name, cityId, cityName] fjs_URLEncoding];
    NSString *urlStr = [NSString stringWithFormat:@"%@?%@", kEMHtmlURLAgencyNew, query];
    FJSLog(@"urlStr => %@", urlStr);
    
    FJSWebViewController *agenyNewViewController = [self webViewControllerWithURL:urlStr];
    [self.navigationController pushViewController:agenyNewViewController animated:YES];
    
}

- (void)apiRequestDidFail:(__kindof FJSBaseApi *)request
{
    [self showFailedAlertViewWithMsg:@"网络连接错误"];
}

@end
