//
//  FJSGlobalConstant.h
//  FJSDolphinCove
//
//  Created by xuyq on 2017/5/4.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#ifndef FJSGlobalConstant_h
#define FJSGlobalConstant_h

#define MAS_SHORTHAND

//APP强制升级开关
#define __APP_FORCE_UPDATE__ 0

//APP发版时间
#define kAppVersionDate @"2017-08-28"

//高德地图Key
static NSString * const kMapKey = @"4357f1d3b3fa2492708eb5c87cb4cbed";

//考勤类型
typedef NS_ENUM(NSUInteger, EMAttendanceStatus) {
    EMAttendanceStatusGoingToWork   = 100,  //未上班
    EMAttendanceStatusOnDuty        = 101,  //上班
    EMAttendanceStatusOffDuty       = 102,  //下班
    EMAttendanceStatusAnnualLeave   = 201,  //年休假
    EMAttendanceStatusCasualLeave   = 202,  //事假
    EMAttendanceStatusSickLeave     = 203,  //病假
    EMAttendanceStatusOther         = 204,  //其他
    EMAttendanceStatusError         = 0,    //打卡异常
};

//请求消息类型
typedef NS_ENUM(NSUInteger, EMRequestMessageType) {
    EMRequestMessageTypeMessage = 1,    //请求消息
    EMRequestMessageTypeNotice = 2,     //请求公告
};

//消息类型
typedef NS_ENUM(NSUInteger, EMMessageType) {
    EMMessageTypeCommonCheck_0              = 110,   //业务核对提醒_0
    EMMessageTypeCommonCheck_1              = 111,   //业务核对提醒_1
    EMMessageTypeCommonClose                = 120,   //结佣人员通道关闭提醒
    EMMessageTypeCommonNotMatch             = 130,   //未配对订单超时提醒
    EMMessageTypePersonMsgApproval          = 210,   //申请审批完成通知
    EMMessageTypeAgencySealRemind           = 310,   //提交用印提醒
    EMMessageTypeAddNewAgencyApproved       = 311,   //新增中介公司审批通过
    EMMessageTypeAddNewAgencyRejection      = 312,   //新增中介公司审批拒绝
    EMMessageTypeMaintainAgencyApproved     = 313,   //维护中介公司审批通过
    EMMessageTypeMaintainAgencyRejection    = 314,   //维护中介公司审批拒绝
    EMMessageTypeAgencyIsException          = 315,   //中介异常提醒
    EMMessageTypeSetMonthlyAim              = 330,   //请制定月度目标
    EMMessageTypeMonthlyAimApproved         = 331,   //月度目标审批通过
    EMMessageTypeMonthlyAimAlter            = 332,   //请修改月度目标
    EMMessageTypeMonthlyAimRejection        = 333,   //月度目标审批拒绝
    EMMessageTypeSetWorkPlan                = 340,   //请制定工作规划
    EMMessageTypeFeedbackWorkplanCondition  = 341,   //请反馈工作规划完成情况
    EMMessageTypeScheduleComment            = 666,   //经理点评工作计划，静默推送
};

#endif /* FJSGlobalConstant_h */
