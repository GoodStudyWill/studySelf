//
//  EMHtmlURL.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/8.
//  Copyright © 2017年 pingan. All rights reserved.
//

#ifndef EMHtmlURL_h
#define EMHtmlURL_h

#pragma mark - 首页
//首页放款
static NSString * const kEMHtmlURLHomeAchieve   = @"index.html#/home/achieve";
//首页申请
static NSString * const kEMHtmlURLHomeApply     = @"index.html#/home/apply";
//首页开单
static NSString * const kEMHtmlURLHomeOrder     = @"index.html#/home/order";

#pragma mark - 考勤
//考勤请假
static NSString * const kEMHtmlURLAttendLeave   = @"index.html#/leave";

#pragma mark - 中介
//中介首页
static NSString * const kEMHtmlURLAgency        = @"index.html#/agency";
//中介搜索
static NSString * const kEMHtmlURLAgencySearch  = @"index.html#/search";
//新增中介
static NSString * const kEMHtmlURLAgencyNew     = @"index.html#/agency/new";

#pragma mark - 月度目标
//月度目标
static NSString * const kEMHtmlURLTarget        = @"index.html#/target";
//制定月度目标
static NSString * const kEMHtmlURLTargetSet     = @"index.html#/target/set";

#pragma mark - 工作计划
//工作计划
static NSString * const kEMHtmlURLSchedule  = @"index.html#/plan?scheduleId=";

#endif /* EMHtmlURL_h */
