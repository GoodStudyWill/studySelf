//
//  AppDelegate.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/6.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "AppDelegate.h"
#import "AppDelegate+EMService.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

#pragma mark - Life cyele
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    [self configureNetwork];
    [self configureMapKey];
    [self configurePushNotification:application];
    [self setupTalkingData];
    [self setupWindow];
    return YES;
}

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification
{
    [self handleLocalNotification:notification];
}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult))completionHandler
{
    FJSLog(@"userInfo => %@", userInfo);
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    
}


- (void)applicationDidEnterBackground:(UIApplication *)application
{
    
}


- (void)applicationWillEnterForeground:(UIApplication *)application
{
    
}


- (void)applicationDidBecomeActive:(UIApplication *)application
{
    
}


- (void)applicationWillTerminate:(UIApplication *)application
{
    
}

@end
