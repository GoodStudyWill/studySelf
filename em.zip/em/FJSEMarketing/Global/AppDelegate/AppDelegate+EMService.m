//
//  AppDelegate+EMService.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <AMapFoundationKit/AMapFoundationKit.h>
#import "AppDelegate+EMService.h"
#import "EMAppConfig.h"
#import "EMTabBarController.h"
#import "EMLoginService.h"
#import "EMUserManager.h"
#import "FJSAlertView.h"
#import "EMNotificationCenter.h"
#import "PACollectTalkingData.h"
#import "PushManager.h"

@implementation AppDelegate (EMService)

#pragma mark - Configure
- (void)configureNetwork
{
    [[EMAppConfig sharedInstance] initNetworkConfig];
}

- (void)configureMapKey
{
    [AMapServices sharedServices].apiKey = (NSString *)kMapKey;
}

- (void)configurePushNotification:(UIApplication *)application
{
    [[EMNotificationCenter sharedInstance] initPushNotificationConfig];
    
    UIUserNotificationSettings *setting = [UIUserNotificationSettings settingsForTypes:UIUserNotificationTypeBadge|UIUserNotificationTypeSound|UIUserNotificationTypeAlert categories:nil];
    [application registerUserNotificationSettings:setting];
}

#pragma mark - Setup
- (void)setupWindow
{
    [EMUserManager sharedInstance];
    
    [UIApplication sharedApplication].statusBarStyle = UIStatusBarStyleLightContent;
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.rootViewController = [EMLoginService loginViewControllerPresent];
    
    [self.window makeKeyAndVisible];
}

#pragma mark - Notification
- (void)handleLocalNotification:(UILocalNotification *)notification
{
    [[EMNotificationCenter sharedInstance] showLocalNotification:notification];
}

#pragma mark - Track
- (void)setupTalkingData
{
    [TalkingData setExceptionReportEnabled:YES];//允许异常
    [TalkingData setSignalReportEnabled:YES];//允许异常信号量
    
#ifdef DEBUG
    [TalkingData setLogEnabled:NO];//开启日志，发布版本请关闭
#else
    [TalkingData setLogEnabled:NO];//关闭日志，发布版本请关闭
#endif
    [TalkingData sessionStarted:[EMAppConfig sharedInstance].talkingDataAppKey withChannelId:@"企业证书"];
    
    [TalkingData setCodelessEnable:YES];
    
    [PACollectTalkingData sessionStarted];
}


@end
