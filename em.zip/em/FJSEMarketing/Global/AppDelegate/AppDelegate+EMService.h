//
//  AppDelegate+EMService.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (EMService)

/**
 初始化网络配置
 */
- (void)configureNetwork;

/**
 初始化地图配置
 */
- (void)configureMapKey;

/**
 初始化推送通知配置
 */
- (void)configurePushNotification:(UIApplication *)application;

/**
 设置window
 */
- (void)setupWindow;

#pragma mark - Notification

- (void)handleLocalNotification:(UILocalNotification *)notification;

#pragma mark - Track
- (void)setupTalkingData;

@end
