//
//  WKWebView+FJSJavaScript.m
//  PADolphinCove
//
//  Created by xuyq on 2017/5/18.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import "WKWebView+FJSJavaScript.h"
#import "NSDictionary+FJSJavaScript.h"

@implementation WKWebView (FJSJavaScript)

- (void)fjs_evaluateJavaScriptString:(NSString *)jsStr
{
    [self evaluateJavaScript:jsStr completionHandler:nil];
}

- (void)fjs_callBackEvaluateJavaScriptString:(NSDictionary *)params
{
    NSString *jsStr = [params fjs_javaScriptStringForCallBack];
    [self evaluateJavaScript:jsStr completionHandler:nil];
}

- (void)fjs_onBackEvaluateJavaScriptString:(NSDictionary *)params
{
    NSString *jsStr = [params fjs_javaScriptStringForOnBack];
    [self evaluateJavaScript:jsStr completionHandler:nil];
}

- (void)fjs_evaluateRefresh
{
    NSString *jsStr = @"$$.EventListener.refresh()";
    [self fjs_evaluateJavaScriptString:jsStr];
}

- (void)fjs_evaluateRefreshURL:(NSString *)url
{
    NSString *jsStr = [NSString stringWithFormat:@"$$.EventListener.refreshURL('%@')", url];
    [self fjs_evaluateJavaScriptString:jsStr];
}

@end
