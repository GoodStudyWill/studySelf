//
//  WKWebView+FJSJavaScript.h
//  PADolphinCove
//
//  Created by xuyq on 2017/5/18.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import <WebKit/WebKit.h>

@interface WKWebView (FJSJavaScript)

- (void)fjs_evaluateJavaScriptString:(NSString *)jsStr;

- (void)fjs_callBackEvaluateJavaScriptString:(NSDictionary *)params;

- (void)fjs_onBackEvaluateJavaScriptString:(NSDictionary *)params;

- (void)fjs_evaluateRefresh;

//按揭刷新URL
- (void)fjs_evaluateRefreshURL:(NSString *)url;

@end
