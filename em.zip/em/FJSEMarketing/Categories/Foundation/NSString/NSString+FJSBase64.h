//
//  NSString+FJSBase64.h
//  PADolphinCove
//
//  Created by xuyq on 2017/5/23.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (FJSBase64)

/**
 对字符串进行Base64编码

 @return Base64编码后的字符串
 */
- (NSString *)fjs_base64EncodedString;

/**
 对字符串进行Base64解码

 @return Base64解码后的字符串
 */
- (NSString *)fjs_base64DecodedString;

@end
