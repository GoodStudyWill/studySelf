//
//  NSString+FJSExtension.h
//  PADolphinCove
//
//  Created by xuyq on 2017/5/25.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (FJSExtension)

/**
 去除字符串的空格和换行符

 @return 去除空格和换行符后的字符串
 */
- (NSString *)fjs_trimString;

/**
 判断是否URL

 @return 是否URL
 */
- (BOOL)fjs_isURL;

/**
 URL编码

 @return 编码后的字符串
 */
- (NSString *)fjs_URLEncoding;

/**
 URL解码

 @return 解码后的字符串
 */
- (NSString *)fjs_URLDecoding;

/**
 JSON字符串转换成字典类型

 @return JSON字典
 */
- (NSDictionary *)fjs_JSONDictionary;

/**
 获取字符串高度

 @param font 字体大小
 @param width 宽度
 @return 高度
 */
- (CGFloat)fjs_heightForFont:(UIFont *)font width:(CGFloat)width;

@end
