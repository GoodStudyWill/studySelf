//
//  NSString+FJSExtension.m
//  PADolphinCove
//
//  Created by xuyq on 2017/5/25.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import "NSString+FJSExtension.h"

@implementation NSString (FJSExtension)

- (NSString *)fjs_trimString
{
    NSMutableString *mutableStr = [NSMutableString stringWithString:self];
    
    //去除空格
    NSRange range1 = {0, self.length};
    [mutableStr replaceOccurrencesOfString:@" " withString:@"" options:NSLiteralSearch range:range1];
    
    //去除换行符
    NSRange range2 = {0, mutableStr.length};
    [mutableStr replaceOccurrencesOfString:@"\n" withString:@"" options:NSLiteralSearch range:range2];
    return [mutableStr copy];
}

- (BOOL)fjs_isURL
{
    NSString *regex = @"http(s)?:\\/\\/([\\w-]+\\.)+[\\w-]+(\\/[\\w- .\\/?%&=]*)?";
    NSPredicate *pred = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    
    return [pred evaluateWithObject:self];
}

- (NSString *)fjs_URLEncoding
{
    return [self stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
}

- (NSString *)fjs_URLDecoding
{
    NSMutableString * string = [NSMutableString stringWithString:self];
    [string replaceOccurrencesOfString:@"+"
                            withString:@" "
                               options:NSLiteralSearch
                                 range:NSMakeRange(0, [string length])];
    return [string stringByRemovingPercentEncoding];
}

- (NSDictionary *)fjs_JSONDictionary
{
    NSError  *error;
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:[self dataUsingEncoding:NSUTF8StringEncoding] options:NSJSONReadingMutableContainers error:&error];
 
    if (error) {
        FJSLog(@"%@", error);
    }
    return dict;
}

- (CGFloat)fjs_heightForFont:(UIFont *)font width:(CGFloat)width
{
    if (self && font) {
        CGRect rect = [self boundingRectWithSize:CGSizeMake(width, FLT_MAX) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName : font}  context:nil];
        return rect.size.height;
    }
    return 0;
}

@end
