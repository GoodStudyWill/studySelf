//
//  NSString+FJSSecurity.m
//  PADolphinCove
//
//  Created by xuyq on 2017/6/26.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import "NSString+FJSSecurity.h"
#import "FJSRSAUtil.h"

static NSString * const kFJSRSAPublicKey = @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCeabYScyccBwY6ieOcVkz/8RwQZSRQxpaVf+rIv3/k9+yxxBtKeK9F8yP3JDTZCr2mYXNlgdBU0OfX6472JrrQaHx5HF6pEjcVUzX34QsfoD+Z4e4zczktg1DEhVo2B7S3p7Rn9VPTTDfVB4s3x0sSge3goqRm1gwJCLaCZqeK+QIDAQAB";

@implementation NSString (FJSSecurity)

- (NSString *)fjs_RSAEncrypt
{
    return [FJSRSAUtil encryptString:self publicKey:kFJSRSAPublicKey];
}

- (NSString *)fjs_RSADecrypt
{
    NSString *encryptedStr = [FJSRSAUtil decryptString:self publicKey:kFJSRSAPublicKey];
    return encryptedStr;
}

@end
