//
//  NSString+FJSSecurity.h
//  PADolphinCove
//
//  Created by xuyq on 2017/6/26.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (FJSSecurity)

- (NSString *)fjs_RSAEncrypt;

- (NSString *)fjs_RSADecrypt;

@end
