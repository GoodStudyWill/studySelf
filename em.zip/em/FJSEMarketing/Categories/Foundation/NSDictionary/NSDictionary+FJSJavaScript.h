//
//  NSDictionary+FJSJavaScript.h
//  FJSWebDemo
//
//  Created by xuyq on 2017/1/17.
//  Copyright © 2017年 xuyq. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (FJSJavaScript)

- (NSString *)fjs_jsonString;

- (NSString *)fjs_jsonStringWithBlank;

- (NSString *)fjs_javaScriptStringForCallBack;

- (NSString *)fjs_javaScriptStringForOnBack;

@end
