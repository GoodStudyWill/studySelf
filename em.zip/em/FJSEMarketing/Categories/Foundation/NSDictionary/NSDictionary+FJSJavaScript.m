//
//  NSDictionary+FJSJavaScript.m
//  FJSWebDemo
//
//  Created by xuyq on 2017/1/17.
//  Copyright © 2017年 xuyq. All rights reserved.
//

#import "NSDictionary+FJSJavaScript.h"

@implementation NSDictionary (FJSJavaScript)

#pragma mark - API
- (NSString *)fjs_jsonString
{
    NSString *jsonStrWithBlank = [self fjs_jsonStringWithBlank];
    return [self trimString:jsonStrWithBlank];
}

- (NSString *)fjs_jsonStringWithBlank
{
    NSError *error;
    NSData *jsonData = [NSJSONSerialization dataWithJSONObject:self options:NSJSONWritingPrettyPrinted error:&error];
    
    NSString *jsonStr = nil;
    if (!jsonData) {
        return nil;
    }
    
    jsonStr = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    return jsonStr;
}

- (NSString *)fjs_javaScriptStringForCallBack
{
    NSString *methodName = self[@"callback"];
    NSDictionary *params = self[@"params"];
    NSString *paramsStr = [params fjs_jsonStringWithBlank];
    NSString *callBack = nil;
    if (params && params.count > 0) {
        callBack = [NSString stringWithFormat:@"$$.platformAdapter.callback('%@',null,%@)", methodName?:@"", paramsStr?:@""];
    } else {
        callBack = [NSString stringWithFormat:@"$$.platformAdapter.callback('%@',null,'')", methodName?:@""];
    }
    
    FJSLog(@"callBack => %@",callBack);
    
    return callBack;
}

- (NSString *)fjs_javaScriptStringForOnBack
{
    NSString *urlStr = self[@"url"];
    
    //data可能是字典或者字符串，按照传过来的传回去
    id data = self[@"data"];
    NSString *onBack = nil;
    if ([data isKindOfClass:[NSDictionary class]]) {
        onBack = [NSString stringWithFormat:@"$$.EventListener.onBack('%@',%@)", urlStr, [(NSDictionary *)data fjs_jsonStringWithBlank]];
    } else {
        onBack = [NSString stringWithFormat:@"$$.EventListener.onBack('%@','%@')", urlStr, (NSString *)data?:@""];
    }
    FJSLog(@"onBack => %@", onBack);
    
    return onBack;
}

#pragma mark - Handle String
- (NSString *)trimString:(NSString *)str
{
    NSMutableString *mutableStr = [NSMutableString stringWithString:str];
    
    //去除空格
    NSRange range1 = {0, str.length};
    [mutableStr replaceOccurrencesOfString:@" " withString:@"" options:NSLiteralSearch range:range1];
    
    //去除换行符
    NSRange range2 = {0, mutableStr.length};
    [mutableStr replaceOccurrencesOfString:@"\n" withString:@"" options:NSLiteralSearch range:range2];
    
    return [mutableStr copy];
}

@end
