//
//  NSDate+FJSExtension.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "NSDate+FJSExtension.h"

@implementation NSDate (FJSExtension)

#pragma mark - Date
//获取今日日期
+ (NSString *)fjs_todayInFormat:(NSString *)format
{
    NSDate *date = [NSDate date];
    return [date fjs_dateInFormat:format];
}

//获取日期
- (NSString *)fjs_dateInFormat:(NSString *)format
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:format];
    return [formatter stringFromDate:self];
}

+ (NSDate *)fjs_dateFromString:(NSString *)dateStr inFormat:(NSString *)format
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:format];
    return [formatter dateFromString:dateStr];
}

+ (NSDate *)fjs_dateFromString:(NSString *)dateStr
{
    return [self fjs_dateFromString:dateStr inFormat:@"yyyy-MM-dd HH:mm:ss"];
}

+ (NSString *)fjs_dateStringFromString:(NSString *)dateStr intoFormat:(NSString *)format
{
    NSDate *date = [self fjs_dateFromString:dateStr];
    return [date fjs_dateInFormat:format];
}

#pragma mark - Week
//获取今天星期几
+ (NSString *)fjs_weekDayOfToday
{
    NSDate *date = [NSDate date];
    return [date fjs_weekDay];
}

//获取星期几
- (NSString *)fjs_weekDay
{
    NSArray *weekdays = @[[NSNull null], @"周日", @"周一", @"周二", @"周三", @"周四", @"周五", @"周六"];
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSTimeZone *timeZone = [NSTimeZone systemTimeZone];
    [calendar setTimeZone:timeZone];
    NSCalendarUnit calendarUnit = NSCalendarUnitWeekday;
    NSDateComponents *theComponents = [calendar components:calendarUnit fromDate:self];
    return [weekdays objectAtIndex:theComponents.weekday];
}

@end
