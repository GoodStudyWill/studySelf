//
//  NSDate+FJSExtension.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (FJSExtension)

// ===============================Date======================================
/**
 获取今日日期

 @param format 格式
 @return 今日日期
 */
+ (NSString *)fjs_todayInFormat:(NSString *)format;

/**
 获取日期

 @param format 日期格式
 @return 日期
 */
- (NSString *)fjs_dateInFormat:(NSString *)format;

/**
 将某种格式的日期字符串转成NSDate对象

 @param dateStr 日期字符串
 @param format 格式
 @return NSDate对象
 */
+ (NSDate *)fjs_dateFromString:(NSString *)dateStr inFormat:(NSString *)format;

/**
 将"yyyy-MM-dd HH:mm:ss"格式的日期字符串转成NSDate对象

 @param dateStr 日期字符串
 @return NSDate对象
 */
+ (NSDate *)fjs_dateFromString:(NSString *)dateStr;

/**
 将某种格式的日期字符串转成另外一种格式

 @param dateStr 日期字符串
 @param format 要转的日期格式
 @return 转换后的日期字符串
 */
+ (NSString *)fjs_dateStringFromString:(NSString *)dateStr intoFormat:(NSString *)format;

// ===============================Week======================================
/**
 获取今天星期几
 
 @return 今天星期几
 */
+ (NSString *)fjs_weekDayOfToday;

/**
 获取星期几
 
 @return 星期几
 */
- (NSString *)fjs_weekDay;

@end
