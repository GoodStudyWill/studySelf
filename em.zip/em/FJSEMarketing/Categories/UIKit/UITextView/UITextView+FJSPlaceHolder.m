//
//  UITextView+FJSPlaceHolder.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/11/6.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <objc/runtime.h>
#import "UITextView+FJSPlaceHolder.h"

static const void *fjs_placeHolderKey;

@interface UITextView ()

@property (nonatomic, readonly) UILabel *fjs_placeHolderLabel;

@end

@implementation UITextView (FJSPlaceHolder)

+ (void)load
{
    [super load];
    method_exchangeImplementations(class_getInstanceMethod(self.class, NSSelectorFromString(@"layoutSubviews")),
                                   class_getInstanceMethod(self.class, @selector(fjs_layoutSubviewsSwizzled)));
    method_exchangeImplementations(class_getInstanceMethod(self.class, NSSelectorFromString(@"dealloc")),
                                   class_getInstanceMethod(self.class, @selector(fjs_deallocSwizzled)));
    method_exchangeImplementations(class_getInstanceMethod(self.class, NSSelectorFromString(@"setText:")),
                                   class_getInstanceMethod(self.class, @selector(fjs_setTextSwizzled:)));
}

#pragma mark - swizzled
- (void)fjs_deallocSwizzled
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    [self fjs_deallocSwizzled];
}

- (void)fjs_layoutSubviewsSwizzled
{
    if (self.fjs_placeHolder) {
        UIEdgeInsets textContainerInset = self.textContainerInset;
        CGFloat lineFragmentPadding = self.textContainer.lineFragmentPadding;
        CGFloat x = lineFragmentPadding + textContainerInset.left + self.layer.borderWidth;
        CGFloat y = textContainerInset.top + self.layer.borderWidth;
        CGFloat width = CGRectGetWidth(self.bounds) - x - textContainerInset.right - 2*self.layer.borderWidth;
        CGFloat height = [self.fjs_placeHolderLabel sizeThatFits:CGSizeMake(width, 0)].height;
        self.fjs_placeHolderLabel.frame = CGRectMake(x, y, width, height);
    }
    [self fjs_layoutSubviewsSwizzled];
}

- (void)fjs_setTextSwizzled:(NSString *)text
{
    [self fjs_setTextSwizzled:text];
    if (self.fjs_placeHolder) {
        [self updatePlaceHolder];
    }
}

#pragma mark - associated
- (NSString *)fjs_placeHolder
{
    return objc_getAssociatedObject(self, &fjs_placeHolderKey);
}

- (void)setFjs_placeHolder:(NSString *)fjs_placeHolder
{
    objc_setAssociatedObject(self, &fjs_placeHolderKey, fjs_placeHolder, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self updatePlaceHolder];
}

- (UIColor *)fjs_placeHolderColor
{
    return self.fjs_placeHolderLabel.textColor;
}

- (void)setFjs_placeHolderColor:(UIColor *)fjs_placeHolderColor
{
    self.fjs_placeHolderLabel.textColor = fjs_placeHolderColor;
}

#pragma mark - update
- (void)updatePlaceHolder
{
    if (self.text.length) {
        [self.fjs_placeHolderLabel removeFromSuperview];
        return;
    }
    self.fjs_placeHolderLabel.font = self.font?self.font:self.cacutDefaultFont;
    self.fjs_placeHolderLabel.textAlignment = self.textAlignment;
    self.fjs_placeHolderLabel.text = self.fjs_placeHolder;
    [self insertSubview:self.fjs_placeHolderLabel atIndex:0];
}

#pragma mark - lazzing
- (UILabel *)fjs_placeHolderLabel
{
    UILabel *placeHolderLab = objc_getAssociatedObject(self, @selector(fjs_placeHolderLabel));
    if (!placeHolderLab) {
        placeHolderLab = [[UILabel alloc] init];
        placeHolderLab.numberOfLines = 0;
        placeHolderLab.textColor = [UIColor lightGrayColor];
        objc_setAssociatedObject(self, @selector(fjs_placeHolderLabel), placeHolderLab, OBJC_ASSOCIATION_RETAIN);
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updatePlaceHolder) name:UITextViewTextDidChangeNotification object:self];
    }
    return placeHolderLab;
}

- (UIFont *)cacutDefaultFont
{
    static UIFont *font = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        UITextView *textview = [[UITextView alloc] init];
        textview.text = @" ";
        font = textview.font;
    });
    return font;
}

@end
