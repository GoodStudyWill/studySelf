//
//  UILabel+FJSVerticalAlign.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/17.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (FJSVerticalAlign)

- (void)fjs_alignTop;
- (void)fjs_alignBottom;

@end
