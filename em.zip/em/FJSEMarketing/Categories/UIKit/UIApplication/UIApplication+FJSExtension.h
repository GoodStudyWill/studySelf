//
//  UIApplication+FJSExtension.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/8.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIApplication (FJSExtension)

+ (UIViewController *)fjs_rootViewController;

//获取Window当前显示的ViewController
+ (UIViewController*)fjs_currentViewController;

@end
