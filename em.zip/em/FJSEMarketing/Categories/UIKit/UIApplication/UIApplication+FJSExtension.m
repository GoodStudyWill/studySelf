//
//  UIApplication+FJSExtension.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/8.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "UIApplication+FJSExtension.h"
#import "UIViewController+FJSExtension.h"

@implementation UIApplication (FJSExtension)

+ (UIViewController *)fjs_rootViewController
{
    UIWindow *window = [UIApplication sharedApplication].keyWindow;
    return window.rootViewController;
}

//获取Window当前显示的ViewController
//+ (UIViewController*)fjs_currentViewController
//{
//    UIViewController* vc = [UIApplication fjs_rootViewController];
//    return [vc fjs_topViewController];
//}

+ (UIViewController *)fjs_currentViewController
{
    UIViewController *currentVC = [self getCurrentVCFrom:[self fjs_rootViewController]];
    
    return currentVC;
}

+ (UIViewController *)getCurrentVCFrom:(UIViewController *)rootVC
{
    UIViewController *currentVC;
    
    if ([rootVC presentedViewController]) {
        // 视图是被presented出来的
        
        rootVC = [rootVC presentedViewController];
    }
    
    if ([rootVC isKindOfClass:[UITabBarController class]]) {
        // 根视图为UITabBarController
        
        currentVC = [self getCurrentVCFrom:[(UITabBarController *)rootVC selectedViewController]];
        
    } else if ([rootVC isKindOfClass:[UINavigationController class]]){
        // 根视图为UINavigationController
        
        currentVC = [self getCurrentVCFrom:[(UINavigationController *)rootVC visibleViewController]];
        
    } else {
        // 根视图为非导航类
        
        currentVC = rootVC;
    }
    
    return currentVC;
}

@end
