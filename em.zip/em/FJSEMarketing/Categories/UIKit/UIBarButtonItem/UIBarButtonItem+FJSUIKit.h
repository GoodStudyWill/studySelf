//
//  UIBarButtonItem+PAHybrid.h
//  PAKepler
//
//  Created by Lips蔡 on 15/11/12.
//  Copyright © 2015年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (FJSUIKit)

@property (nonatomic) UIColor * barButtonItemColor;

/**
 *  显示导航栏右边文字按钮
 *
 *  @param title    按钮文字
 *  @param target   点击者
 *  @param selector 点击事件
 */
+ (instancetype)showRightBarButtonItemWithTitle:(NSString *)title
                                     titleColor:(UIColor *)titleColor
                                         target:(id)target
                                       selector:(SEL)selector;

/**
 *  显示导航栏右边图片按钮
 *
 *  @param imageName 图片
 *  @param target    点击者
 *  @param selector  点击事件
 */
+(instancetype)showRightBarButtonItemWithImage:(NSString *)imageName
                                        target:(id)target
                                      selector:(SEL)selector;

/**
 *  显示导航栏右边文字按钮 或 图片按钮
 *
 *  @param title     文字
 *  @param imageName 图片
 *  @param target    点击者
 *  @param selector  点击事件
 */
+(instancetype)showRightBarButtonItemWithTitle:(NSString *)title
                                   orButtonImage:(NSString *)imageName
                                    titleColor:(UIColor *)titleColor
                                        target:(id)target
                                      selector:(SEL)selector;

/**
 *  显示导航栏左边文字按钮
 *
 *  @param title    标题
 *  @param target   点击者
 *  @param selector 点击事件
 *
 */
+(instancetype)showLeftBarButtonItemWithTitle:(NSString *)title
                                       target:(id)target
                                     selector:(SEL)selector;

/**
 *  显示导航栏左边图片按钮
 *
 *  @param imageName 图片
 *  @param target    点击者
 *  @param selector  点击事件
 *
 */
+(instancetype)showLeftBarButtonItemWithImage:(NSString *)imageName
                                       target:(id)target
                                     selector:(SEL)selector;

/**
 *  显示导航栏左边文字按钮 或 图片按钮
 *
 *  @param title     标题
 *  @param imageName 图片
 *  @param target    点击者
 *  @param selector  点击事件
 *
 */
+(instancetype)showLeftBarButtonItemWithTitle:(NSString *)title
                                orButtonImage:(NSString *)imageName
                                       target:(id)target
                                     selector:(SEL)selector;

/**
 *  <#Description#>
 *
 *  @param title     <#title description#>
 *  @param imageName <#imageName description#>
 *  @param target    <#target description#>
 *  @param selector  <#selector description#>
 *
 *  @return <#return value description#>
 */
+ (instancetype)showBackBarButtonItemWithTitle:(NSString *)title
                                 orButtonImage:(NSString *)imageName
                                        target:(id)target
                                      selector:(SEL)selector;

@end
