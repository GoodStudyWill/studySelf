//
//  UIBarButtonItem+PAHybrid.m
//  PAKepler
//
//  Created by Lips蔡 on 15/11/12.
//  Copyright © 2015年 pingan. All rights reserved.
//

#import "UIBarButtonItem+FJSUIKit.h"
#import <objc/runtime.h>

NSString const * __barButtonItemColor__ = @"__barButtonItemColor__";

@implementation UIBarButtonItem (FJSUIKit)

-(UIColor *)barButtonItemColor {
    return objc_getAssociatedObject(self, &__barButtonItemColor__);
}

-(void)setBarButtonItemColor:(UIColor *)barButtonItemColor {
    objc_setAssociatedObject(self, &__barButtonItemColor__, barButtonItemColor, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

+ (instancetype)showRightBarButtonItemWithTitle:(NSString *)title
                                     titleColor:(UIColor *)titleColor
                                        target:(id)target
                                      selector:(SEL)selector {
    return [self showRightBarButtonItemWithTitle:title orButtonImage:nil titleColor:titleColor target:target selector:selector];
}

+ (instancetype)showRightBarButtonItemWithImage:(NSString *)imageName
                                        target:(id)target
                                      selector:(SEL)selector {
    return [self showRightBarButtonItemWithTitle:nil orButtonImage:imageName titleColor:nil target:target selector:selector];
}

+ (instancetype)showRightBarButtonItemWithTitle:(NSString *)title
                                orButtonImage:(NSString *)imageName
                                     titleColor:(UIColor *)titleColor
                                        target:(id)target
                                      selector:(SEL)selector {
    
    UIButton * rightButton = [self __showBarButtonItemWitTitle:title imageName:imageName target:target selector:selector];
    [rightButton setTitleColor:titleColor forState:UIControlStateNormal];
    return [[UIBarButtonItem alloc] initWithCustomView:rightButton];
}

+ (instancetype)showLeftBarButtonItemWithTitle:(NSString *)title
                                       target:(id)target
                                     selector:(SEL)selector {
    
    return [self showLeftBarButtonItemWithTitle:title orButtonImage:nil target:target selector:selector];
}

+ (instancetype)showLeftBarButtonItemWithImage:(NSString *)imageName
                                       target:(id)target
                                     selector:(SEL)selector {
    return [self showLeftBarButtonItemWithTitle:nil orButtonImage:imageName target:target selector:selector];
}

+ (instancetype)showLeftBarButtonItemWithTitle:(NSString *)title
                                orButtonImage:(NSString *)imageName
                                       target:(id)target
                                     selector:(SEL)selector {
    
    UIButton * leftButton = [self __showBarButtonItemWitTitle:title imageName:imageName target:target selector:selector];
    leftButton.imageEdgeInsets = UIEdgeInsetsMake(0, -15, 0, 15);
    return [[UIBarButtonItem alloc] initWithCustomView:leftButton];
}

+ (instancetype)showBackBarButtonItemWithTitle:(NSString *)title
                                 orButtonImage:(NSString *)imageName
                                        target:(id)target
                                      selector:(SEL)selector {
    
    UIButton * backButton = [self __showBarButtonItemWitTitle:title imageName:imageName target:target selector:selector];
    backButton.imageEdgeInsets = UIEdgeInsetsMake(0, 64, 0, 20);
    return [[UIBarButtonItem alloc] initWithCustomView:backButton];
}

+ (UIButton *)__showBarButtonItemWitTitle:(NSString *)title
                               imageName:(NSString *)imageName
                                  target:(id)target
                                selector:(SEL)selector {
    UIButton * barButtonItem = [UIButton buttonWithType:UIButtonTypeCustom];
    if (title == nil || [title isEqualToString:@""]) {

        [barButtonItem setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
        barButtonItem.frame = CGRectMake(0, 0, 44, 44);
    }else {
        
        [barButtonItem setTitle:title forState:UIControlStateNormal];
//        CGFloat buttonWidth = [title sizeWithFont:barButtonItem.font].width;
        CGFloat buttonWidth = [title sizeWithAttributes:@{NSFontAttributeName:barButtonItem.titleLabel.font}].width;
        barButtonItem.frame = CGRectMake(0, 0, 40, buttonWidth);
    }
    [barButtonItem addTarget:target action:selector forControlEvents:UIControlEventTouchUpInside];
    
    return barButtonItem;
}

@end
