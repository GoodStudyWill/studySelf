//
//  UIViewController+FJSExtension.h
//  PADolphinCove
//
//  Created by xuyq on 2017/6/26.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (FJSExtension)

- (UIViewController*)fjs_topViewController;

@end
