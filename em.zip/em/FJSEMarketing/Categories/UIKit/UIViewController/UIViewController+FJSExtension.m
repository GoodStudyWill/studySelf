//
//  UIViewController+FJSExtension.m
//  PADolphinCove
//
//  Created by xuyq on 2017/6/26.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import "UIViewController+FJSExtension.h"

@implementation UIViewController (FJSExtension)

- (UIViewController*)fjs_topViewController
{
    if (self.presentedViewController) {
        return [self.presentedViewController fjs_topViewController];
    }
    else if ([self isKindOfClass:[UINavigationController class]]) {
        UINavigationController* nav = (UINavigationController*)self;
        UIViewController* top = [nav topViewController];
        return [top fjs_topViewController];
    }
    else if ([self isKindOfClass:[UITabBarController class]]) {
        UINavigationController *nav = [(UITabBarController*)self selectedViewController];
        UIViewController *top = [nav topViewController];
        return [top fjs_topViewController];
    }
    return self;
}

@end
