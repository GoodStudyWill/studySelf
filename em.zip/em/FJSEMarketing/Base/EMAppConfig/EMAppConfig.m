//
//  EMAppConfig.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>
#import "EMAppConfig.h"
#import "NSString+FJSBase64.h"
#import "EMUserManager.h"
NSString * const kAESKey = @"^O'*P#!&/@%Mg*T$";
NSString * const kRSAPublicKey = @"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCeabYScyccBwY6ieOcVkz/8RwQZSRQxpaVf+rIv3/k9+yxxBtKeK9F8yP3JDTZCr2mYXNlgdBU0OfX6472JrrQaHx5HF6pEjcVUzX34QsfoD+Z4e4zczktg1DEhVo2B7S3p7Rn9VPTTDfVB4s3x0sSge3goqRm1gwJCLaCZqeK+QIDAQAB";

@interface EMAppConfig ()

@property (nonatomic, strong)   NSNumber *ssEnv;
@property (nonatomic, copy)     NSString *baseURL;
@property (nonatomic, copy)     NSString *userAgentSSEnv;

@end

@implementation EMAppConfig

#pragma mark - Shared instance
+ (EMAppConfig *)sharedInstance
{
    static EMAppConfig *appConfig;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        appConfig = [[EMAppConfig alloc] init];
        [appConfig reset];
    });
    return appConfig;
}

#pragma mark - Init network config
- (void)initNetworkConfig
{
    FJSNetworkConfig *config = [FJSNetworkConfig sharedConfig];
    config.requestEncryptType = FJSRequestEncryptTypePart;
    [config setBaseUrl:self.baseURL];
    [config setAESKey:[kAESKey fjs_base64EncodedString] encryptedAESKey:@""];
    
    //设置公共入参
    config.commonRequestArgument = [@{@"networkType"     : [FJSSystemInfo netWorkType] ?: @"",
                                      @"deviceId"        : [FJSSystemInfo deviceID] ?: @"",
                                      @"deviceType"      : [FJSSystemInfo deviceModel] ?: @"",
                                      @"deviceSVN"       : [FJSSystemInfo osInfo] ?: @"",
                                      @"nativeType"      : @"IOS",
                                      @"versionId"       : [FJSSystemInfo bundleVersion] ?: @"",
                                      @"versionDate"     : kAppVersionDate,
                                      @"versionDesc"     : @"123456787654",
                                      @"token"           : [EMUserManager sharedInstance].token ?: @"",
                                      } mutableCopy];
    FJSLog(@"%@", config.commonRequestArgument);
    
    //设置删除返回的NSNull值
    config.removesKeysWithNullValues = YES;
}

#pragma mark - Set environment
- (void)changeSSEnvironment:(NSInteger)ssEnv
{
    //如果当前环境是生产环境，不允许更改；如果想改成生产环境，也不允许更改
    if (ssEnv == 0 || ssEnv == 0) {
        return;
    }
    _ssEnv = [NSNumber numberWithInteger:ssEnv];
    [[NSUserDefaults standardUserDefaults] setObject:_ssEnv forKey:@"ss_env"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    [self reset];
}

- (void)reset
{
    switch ([self.ssEnv integerValue]) {
        case 0:
        {
            //生产
            self.baseURL = @"https://papc-gs.pingan.com.cn/opmgt/";
            self.userAgentSSEnv = @"prd";
        }
            break;
            
        case 1:
        {
            // stg1
            self.baseURL = @"https://test-papc-gs.pingan.com.cn:8843/stg1/opmgt/";
            self.userAgentSSEnv = @"stg1";
        }
            break;
            
        case 2:
        {
            self.baseURL =@"https://test-papc-gs.pingan.com.cn:8843/stg2/opmgt/";
            self.userAgentSSEnv = @"stg2";
        }
            break;
            
        case 3:
        {
            self.baseURL =@"https://test-papc-gs.pingan.com.cn:8843/stg3/opmgt/";
            self.userAgentSSEnv = @"stg3";
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - H5 URL
- (NSString *)completeH5URLForPath:(NSString *)path
{
    //    NSString *baseUrl = @"https://fang-test.pingan.com.cn:20443/opmgt/stg3/h5/online/em/";
    //    NSString *baseUrl = @"http://10.180.228.24:8899/em/";
    NSString *baseUrl = kHtmlBaseURL;
    return [NSString stringWithFormat:@"%@%@", baseUrl, path];
}

#pragma mark - Setter & Getter
- (NSNumber *)ssEnv{
    if (!SS_ENV) {
        return @(SS_ENV);
    }
    if (_ssEnv) {
        return _ssEnv;
    }
    NSNumber *ssEnv = [[NSUserDefaults standardUserDefaults] objectForKey:@"ss_env"];
    if (ssEnv) {
        _ssEnv = ssEnv;
    }else{
        _ssEnv = @(SS_ENV);
    }
    return _ssEnv;
}

@end
