//
//  EMBaseService.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/7.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FJSBaseApi;

@interface EMBaseService : NSObject

#pragma mark - 网络请求必须重写

/**
 处理请求成功

 @param request api
 */
- (void)handleApiRequestDidSuccess:(__kindof FJSBaseApi*)request;

/**
 处理请求失败

 @param request api
 */
- (void)handleApiRequestDidFail:(__kindof FJSBaseApi *)request;

- (void)handleApiResponseData:(__kindof FJSBaseApi *)request;

@end
