//
//  EMBaseService.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/7.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>
#import "EMBaseService.h"
#import "UIApplication+FJSExtension.h"
#import "EMLoginViewController.h"
#import "EMUserManager.h"
#import "FJSAlertView.h"
#import "EMGesturePasswordViewController.h"
#import "EMNotificationCenter.h"
#import "EMNetworkHelper.h"

@interface EMBaseService ()<FJSRequestDelegate>

@property (nonatomic, assign) BOOL showFailedAlert;

@end

@implementation EMBaseService

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.showFailedAlert = NO;
    }
    return self;
}

- (void)apiRequestDidSuccess:(__kindof FJSBaseApi *)request
{
    FJSLog(@"%@ response => %@", request.class, request.responseString);
    FJSLog(@"responseObject => %@", request.responseObject);
    if (![request.responseObject isKindOfClass:[NSDictionary class]]) {
        [self handleApiResponseData:request];
        return;
    }
    
    NSDictionary *responseDict = request.responseObject;
    
    NSString *flagStr = responseDict[@"flag"];
    NSInteger flag = flagStr ? [flagStr integerValue] : [responseDict[@"responseCode"] integerValue];
    NSString *msg = flagStr ? responseDict[@"msg"] : responseDict[@"responseMsg"];
    
    if (flag == 1 || flag == 11) {
        [self handleApiRequestDidSuccess:request];
    }
    else if (flag == 0 || flag == 9)
    {
        if (self.showFailedAlert) {
            //保证登录失败弹框唯一性
            return;
        }
        
        self.showFailedAlert = YES;
        [EMNetworkHelper tokenTimeOutWithMessage:msg];
    }
    else {
        if (self.showFailedAlert) {
            //保证登录失败弹框唯一性
            return;
        }
        
        self.showFailedAlert = YES;
        __weak EMBaseService *weakSelf = self;
        FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:@"提示" detail:msg buttonTitle:@"确定" completionBlock:^{
            weakSelf.showFailedAlert = NO;
        }];
        [alertView show];
    }
}

- (void)apiRequestDidFail:(__kindof FJSBaseApi *)request
{
    FJSLog(@"%@ response => %@", request.class, request.responseString);
    
    if (request.response) {
        [self handleApiRequestDidFail:request];
    } else {
        if (_showFailedAlert) {
            //保证登录失败弹框唯一性
            return;
        }
        
        _showFailedAlert = YES;
        FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:@"提示" detail:@"网络连接异常" buttonTitle:@"确定" completionBlock:^{
            _showFailedAlert = NO;
        }];
        [alertView show];
    }
}

- (void)handleApiRequestDidSuccess:(__kindof FJSBaseApi*)request
{
    
}

- (void)handleApiRequestDidFail:(__kindof FJSBaseApi *)request
{
    
}

- (void)handleApiResponseData:(__kindof FJSBaseApi *)request
{
    
}

@end
