//
//  FJSAlertView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/18.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, FJSAlertViewType) {
    FJSAlertViewTypeWarning,
    FJSAlertViewTypeSuccess,
    FJSAlertViewTypeFailed,
};

typedef void (^FJSAlertViewLeftBlock)(void);
typedef void (^FJSAlertViewRightBlock)(void);

@interface FJSAlertView : UIView

/**
 只有一个按钮的弹框

 @param type 弹框类型
 @param title 标题
 @param detail 详细
 @param buttonTitle 按钮文字
 @param completionBlock 点击按钮回调
 @return 弹框对象
 */
- (instancetype)initWithType:(FJSAlertViewType)type
                       title:(NSString *)title
                      detail:(NSString *)detail
                 buttonTitle:(NSString *)buttonTitle
             completionBlock:(FJSAlertViewRightBlock)completionBlock;

- (instancetype)initWithType:(FJSAlertViewType)type
                       title:(NSString *)title
                      detail:(NSString *)detail
                   leftTitle:(NSString *)leftTitle
                  rightTitle:(NSString *)rightTitle
             leftButtonBlock:(FJSAlertViewLeftBlock)leftBlock
            rightButtonBlock:(FJSAlertViewRightBlock)rightBlock;

- (instancetype)initWithScheduleCompanyName:(NSString *)companyName
                               scheduleType:(EMScheduleType)scheduleType
                                  startDate:(NSString *)startDate;

- (void)show;

//设置点击灰色区域关闭弹框
- (void)setMaskViewTapToClose;

@end
