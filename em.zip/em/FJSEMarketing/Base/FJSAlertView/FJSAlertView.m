//
//  FJSAlertView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/18.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSAlertView.h"
#import <pop/POP.h>

@interface FJSAlertView ()

@property (nonatomic, copy) NSString *imageName;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *detail;
@property (nonatomic, copy) NSString *leftTitle;
@property (nonatomic, copy) NSString *rightTitle;

@property (nonatomic, copy) FJSAlertViewLeftBlock leftBlock;
@property (nonatomic, copy) FJSAlertViewRightBlock rightBlock;

@property (nonatomic, strong) UIView *maskView;
@property (nonatomic, strong) UIView *backgroundView;
@property (nonatomic, strong) UIImageView *imageView;
@property (nonatomic, strong) UILabel *titleLabel;
@property (nonatomic, strong) UILabel *detailLabel;
@property (nonatomic, strong) UIButton *confirmButton;
@property (nonatomic, strong) UIButton *cancleButton;

@property (nonatomic, strong) UIView *lineView;
@property (nonatomic, strong) UIView *buttonLineView;

#pragma mark - 日程提醒
@property (nonatomic, copy) NSString *scheduleIconName;
@property (nonatomic, copy) NSString *companyName;
@property (nonatomic, copy) NSString *startDate;
@property (nonatomic, assign) EMScheduleType scheduleType;

@property (nonatomic, strong) UILabel *companyLabel;
@property (nonatomic, strong) UILabel *timeLabel;
@property (nonatomic, strong) UIImageView *iconImageView;

@end

@implementation FJSAlertView

#pragma mark - Init
- (instancetype)initWithType:(FJSAlertViewType)type
                       title:(NSString *)title
                      detail:(NSString *)detail
                 buttonTitle:(NSString *)buttonTitle
             completionBlock:(FJSAlertViewRightBlock)completionBlock
{
    self = [super initWithFrame:[UIApplication sharedApplication].keyWindow.bounds];
    if (self) {
        
        [self initImageName:type];
        
        _title = title;
        _detail = detail;
        _rightTitle = buttonTitle;
        _rightBlock = completionBlock;
        
        [self initViews];
        [self initOneButton];
    }
    return self;
}

- (instancetype)initWithType:(FJSAlertViewType)type
                       title:(NSString *)title
                      detail:(NSString *)detail
                   leftTitle:(NSString *)leftTitle
                  rightTitle:(NSString *)rightTitle
             leftButtonBlock:(FJSAlertViewLeftBlock)leftBlock
            rightButtonBlock:(FJSAlertViewRightBlock)rightBlock
{
    self = [super initWithFrame:[UIApplication sharedApplication].keyWindow.bounds];
    if (self) {
        
        [self initImageName:type];
        
        _title = title;
        _detail = detail;
        _leftTitle = leftTitle;
        _rightTitle = rightTitle;
        _leftBlock = leftBlock;
        _rightBlock = rightBlock;
        
        [self initViews];
        [self initTwoButtons];
    }
    return self;
}

- (instancetype)initWithScheduleCompanyName:(NSString *)companyName
                               scheduleType:(EMScheduleType)scheduleType
                                  startDate:(NSString *)startDate
{
    self = [super initWithFrame:[UIApplication sharedApplication].keyWindow.bounds];
    if (self) {
        
        [self initImageName:FJSAlertViewTypeWarning];
        
        _title = @"日历通知";
        _rightTitle = @"知道了";
        _companyName = companyName;
        _scheduleType = scheduleType;
        _startDate = startDate;
        
        [self initScheduleViews];
        [self initOneButton];
    }
    return self;
}

#pragma mark - Show & dismiss
- (void)show
{
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    
    POPSpringAnimation *anim = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerScaleXY];
    anim.fromValue = [NSValue valueWithCGPoint:CGPointMake(0.7f, 0.7f)];
    anim.toValue = [NSValue valueWithCGPoint:CGPointMake(1.f, 1.f)];
    anim.springSpeed = 0.f;
    [self.backgroundView.layer pop_addAnimation:anim forKey:nil];
}

- (void)dismiss
{
    [self removeFromSuperview];
}

#pragma mark - Set up tap
- (void)setMaskViewTapToClose
{
    UITapGestureRecognizer *tapGR = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismiss)];
    tapGR.numberOfTapsRequired = 1;
    [self.maskView addGestureRecognizer:tapGR];
}

#pragma mark - Init views
- (void)initViews
{
    BOOL hasTitle = _title && [_title isKindOfClass:[NSString class]] && _title.length > 0;

    [self addSubview:self.maskView];
    
    [self.backgroundView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self);
        make.width.equalTo(@310);
        make.top.equalTo(self.imageView.mas_top).with.offset(-20);
        make.bottom.equalTo(self.confirmButton.mas_bottom);
    }];
    
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.backgroundView.mas_top).with.offset(20);
        make.centerX.equalTo(self);
        make.height.equalTo(@43);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageView.mas_bottom).with.offset(10);
        make.height.equalTo(hasTitle ? @25 : @0);
        make.centerX.equalTo(self);
    }];
    
    [self.detailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).with.offset(20);
        make.centerX.equalTo(self);
    }];
    
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.detailLabel.mas_bottom).with.offset(20);
        make.height.equalTo(@1);
        make.width.equalTo(self.backgroundView.mas_width);
        make.centerX.equalTo(self);
    }];
}

- (void)initOneButton
{
    [self.confirmButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.lineView.mas_bottom);
        make.height.equalTo(@61);
        make.width.equalTo(self.backgroundView.mas_width);
        make.centerX.equalTo(self);
    }];
}

- (void)initTwoButtons
{
    [self.cancleButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.lineView.mas_bottom);
        make.height.equalTo(@61);
        make.width.equalTo(self.confirmButton.mas_width);
        make.left.equalTo(self.backgroundView.mas_left);
        make.right.equalTo(self.confirmButton.mas_left);
    }];
    
    [self.confirmButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.lineView.mas_bottom);
        make.height.equalTo(@61);
        make.width.equalTo(self.cancleButton.mas_width);
        make.left.equalTo(self.cancleButton.mas_right);
        make.right.equalTo(self.backgroundView.mas_right);
    }];
    
    [self.buttonLineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.lineView.mas_bottom);
        make.height.equalTo(@61);
        make.width.equalTo(@1);
        make.left.equalTo(self.cancleButton.mas_right);
    }];
}

#pragma mark - Schedule
- (void)initScheduleViews
{
    [self initScheduleIconImageName:self.scheduleType];
    
    [self addSubview:self.maskView];
    
    [self.backgroundView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self);
        make.width.equalTo(@310);
        make.top.equalTo(self.imageView.mas_top).with.offset(-20);
        make.bottom.equalTo(self.confirmButton.mas_bottom);
    }];
    
    [self.imageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.backgroundView.mas_top).with.offset(20);
        make.centerX.equalTo(self);
        make.height.equalTo(@43);
    }];
    
    [self.titleLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageView.mas_bottom).with.offset(10);
        make.height.equalTo(@25);
        make.centerX.equalTo(self);
    }];
    
    [self.iconImageView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.companyLabel.mas_centerY);
        make.left.equalTo(self.backgroundView.mas_left).with.offset(25);
    }];
    
    [self.companyLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.titleLabel.mas_bottom).with.offset(20);
        make.left.equalTo(self.iconImageView.mas_left).with.offset(20);
        make.width.equalTo(@200);
    }];
    
    [self.timeLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.companyLabel.mas_bottom).with.offset(10);
        make.left.equalTo(self.companyLabel.mas_left);
        make.width.equalTo(@200);
    }];
    
    [self.lineView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.timeLabel.mas_bottom).with.offset(20);
        make.height.equalTo(@1);
        make.width.equalTo(self.backgroundView.mas_width);
        make.centerX.equalTo(self);
    }];

}

#pragma mark - Action
- (void)handleConfirmAction:(UIButton *)sender
{
    [self dismiss];
    if (_rightBlock) {
        _rightBlock();
    }
}

- (void)handleCancleAction:(UIButton *)sender
{
    [self dismiss];
    if (_leftBlock) {
        _leftBlock();
    }
}

#pragma mark - Setter & getter
- (void)initImageName:(FJSAlertViewType)type
{
    switch (type) {
        case FJSAlertViewTypeWarning:
        {
            _imageName = @"icon_!";
        }
            break;
            
        case FJSAlertViewTypeSuccess:
        {
            _imageName = @"icon_success";
        }
            break;
            
        case FJSAlertViewTypeFailed:
        {
            _imageName = @"icon_fail";
        }
            break;
    }
}

- (void)initScheduleIconImageName:(EMScheduleType)scheduleType
{
    switch (scheduleType) {
        case EMScheduleTypeExploit:
        {
            _scheduleIconName = @"icon_square_red";
        }
            break;
            
        case EMScheduleTypeMaintain:
        {
            _scheduleIconName = @"icon_square_yellow";
        }
            break;
            
        case EMScheduleTypeOther:
        {
            _scheduleIconName = @"icon_square_blue";
        }
            break;
    }
}

- (UIView *)maskView
{
    if (!_maskView) {
        _maskView = [[UIView alloc] initWithFrame:self.bounds];
        _maskView.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
    }
    return _maskView;
}
                                   
- (UIView *)backgroundView
{
    if (!_backgroundView) {
        _backgroundView = [UIView new];
        _backgroundView.backgroundColor = [UIColor whiteColor];
        _backgroundView.layer.cornerRadius = 4;
        [self addSubview:_backgroundView];
    }
    return _backgroundView;
}

- (UIImageView *)imageView
{
    if (!_imageView) {
        _imageView = [UIImageView new];
        _imageView.image = [UIImage imageNamed:self.imageName];
        [self.backgroundView addSubview:_imageView];
    }
    return _imageView;
}

- (UILabel *)titleLabel
{
    if (!_titleLabel) {
        _titleLabel = [UILabel new];
        _titleLabel.text = self.title;
        _titleLabel.textColor = UIColorFromHex(0x666666);
        _titleLabel.font = [UIFont boldSystemFontOfSize:18];
        _titleLabel.textAlignment = NSTextAlignmentCenter;
        [self.backgroundView addSubview:_titleLabel];
    }
    return _titleLabel;
}

- (UILabel *)detailLabel
{
    if (!_detailLabel) {
        _detailLabel = [UILabel new];
        _detailLabel.text = self.detail;
        _detailLabel.textColor = UIColorFromHex(0x666666);
        _detailLabel.font = [UIFont systemFontOfSize:15];
        _detailLabel.textAlignment = NSTextAlignmentCenter;
        _detailLabel.numberOfLines = 0;
        _detailLabel.preferredMaxLayoutWidth = SCREEN_WIDTH - 60 * 2;
        [self.backgroundView addSubview:_detailLabel];
    }
    return _detailLabel;
}

- (UIButton *)confirmButton
{
    if (!_confirmButton) {
        _confirmButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_confirmButton setTitle:self.rightTitle forState:UIControlStateNormal];
        [_confirmButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
        _confirmButton.titleLabel.font = [UIFont systemFontOfSize:18];
        [_confirmButton addTarget:self action:@selector(handleConfirmAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.backgroundView addSubview:_confirmButton];
    }
    return _confirmButton;
}

- (UIButton *)cancleButton
{
    if (!_cancleButton) {
        _cancleButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [_cancleButton setTitle:self.leftTitle forState:UIControlStateNormal];
        [_cancleButton setTitleColor:UIColorFromHex(0x999999) forState:UIControlStateNormal];
        _cancleButton.titleLabel.font = [UIFont systemFontOfSize:18];
        [_cancleButton addTarget:self action:@selector(handleCancleAction:) forControlEvents:UIControlEventTouchUpInside];
        [self.backgroundView addSubview:_cancleButton];
    }
    return _cancleButton;
}

- (UIView *)lineView
{
    if (!_lineView) {
        _lineView = [UIView new];
        _lineView.backgroundColor = UIColorFromHex(0xeeeeee);
        [self.backgroundView addSubview:_lineView];
    }
    return _lineView;
}

- (UIView *)buttonLineView
{
    if (!_buttonLineView) {
        _buttonLineView = [UIView new];
        _buttonLineView.backgroundColor = UIColorFromHex(0xeeeeee);
        [self.backgroundView addSubview:_buttonLineView];
    }
    return _buttonLineView;
}

- (UILabel *)companyLabel
{
    if (!_companyLabel) {
        _companyLabel = [UILabel new];
        _companyLabel.text = self.companyName;
        _companyLabel.textColor = UIColorFromHex(0x666666);
        _companyLabel.font = [UIFont systemFontOfSize:15];
        _companyLabel.numberOfLines = 0;
        [self.backgroundView addSubview:_companyLabel];
    }
    return _companyLabel;
}

- (UILabel *)timeLabel
{
    if (!_timeLabel) {
        NSString *descStr = @"开始时间 ";
        NSString *startDateStr = self.startDate;
        NSString *wholeStr = [NSString stringWithFormat:@"%@%@", descStr, startDateStr];
        NSMutableAttributedString *attrStr = [[NSMutableAttributedString alloc] initWithString:wholeStr];
        [attrStr addAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:14],
                                    NSForegroundColorAttributeName : UIColorFromHex(0x999999)}
                            range:NSMakeRange(0, 4)];
        [attrStr addAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:14],
                                    NSForegroundColorAttributeName : UIColorFromHex(0x666666)}
                            range:NSMakeRange(5, wholeStr.length - 5)];
        
        _timeLabel = [UILabel new];
        _timeLabel.attributedText = attrStr;
        [self.backgroundView addSubview:_timeLabel];
    }
    return _timeLabel;
}

- (UIImageView *)iconImageView
{
    if (!_iconImageView) {
        _iconImageView = [UIImageView new];
        _iconImageView.image = [UIImage imageNamed:_scheduleIconName];
        [self.backgroundView addSubview:_iconImageView];
    }
    return _iconImageView;
}

@end
