//
//  FJSMacro.h
//  FJSDolphinCove
//
//  Created by xuyq on 2017/5/4.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#ifndef FJSMacro_h
#define FJSMacro_h

#import <mach/mach_time.h>
#import <CoreGraphics/CGBase.h>

#pragma mark - TODO & FIXME

#define STRINGIFY(S) #S
#define DEFER_STRINGIFY(S) STRINGIFY(S)

//TODO，显示一个warning
#define PRAGMA_TODO_MESSAGE(MSG) _Pragma(STRINGIFY(message(MSG)))
#define FORMATTED_TODO_MESSAGE(MSG) "[TODO-" DEFER_STRINGIFY(__COUNTER__) "] " MSG " \n" \
DEFER_STRINGIFY(__FILE__) " line " DEFER_STRINGIFY(__LINE__)
#define TODO(MSG) PRAGMA_TODO_MESSAGE(FORMATTED_TODO_MESSAGE(MSG))

//FIXME，显示一个error
#define PRAGMA_FIXME_MESSAGE(MSG) _Pragma(STRINGIFY(GCC error(MSG)))
#define FORMATTED_FIXME_MESSAGE(MSG) "[FIXME-" DEFER_STRINGIFY(__COUNTER__) "] " MSG " \n" \
DEFER_STRINGIFY(__FILE__) " line " DEFER_STRINGIFY(__LINE__)
#define FIXME(MSG) PRAGMA_FIXME_MESSAGE(FORMATTED_FIXME_MESSAGE(MSG))

//***********************************************************************************************
#pragma mark - Logging

#ifdef DEBUG
#define FJSLog(fmt, ...) NSLog((@"%s [Line %d] " fmt), __PRETTY_FUNCTION__, __LINE__, ##__VA_ARGS__)
#else
#define FJSLog(...)
#endif

//***********************************************************************************************
#pragma mark - iOS Version

#define SYSTEM_VERSION                              [[UIDevice currentDevice] systemVersion]
#define SYSTEM_VERSION_EQUAL_TO(v)                  ([SYSTEM_VERSION compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([SYSTEM_VERSION compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([SYSTEM_VERSION compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([SYSTEM_VERSION compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([SYSTEM_VERSION compare:v options:NSNumericSearch] != NSOrderedDescending)

//***********************************************************************************************
#pragma mark - UIColor

// example: UIColorFromHex(0x9daa76)
#define UIColorFromHexWithAlpha(hexValue,a) [UIColor colorWithRed:((float)((hexValue & 0xFF0000) >> 16))/255.0 green:((float)((hexValue & 0xFF00) >> 8))/255.0 blue:((float)(hexValue & 0xFF))/255.0 alpha:a]
#define UIColorFromHex(hexValue)            UIColorFromHexWithAlpha(hexValue,1.0)
#define UIColorFromRGBA(r,g,b,a)            [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define UIColorFromRGB(r,g,b)               IColorFromRGBA(r,g,b,1.0)

//***********************************************************************************************
#pragma mark - NSNumber

#define NUM_INT(int) [NSNumber numberWithInt:int]
#define NUM_FLOAT(float) [NSNumber numberWithFloat:float]
#define NUM_BOOL(bool) [NSNumber numberWithBool:bool]

//***********************************************************************************************
#pragma mark - Frame Geometry

#define CENTER_VERTICALLY(parent,child) floor((parent.frame.size.height - child.frame.size.height) / 2)
#define CENTER_HORIZONTALLY(parent,child) floor((parent.frame.size.width - child.frame.size.width) / 2)

// example: [[UIView alloc] initWithFrame:(CGRect){CENTER_IN_PARENT(parentView,500,500),CGSizeMake(500,500)}];
#define CENTER_IN_PARENT(parent,childWidth,childHeight) CGPointMake(floor((parent.frame.size.width - childWidth) / 2),floor((parent.frame.size.height - childHeight) / 2))
#define CENTER_IN_PARENT_X(parent,childWidth) floor((parent.frame.size.width - childWidth) / 2)
#define CENTER_IN_PARENT_Y(parent,childHeight) floor((parent.frame.size.height - childHeight) / 2)

//用系统方法CGRectGetWidth和CGRectGetHeight
//#define WIDTH(view) view.frame.size.width
//#define HEIGHT(view) view.frame.size.height
#define X(view) view.frame.origin.x
#define Y(view) view.frame.origin.y
#define LEFT(view) view.frame.origin.x
#define TOP(view) view.frame.origin.y
#define BOTTOM(view) (view.frame.origin.y + view.frame.size.height)
#define RIGHT(view) (view.frame.origin.x + view.frame.size.width)

//***********************************************************************************************
#pragma mark - Screen size

#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height

//***********************************************************************************************
#pragma mark - IndexPath

#define INDEX_PATH(a,b) [NSIndexPath indexPathWithIndexes:(NSUInteger[]){a,b} length:2]

//***********************************************************************************************
#pragma mark - Device type

#define TARGETED_DEVICE_IS_IPAD UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad
#define TARGETED_DEVICE_IS_IPHONE UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPhone
#define TARGETED_DEVICE_IS_IPHONE_568 TARGETED_DEVICE_IS_IPHONE && SCREEN_HEIGHT == 568

//***********************************************************************************************
#pragma mark - Transforms

//角度获取弧度
#define TRANSFORM_DEGREES_TO_RADIANS(degrees) degrees * M_PI / 180

//弧度获取角度
#define TRANSFORM_RADIANS_TO_DEGREES(radians) radians * 180.0 / M_PI

#endif /* FJSMacro_h */
