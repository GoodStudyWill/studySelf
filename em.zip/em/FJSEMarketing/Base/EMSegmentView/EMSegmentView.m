//
//  EMSegmentView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMSegmentView.h"

@interface EMSegmentView ()

@property (nonatomic, strong) UIButton *scheduleButton;
@property (nonatomic, strong) UIButton *targetButton;

@property (nonatomic, strong) UIView *selectedBottomView;

@end

@implementation EMSegmentView

- (instancetype)initWithFrame:(CGRect)frame
                    leftTitle:(NSString *)leftTitle
                   rightTitle:(NSString *)rightTitle
{
    self = [super initWithFrame:frame];
    if (self) {
        self.userInteractionEnabled = YES;
        [self initViewsWithLeftTitle:leftTitle rightTitle:rightTitle];
    }
    return self;
}

#pragma mark - UI
- (void)initViewsWithLeftTitle:(NSString *)leftTitle rightTitle:(NSString *)rightTitle
{
    self.scheduleButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.scheduleButton setTitle:leftTitle forState:UIControlStateNormal];
    [self.scheduleButton addTarget:self action:@selector(handleClickButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.scheduleButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
    self.scheduleButton.tag = 0;
    [self setButton:self.scheduleButton];
    [self addSubview:self.scheduleButton];
    
    self.targetButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.targetButton setTitle:rightTitle forState:UIControlStateNormal];
    [self.targetButton addTarget:self action:@selector(handleClickButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.targetButton setTitleColor:UIColorFromHex(0x999999) forState:UIControlStateNormal];
    self.targetButton.tag = 1;
    [self setButton:self.targetButton];
    [self addSubview:self.targetButton];
    
    self.selectedBottomView = [UIView new];
    self.selectedBottomView.backgroundColor = UIColorFromHex(0x00a0ea);
    [self addSubview:self.selectedBottomView];
    
    [self layoutConstraints];
}

- (void)layoutConstraints
{
    [self.scheduleButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).with.offset(5);
        make.left.equalTo(self).with.offset(10);
        make.right.equalTo(self.targetButton.mas_left).with.offset(-2);
        make.height.equalTo(@40);
        make.width.equalTo(self.targetButton);
    }];
    
    [self.targetButton mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).with.offset(5);
        make.left.equalTo(self.scheduleButton.mas_right).with.offset(2);
        make.right.equalTo(self).with.offset(-10);
        make.height.equalTo(@40);
        make.width.equalTo(self.scheduleButton);
    }];
    
    [self.selectedBottomView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self);
        make.centerX.equalTo(self.scheduleButton.mas_centerX);
        make.size.mas_equalTo(CGSizeMake(53, 2));
    }];
}

- (void)setButton:(UIButton *)button
{
    CGFloat alpha = 0.92;
    CGFloat cornerRadius = 2;
    
    button.alpha = alpha;
    button.layer.cornerRadius = cornerRadius;
    [button setBackgroundColor:[UIColor whiteColor]];
    button.titleLabel.font = [UIFont systemFontOfSize:15];
}

#pragma mark - Api
- (void)selectIndex:(NSInteger)index
{
    UIButton *selectedButton = nil;
    if (index == 0) {
        [self.scheduleButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
        [self.targetButton setTitleColor:UIColorFromHex(0x999999) forState:UIControlStateNormal];
        
        selectedButton = self.scheduleButton;
    }
    else if (index == 1) {
        [self.scheduleButton setTitleColor:UIColorFromHex(0x999999) forState:UIControlStateNormal];
        [self.targetButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
        
        selectedButton = self.targetButton;
    }
    
    CGPoint center = self.selectedBottomView.center;
    center.x = selectedButton.centerX;
    [UIView animateWithDuration:0.5 animations:^{
        self.selectedBottomView.center = center;
    } completion:^(BOOL finished) {
        if (finished && self.delegate && [self.delegate respondsToSelector:@selector(segmentViewDidSelectedAtIndex:)]) {
            [self.delegate segmentViewDidSelectedAtIndex:index];
        }
    }];
}

#pragma mark - Event
- (void)handleClickButtonAction:(UIButton *)sender
{
    FJSLog(@"click %ld...", sender.tag);
    [self selectIndex:sender.tag];
//    if (sender.tag == 0) {
//        [self.scheduleButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
//        [self.targetButton setTitleColor:UIColorFromHex(0x999999) forState:UIControlStateNormal];
//    } else if (sender.tag == 1) {
//        [self.scheduleButton setTitleColor:UIColorFromHex(0x999999) forState:UIControlStateNormal];
//        [self.targetButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
//    }
//    
//    CGPoint center = self.selectedBottomView.center;
//    center.x = sender.centerX;
//    [UIView animateWithDuration:0.5 animations:^{
//        self.selectedBottomView.center = center;
//    } completion:^(BOOL finished) {
//        if (finished && self.delegate && [self.delegate respondsToSelector:@selector(segmentViewDidSelectedAtIndex:)]) {
//            [self.delegate segmentViewDidSelectedAtIndex:sender.tag];
//        }
//    }];
}


@end
