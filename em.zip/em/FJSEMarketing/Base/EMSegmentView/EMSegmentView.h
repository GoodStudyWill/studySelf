//
//  EMSegmentView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/13.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol EMSegmentViewDelegate <NSObject>

/**
 选择回调

 @param index 被选中的index，0为左边，1为右边
 */
- (void)segmentViewDidSelectedAtIndex:(NSInteger)index;

@end

@interface EMSegmentView : UIView

@property (nonatomic, weak) id<EMSegmentViewDelegate> delegate;

- (instancetype)initWithFrame:(CGRect)frame
                    leftTitle:(NSString *)leftTitle
                   rightTitle:(NSString *)rightTitle;

- (void)selectIndex:(NSInteger)index;

@end
