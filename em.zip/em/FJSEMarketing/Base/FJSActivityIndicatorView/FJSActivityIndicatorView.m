//
//  FJSActivityIndicatorView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/28.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSActivityIndicatorView.h"

@interface FJSActivityIndicatorView ()

@property (nonatomic, strong) UIImageView *loadingImageView;
@property (nonatomic, strong) UILabel *tipLabel;

@property (nonatomic, assign) FJSActivityIndicatorViewStyle style;

@property (nonatomic, assign) BOOL isAnimating;

@end

@implementation FJSActivityIndicatorView

- (instancetype)initWithFrame:(CGRect)frame style:(FJSActivityIndicatorViewStyle)style
{
    self = [super initWithFrame:frame];
    if (self) {
        _style = style;
        _isAnimating = NO;
        if (style == FJSActivityIndicatorViewStyleUp) {
            [self addSubview:self.tipLabel];
        }
        [self addSubview:self.loadingImageView];
    }
    return self;
}

- (void)changeStatus:(BOOL)isEnable
{
    if (self.style == FJSActivityIndicatorViewStyleUp) {
        NSString *tipText = isEnable? @"正在加载更多数据..." : @"已经到底啦";
        self.tipLabel.text = tipText;
        CGFloat x = isEnable ? (self.width-100-14-3)/2+14+8 : (self.width-100)/2;
        self.tipLabel.frame = CGRectMake(x, 0, 100, 20);
        self.loadingImageView.hidden = !isEnable;
    } else {
        NSString *imageName = isEnable? @"icon_loading_blue" : @"icon_loading_gray";
        self.loadingImageView.image = [UIImage imageNamed:imageName];
    }
    
}

- (void)startAnimating
{
    if (self.isAnimating) {
        return;
    }
    
    CABasicAnimation *rotationAnimation = [CABasicAnimation animationWithKeyPath:@"transform.rotation.z"];
    rotationAnimation.toValue = [NSNumber numberWithFloat:M_PI*2.0];
    rotationAnimation.duration = 1;
    rotationAnimation.cumulative = YES;
    rotationAnimation.repeatCount = FLT_MAX;
    [self.loadingImageView.layer addAnimation:rotationAnimation forKey:@"rotationAnimation"];
    
    self.isAnimating = YES;
}

- (void)stopAnimating
{
    self.isAnimating = NO;
    [self.loadingImageView.layer removeAllAnimations];
}

- (UIImageView *)loadingImageView
{
    if (!_loadingImageView) {
        CGRect frame = CGRectZero;
        UIImage *image = nil;
        
        if (self.style == FJSActivityIndicatorViewStyleDown) {
            frame = CGRectMake((self.width-32)/2, 0, 32, 32);
            image = [UIImage imageNamed:@"icon_loading_gray"];
        } else {
            CGFloat x = (self.width - self.tipLabel.width - 14 - 8) / 2;
            frame = CGRectMake(x, 3, 14, 14);
            image = [UIImage imageNamed:@"icon_loading_footer"];
        }
        
        _loadingImageView = [[UIImageView alloc] initWithFrame:frame];
        _loadingImageView.image = image;
        
    }
    return _loadingImageView;
}

- (UILabel *)tipLabel
{
    if (!_tipLabel) {
        CGFloat x = (self.width - 100 - 14 - 3) / 2 + 14 + 8;
        _tipLabel = [[UILabel alloc] initWithFrame:CGRectMake(x, 0, 100, 20)];
        _tipLabel.text = @"正在加载更多数据...";
        _tipLabel.textAlignment = NSTextAlignmentCenter;
        _tipLabel.font = [UIFont systemFontOfSize:14];
    }
    return _tipLabel;
}

@end
