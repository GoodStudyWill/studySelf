//
//  FJSActivityIndicatorView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/28.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, FJSActivityIndicatorViewStyle) {
    FJSActivityIndicatorViewStyleDown,      //下拉刷新
    FJSActivityIndicatorViewStyleUp,        //上拉刷新
};

@interface FJSActivityIndicatorView : UIView

- (instancetype)initWithFrame:(CGRect)frame style:(FJSActivityIndicatorViewStyle)style;

- (void)changeStatus:(BOOL)isEnable;

- (void)startAnimating;

- (void)stopAnimating;

@end
