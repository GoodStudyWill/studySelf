//
//  FJSAddressPicker.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/6.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSAddressPicker.h"

NSString * const kFJSAddressPickerKeyProvince   = @"province";   //省
NSString * const kFJSAddressPickerKeyCity       = @"city";       //市
NSString * const kFJSAddressPickerKeyZone       = @"zone";       //区

NSString * const kFJSAddressPickerKeyKey        = @"k";         //key
NSString * const kFJSAddressPickerKeyValue      = @"v";         //value

@interface FJSAddressPicker ()<UIPickerViewDelegate, UIPickerViewDataSource>
//左边退出按钮
@property (nonatomic, strong) UIButton *cancelButton;
//右边的确定按钮
@property (nonatomic, strong) UIButton *chooseButton;


@property (nonatomic, strong) UIPickerView *pickerView;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UIView *bgView;

@property (nonatomic, copy) NSDictionary *addressDict;

@property (nonatomic, strong) NSMutableDictionary *selectedAddrDict;

@property (nonatomic, copy) FJSAddressPickerConfirmBlock confirmBlock;
@property (nonatomic, copy) FJSAddressPickerCancleBlock  cancleBlock;

@property (nonatomic, copy) NSString *selectedProvince;
@property (nonatomic, copy) NSArray *selectedCity;
@property (nonatomic, copy) NSArray *selectedZone;

@end

@implementation FJSAddressPicker

#pragma mark - Init
+ (instancetype)addressPickerWithTitle:(NSString *)title
                          confirmBlock:(FJSAddressPickerConfirmBlock)confirmBlock
                           cancleBlock:(FJSAddressPickerCancleBlock)cancleBlock
{
    FJSAddressPicker *addressPicker = [FJSAddressPicker addressPickerWithConfirmBlock:confirmBlock cancleBlock:cancleBlock];
    addressPicker.titleLabel.text = title;
    return addressPicker;
}

+ (instancetype)addressPickerWithConfirmBlock:(FJSAddressPickerConfirmBlock)confirmBlock
                                  cancleBlock:(FJSAddressPickerCancleBlock)cancleBlock
{
    FJSAddressPicker *addressPicker = [FJSAddressPicker new];
    addressPicker.confirmBlock = confirmBlock;
    addressPicker.cancleBlock = cancleBlock;
    return addressPicker;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        //获取地址数据
        NSString *plistPath = [[NSBundle mainBundle] pathForResource:@"address" ofType:@"plist"];
        if (plistPath) {
            _addressDict = [[NSDictionary alloc] initWithContentsOfFile:plistPath];
        }
        
        _selectedAddrDict = [NSMutableDictionary dictionary];
        
        self.backgroundColor = UIColorFromRGBA(0, 0, 0, 0.5);
        self.alpha = 0;
        
        UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 250)];
        contentView.backgroundColor = [UIColor whiteColor];
        [self addSubview:contentView];
        self.contentView = contentView;
        
        self.pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, 45, SCREEN_WIDTH, 205)];
        self.pickerView.backgroundColor = [UIColor whiteColor];
        self.pickerView.dataSource = self;
        self.pickerView.delegate = self;
        [contentView addSubview:self.pickerView];
        
        //放按钮的View
        UIView *upVeiw = [[UIView alloc]initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 45)];
        upVeiw.backgroundColor = [UIColor whiteColor];
        [contentView addSubview:upVeiw];
        
        //左边的取消按钮
        self.cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.cancelButton.frame = CGRectMake(20, 0, 40, 45);
        [self.cancelButton setTitle:@"取消" forState:UIControlStateNormal];
        self.cancelButton.backgroundColor = [UIColor clearColor];
        self.cancelButton.titleLabel.font = [UIFont systemFontOfSize:15];
        [self.cancelButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
        [self.cancelButton addTarget:self action:@selector(cancelButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [upVeiw addSubview:self.cancelButton];
        
        //右边的确定按钮
        self.chooseButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.chooseButton.frame = CGRectMake([UIScreen mainScreen].bounds.size.width - 60, 0, 40, 45);
        [self.chooseButton setTitle:@"确定" forState:UIControlStateNormal];
        self.chooseButton.backgroundColor = [UIColor clearColor];
        self.chooseButton.titleLabel.font = [UIFont systemFontOfSize:15];
        [self.chooseButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
        [self.chooseButton addTarget:self action:@selector(configButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [upVeiw addSubview:self.chooseButton];
        
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 45)];
        self.titleLabel.textColor = [UIColor blackColor];
        self.titleLabel.font = [UIFont systemFontOfSize:18];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.text = @"地区选择";
        [upVeiw addSubview:self.titleLabel];
        
        //分割线
        UIView *splitView = [[UIView alloc] initWithFrame:CGRectMake(0, 45, [UIScreen mainScreen].bounds.size.width, 1)];
        splitView.backgroundColor = UIColorFromHex(0xe6e6e6);
        [upVeiw addSubview:splitView];
    }
    return self;
}

#pragma mark - Set current data
- (void)setCurrentData
{
    NSArray *provinceArr = self.addressDict[kFJSAddressPickerKeyProvince];
    NSDictionary *selectedProvince = provinceArr.firstObject;
    self.selectedProvince = selectedProvince[kFJSAddressPickerKeyKey];
    
    NSDictionary *cityDict = self.addressDict[kFJSAddressPickerKeyCity];
    NSString *cityKey = selectedProvince[kFJSAddressPickerKeyKey];
    NSArray *cityArr = cityDict[cityKey];
    NSDictionary *selectedCity = cityArr.firstObject;
    self.selectedCity = cityArr;
    
    NSDictionary *zoneDict = self.addressDict[kFJSAddressPickerKeyZone];
    NSString *zoneKey = selectedCity[kFJSAddressPickerKeyKey];
    NSArray *zoneArr = zoneDict[zoneKey];
    NSDictionary *selectedZone = zoneArr.firstObject;
    self.selectedZone = zoneArr;
    
    [self.selectedAddrDict setObject:selectedProvince forKey:kFJSAddressPickerKeyProvince];
    [self.selectedAddrDict setObject:selectedCity forKey:kFJSAddressPickerKeyCity];
    [self.selectedAddrDict setObject:selectedZone forKey:kFJSAddressPickerKeyZone];
    
    [self.pickerView selectRow:0 inComponent:0 animated:NO];
    [self.pickerView selectRow:0 inComponent:1 animated:NO];
    [self.pickerView selectRow:0 inComponent:2 animated:NO];
    
    [self pickerView:self.pickerView didSelectRow:0 inComponent:0];
    [self pickerView:self.pickerView didSelectRow:0 inComponent:1];
    [self pickerView:self.pickerView didSelectRow:0 inComponent:2];
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 3;
}

//确定每一列返回的东西
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    switch (component) {
        case 0:
        {
            return [self.addressDict[kFJSAddressPickerKeyProvince] count];
        }
            break;
            
        case 1:
        {
            return self.selectedCity.count;
        }
            break;
            
        case 2:
        {
            return self.selectedZone.count;
        }
            break;
            
        default:
        {
            return 0;
        }
            break;
    }
}

- (UIView*)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    CGFloat width = component == 0 ? SCREEN_WIDTH/3.0 : SCREEN_WIDTH/3.7;
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH*component/3.0, 0, width, 40)];
    label.font = [UIFont systemFontOfSize:15.0];
    label.numberOfLines = 0;
    label.tag = component*100+row;
    label.textAlignment = NSTextAlignmentCenter;
    
    NSString *text = nil;
    switch (component) {
        case 0:
        {
            NSArray *provinceArr = self.addressDict[kFJSAddressPickerKeyProvince];
            NSDictionary *province = provinceArr[row];
            text = province[kFJSAddressPickerKeyValue];
        }
            break;
            
        case 1:
        {
            NSDictionary *city = self.selectedCity[row];
            text = city[kFJSAddressPickerKeyValue];
        }
            break;
            
        case 2:
        {
            NSDictionary *zone = self.selectedZone[row];
            text = zone[kFJSAddressPickerKeyValue];
        }
            break;
            
        default:
            break;
    }
    
    label.text = text;
    
    return label;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
    return (SCREEN_WIDTH-40)/3;;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
    return 40;
}

// 监听picker的滑动
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    switch (component) {
        case 0:
        {
            NSArray *provinceArr = self.addressDict[kFJSAddressPickerKeyProvince];
            NSDictionary *selectedProvince = provinceArr[row];
            self.selectedProvince = selectedProvince[kFJSAddressPickerKeyKey];
            
            NSDictionary *cityDict = self.addressDict[kFJSAddressPickerKeyCity];
            NSString *cityKey = selectedProvince[kFJSAddressPickerKeyKey];
            self.selectedCity = cityDict[cityKey];
            
            NSDictionary *selectedCity = self.selectedCity.firstObject;
            NSDictionary *zoneDict = self.addressDict[kFJSAddressPickerKeyZone];
            NSString *zoneKey = selectedCity[kFJSAddressPickerKeyKey];
            self.selectedZone = zoneDict[zoneKey];
            
            NSDictionary *selectedZone = self.selectedZone.firstObject;
            
            [self.selectedAddrDict setObject:selectedProvince forKey:kFJSAddressPickerKeyProvince];
            [self.selectedAddrDict setObject:selectedCity forKey:kFJSAddressPickerKeyCity];
            [self.selectedAddrDict setObject:selectedZone forKey:kFJSAddressPickerKeyZone];
            
            [self.pickerView reloadComponent:1];
            [self.pickerView reloadComponent:2];
            
            [self.pickerView selectRow:0 inComponent:1 animated:NO];
            [self.pickerView selectRow:0 inComponent:2 animated:NO];
            
            [self pickerView:self.pickerView didSelectRow:0 inComponent:1];
            [self pickerView:self.pickerView didSelectRow:0 inComponent:2];
        }
            break;
            
        case 1:
        {
            NSDictionary *selectedCity = self.selectedCity[row];
            
            NSDictionary *zoneDict = self.addressDict[kFJSAddressPickerKeyZone];
            NSString *zoneKey = selectedCity[kFJSAddressPickerKeyKey];
            self.selectedZone = zoneDict[zoneKey];
            
            NSDictionary *selectedZone = self.selectedZone.firstObject;
            
            [self.selectedAddrDict setObject:selectedCity forKey:kFJSAddressPickerKeyCity];
            [self.selectedAddrDict setObject:selectedZone forKey:kFJSAddressPickerKeyZone];
            [self.pickerView reloadComponent:2];
            
            [self.pickerView selectRow:0 inComponent:2 animated:NO];
            [self pickerView:self.pickerView didSelectRow:0 inComponent:2];
        }
            break;
            
        case 2:
        {
            NSDictionary *selectedZone = self.selectedZone[row];
            [self.selectedAddrDict setObject:selectedZone forKey:kFJSAddressPickerKeyZone];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark - Show & dismiss
- (void)show
{
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    [self setCurrentData];
    self.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    [UIView animateWithDuration:0.25f animations:^{
        self.alpha = 1;
        _contentView.frame = CGRectMake(0, SCREEN_HEIGHT-245, SCREEN_WIDTH, 245);
        
    } completion:^(BOOL finished) {
        
    }];
}

- (void)dismiss
{
    
    [UIView animateWithDuration:0.2f animations:^{
        self.alpha = 0;
        _contentView.frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 245);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}

#pragma mark - Action
//取消的隐藏
- (void)cancelButtonClick
{
    //优先使用block
    if (self.cancleBlock) {
        self.cancleBlock();
    }
    
    [self dismiss];
    
}

//确认的隐藏
- (void)configButtonClick
{
    //优先使用block
    if (self.confirmBlock) {
        self.confirmBlock(self.selectedAddrDict);
    }
    
    [self dismiss];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    
    if (!CGRectContainsPoint(self.contentView.frame, point)) {
        [self dismiss];
    }
}

@end
