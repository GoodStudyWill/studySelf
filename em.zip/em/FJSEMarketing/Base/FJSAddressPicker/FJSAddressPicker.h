//
//  FJSAddressPicker.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/6.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

FOUNDATION_EXPORT NSString * const kFJSAddressPickerKeyProvince;   //省
FOUNDATION_EXPORT NSString * const kFJSAddressPickerKeyCity;       //市
FOUNDATION_EXPORT NSString * const kFJSAddressPickerKeyZone;       //区

FOUNDATION_EXPORT NSString * const kFJSAddressPickerKeyKey;        //key
FOUNDATION_EXPORT NSString * const kFJSAddressPickerKeyValue;      //value

/**
 确认回调
 key值有province, city, zone
 例：@{
       @"province":@{@"k":@"440000", @"v":@"广东省"},
       @"city"    :@{@"k":@"440300", @"v":@"深圳市"},
       @"zone"    :@"@"k":@"440304", @"v":@"福田区"}
     }
 
 @param addressDict 地址字典
 */
typedef void (^FJSAddressPickerConfirmBlock)(NSDictionary *addressDict);

/**
 取消回调
 */
typedef void (^FJSAddressPickerCancleBlock)();

@interface FJSAddressPicker : UIView

@property (nonatomic, strong) UILabel *titleLabel;

+ (instancetype)addressPickerWithTitle:(NSString *)title
                          confirmBlock:(FJSAddressPickerConfirmBlock)confirmBlock
                           cancleBlock:(FJSAddressPickerCancleBlock)cancleBlock;

+ (instancetype)addressPickerWithConfirmBlock:(FJSAddressPickerConfirmBlock)confirmBlock
                                  cancleBlock:(FJSAddressPickerCancleBlock)cancleBlock;


- (void)show;

@end
