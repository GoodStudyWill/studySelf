//
//  FJSPickerView.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/4.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSPickerView.h"

@interface FJSPickerView ()<UIPickerViewDataSource, UIPickerViewDelegate>

//左边退出按钮
@property (nonatomic, strong) UIButton *cancelButton;
//右边的确定按钮
@property (nonatomic, strong) UIButton *chooseButton;


@property (nonatomic, strong) UIPickerView *pickerView;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UIView *bgView;

@property (nonatomic, copy) NSArray *dataArray;

@property (nonatomic, assign) NSInteger selectedIndex;
@property (nonatomic, copy)   NSString  *selectedString;

@property (nonatomic, copy) FJSPickerViewCancleBlock  cancleBlock;
@property (nonatomic, copy) FJSPickerViewConfirmBlock confirmBlock;

@end

@implementation FJSPickerView

#pragma mark - Init
+ (instancetype)pickerViewWithData:(NSArray *)data
                             title:(NSString *)title
                      confirmBlock:(FJSPickerViewConfirmBlock)confirmBlock
                       cancleBlock:(FJSPickerViewCancleBlock)cancleBlock
{
    FJSPickerView *pickerView = [[FJSPickerView alloc] initWithData:data];
    pickerView.titleLabel.text = title;
    pickerView.confirmBlock = confirmBlock;
    pickerView.cancleBlock = cancleBlock;
    return pickerView;
}

- (instancetype)initWithData:(NSArray *)data
{
    self = [super init];
    if (self) {
        _dataArray = data;
        
        self.backgroundColor = UIColorFromRGBA(0, 0, 0, 0.5);
        self.alpha = 0;
        
        UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 250)];
        contentView.backgroundColor = [UIColor whiteColor];
        [self addSubview:contentView];
        self.contentView = contentView;
        
        self.pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, 45, [UIScreen mainScreen].bounds.size.width, 205)];
        self.pickerView.backgroundColor = [UIColor whiteColor];
        self.pickerView.dataSource = self;
        self.pickerView.delegate = self;
        
        [contentView addSubview:self.pickerView];
        //放按钮的View
        UIView *upVeiw = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 45)];
        upVeiw.backgroundColor = [UIColor whiteColor];
        [contentView addSubview:upVeiw];
        
        //左边的取消按钮
        self.cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.cancelButton.frame = CGRectMake(20, 0, 40, 45);
        [self.cancelButton setTitle:@"取消" forState:UIControlStateNormal];
        self.cancelButton.backgroundColor = [UIColor clearColor];
        self.cancelButton.titleLabel.font = [UIFont systemFontOfSize:15];
        [self.cancelButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
        [self.cancelButton addTarget:self action:@selector(cancelButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [upVeiw addSubview:self.cancelButton];
        
        //右边的确定按钮
        self.chooseButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.chooseButton.frame = CGRectMake([UIScreen mainScreen].bounds.size.width - 60, 0, 40, 45);
        [self.chooseButton setTitle:@"确定" forState:UIControlStateNormal];
        self.chooseButton.backgroundColor = [UIColor clearColor];
        self.chooseButton.titleLabel.font = [UIFont systemFontOfSize:15];
        [self.chooseButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
        [self.chooseButton addTarget:self action:@selector(configButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [upVeiw addSubview:self.chooseButton];
        
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 45)];
        self.titleLabel.textColor = [UIColor blackColor];
        self.titleLabel.font = [UIFont systemFontOfSize:18];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        [upVeiw addSubview:self.titleLabel];
        
        //分割线
        UIView *splitView = [[UIView alloc] initWithFrame:CGRectMake(0, 45, [UIScreen mainScreen].bounds.size.width, 1)];
        splitView.backgroundColor = UIColorFromHex(0xe6e6e6);
        [upVeiw addSubview:splitView];
    }
    return self;
}

#pragma mark - Set current data
- (void)setCurrentData
{
    if (self.dataArray.count > 2) {
        self.selectedIndex = self.dataArray.count / 2;
        self.selectedString = self.dataArray[self.selectedIndex];
        [self.pickerView selectRow:self.selectedIndex inComponent:0 animated:NO];
    } else {
        self.selectedIndex = 0;
        self.selectedString = self.dataArray.firstObject;
    }
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}

//确定每一列返回的东西
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return self.dataArray.count;
}

- (UIView*)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0,SCREEN_WIDTH, 30)];
    label.font = [UIFont systemFontOfSize:15.0];
    label.tag = component*100+row;
    label.textAlignment = NSTextAlignmentCenter;
    NSDictionary *dict = self.dataArray[row];
    NSString *text = dict[@"v"];
    label.text = text;
    
    return label;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
    return 100;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
    return 30;
}

// 监听picker的滑动
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    self.selectedIndex = row;
    self.selectedString = self.dataArray[row];
}

#pragma mark - Show & dismiss
- (void)show
{
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    [self setCurrentData];
    self.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    [UIView animateWithDuration:0.25f animations:^{
        self.alpha = 1;
        _contentView.frame = CGRectMake(0, SCREEN_HEIGHT-245, SCREEN_WIDTH, 245);
        
    } completion:^(BOOL finished) {
        
    }];
}

- (void)dismiss
{
    
    [UIView animateWithDuration:0.2f animations:^{
        self.alpha = 0;
        _contentView.frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 245);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}

#pragma mark - Action
//取消的隐藏
- (void)cancelButtonClick
{
    //优先使用block
    if (self.cancleBlock) {
        self.cancleBlock();
    }
    
    [self dismiss];
    
}

//确认的隐藏
- (void)configButtonClick
{
    //优先使用block
    if (self.confirmBlock) {
        self.confirmBlock(self.selectedIndex, self.selectedString);
    }
    
    [self dismiss];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    
    if (!CGRectContainsPoint(self.contentView.frame, point)) {
        [self dismiss];
    }
}

@end
