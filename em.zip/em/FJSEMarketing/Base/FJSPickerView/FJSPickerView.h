//
//  FJSPickerView.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/4.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^FJSPickerViewCancleBlock)();
typedef void (^FJSPickerViewConfirmBlock)(NSInteger index, NSString *selectedString);

@interface FJSPickerView : UIView

@property (nonatomic, strong) UILabel *titleLabel;

+ (instancetype)pickerViewWithData:(NSArray *)data
                             title:(NSString *)title
                      confirmBlock:(FJSPickerViewConfirmBlock)confirmBlock
                       cancleBlock:(FJSPickerViewCancleBlock)cancleBlock;

- (instancetype)initWithData:(NSArray *)data;

- (void)show;

@end
