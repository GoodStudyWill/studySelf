//
//  FJSDatePicker.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/3.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, FJSDatePickerMode) {
    FJSDatePickerModeDateTime,          //年月日,时分
    FJSDatePickerModeDate,              //年月日
    FJSDatePickerModeDateWithoutDay,    //年月
    FJSDatePickerModeTime,              //时分
};

typedef void (^FJSDatePickerCancleBlock)();
typedef void (^FJSDatePickerConfirmBlock)(NSString *date);

@protocol FJSDatePickerDelegate <NSObject>
@optional

/**
 点击确定按钮

 @param date 日期
 */
-(void)didClickFinishDateTimePickerView:(NSString*)date;


/**
 点击取消按钮
 */
-(void)didClickCancelDateTimePickerView;

@end

@interface FJSDatePicker : UIView

//设置当前时间
@property (nonatomic, strong) NSDate *currentDate;

//设置标题
@property (nonatomic, strong) UILabel *titleLabel;

@property (nonatomic, weak) id<FJSDatePickerDelegate> delegate;

//显示类型
@property (nonatomic, assign) FJSDatePickerMode pickerViewMode;

//分钟时间间隔
@property (nonatomic, assign) NSUInteger minuteTimeInterval;

+ (FJSDatePicker *)datePickerInDateTimeWithTitle:(NSString *)title
                              minuteTimeInterval:(NSUInteger)timeInterval
                                    confirmBlock:(FJSDatePickerConfirmBlock)confirmBlock
                                     cancleBlock:(FJSDatePickerCancleBlock)cancleBlock;

+ (FJSDatePicker *)datePickerWithTitle:(NSString *)title
                                  mode:(FJSDatePickerMode)mode
                          confirmBlock:(FJSDatePickerConfirmBlock)confirmBlock
                           cancleBlock:(FJSDatePickerCancleBlock)cancleBlock;


- (void)show;

@end
