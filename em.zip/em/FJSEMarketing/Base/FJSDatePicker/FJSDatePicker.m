//
//  FJSDatePicker.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/3.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSDatePicker.h"

@interface FJSDatePicker ()<UIPickerViewDataSource, UIPickerViewDelegate>

@property (nonatomic, copy) NSString *yearStr;
@property (nonatomic, copy) NSString *monthStr;

@property (nonatomic, assign) NSInteger yearRange;
@property (nonatomic, assign) NSInteger dayRange;
@property (nonatomic, assign) NSInteger startYear;
@property (nonatomic, assign) NSInteger selectedYear;
@property (nonatomic, assign) NSInteger selectedMonth;
@property (nonatomic, assign) NSInteger selectedDay;
@property (nonatomic, assign) NSInteger selectedHour;
@property (nonatomic, assign) NSInteger selectedMinute;
@property (nonatomic, assign) NSInteger selectedSecond;

@property (nonatomic, strong) NSCalendar *calendar;

//左边退出按钮
@property (nonatomic, strong) UIButton *cancelButton;
//右边的确定按钮
@property (nonatomic, strong) UIButton *chooseButton;


@property (nonatomic, copy) FJSDatePickerConfirmBlock confirmBlock;
@property (nonatomic, copy) FJSDatePickerCancleBlock cancleBlock;

@property (nonatomic, copy)   NSString *string;
@property (nonatomic, strong) UIPickerView *pickerView;
@property (nonatomic, strong) UIView *contentView;
@property (nonatomic, strong) UIView *bgView;

@end

@implementation FJSDatePicker

#pragma mark - Init
+ (FJSDatePicker *)datePickerInDateTimeWithTitle:(NSString *)title
                              minuteTimeInterval:(NSUInteger)timeInterval
                                    confirmBlock:(FJSDatePickerConfirmBlock)confirmBlock
                                     cancleBlock:(FJSDatePickerCancleBlock)cancleBlock
{
    FJSDatePicker *datePicker = [self datePickerWithTitle:title mode:FJSDatePickerModeDateTime confirmBlock:confirmBlock cancleBlock:cancleBlock];
    datePicker.minuteTimeInterval = timeInterval;
    return datePicker;
}

+ (FJSDatePicker *)datePickerWithTitle:(NSString *)title
                                  mode:(FJSDatePickerMode)mode
                          confirmBlock:(FJSDatePickerConfirmBlock)confirmBlock
                           cancleBlock:(FJSDatePickerCancleBlock)cancleBlock
{
    FJSDatePicker *datePicker = [[FJSDatePicker alloc] init];
    datePicker.titleLabel.text = title;
    datePicker.pickerViewMode = mode;
    datePicker.confirmBlock = confirmBlock;
    datePicker.cancleBlock = cancleBlock;
    return datePicker;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.backgroundColor = UIColorFromRGBA(0, 0, 0, 0.5);
        self.alpha = 0;
        
        _minuteTimeInterval = 1;
        
        UIView *contentView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 250)];
        contentView.backgroundColor = [UIColor whiteColor];
        [self addSubview:contentView];
        self.contentView = contentView;
        
        self.pickerView = [[UIPickerView alloc]initWithFrame:CGRectMake(0, 45, [UIScreen mainScreen].bounds.size.width, 205)];
        self.pickerView.backgroundColor = [UIColor whiteColor];
        self.pickerView.dataSource = self;
        self.pickerView.delegate = self;
        
        [contentView addSubview:self.pickerView];
        //放按钮的View
        UIView *upVeiw = [[UIView alloc]initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, 45)];
        upVeiw.backgroundColor = [UIColor whiteColor];
        [contentView addSubview:upVeiw];
        
        //左边的取消按钮
        self.cancelButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.cancelButton.frame = CGRectMake(20, 0, 40, 45);
        [self.cancelButton setTitle:@"取消" forState:UIControlStateNormal];
        self.cancelButton.backgroundColor = [UIColor clearColor];
        self.cancelButton.titleLabel.font = [UIFont systemFontOfSize:15];
        [self.cancelButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
        [self.cancelButton addTarget:self action:@selector(cancelButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [upVeiw addSubview:self.cancelButton];
        
        //右边的确定按钮
        self.chooseButton = [UIButton buttonWithType:UIButtonTypeCustom];
        self.chooseButton.frame = CGRectMake([UIScreen mainScreen].bounds.size.width - 60, 0, 40, 45);
        [self.chooseButton setTitle:@"确定" forState:UIControlStateNormal];
        self.chooseButton.backgroundColor = [UIColor clearColor];
        self.chooseButton.titleLabel.font = [UIFont systemFontOfSize:15];
        [self.chooseButton setTitleColor:UIColorFromHex(0x00a0ea) forState:UIControlStateNormal];
        [self.chooseButton addTarget:self action:@selector(configButtonClick) forControlEvents:UIControlEventTouchUpInside];
        [upVeiw addSubview:self.chooseButton];
        
        self.titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 45)];
        self.titleLabel.textColor = [UIColor blackColor];
        self.titleLabel.font = [UIFont systemFontOfSize:18];
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        [upVeiw addSubview:self.titleLabel];
        
        //分割线
        UIView *splitView = [[UIView alloc] initWithFrame:CGRectMake(0, 45, [UIScreen mainScreen].bounds.size.width, 1)];
        splitView.backgroundColor = UIColorFromHex(0xe6e6e6);
        [upVeiw addSubview:splitView];
        
        
        NSCalendar *calendar0 = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
        NSInteger unitFlags =  NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute;
        NSDateComponents *comps = [calendar0 components:unitFlags fromDate:[NSDate date]];
        NSInteger year=[comps year];
        
        self.startYear=year-15;
        self.yearRange=50;
        [self setCurrentDate:[NSDate date]];

    }
    return self;
}

#pragma mark - Set current date
//默认时间的处理
- (void)setCurrentDate:(NSDate *)currentDate
{
    //获取当前时间
    NSCalendar *calendar0 = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSInteger unitFlags = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay | NSCalendarUnitHour | NSCalendarUnitMinute;
    NSDateComponents *comps = [calendar0 components:unitFlags fromDate:currentDate];
    NSInteger year = [comps year];
    NSInteger month = [comps month];
    NSInteger day = [comps day];
    NSInteger hour = [comps hour];
    NSInteger minute = [comps minute];
    
    self.selectedYear = year;
    self.selectedMonth = month;
    self.selectedDay = day;
    self.selectedHour = hour;
    self.selectedMinute = minute;
    
    self.dayRange = [self isAllDay:year andMonth:month];
    
    if (self.pickerViewMode == FJSDatePickerModeDateTime) {
        NSInteger minuteRow = _minuteTimeInterval > 1 ? 0 : minute;
        [self.pickerView selectRow:year-self.startYear inComponent:0 animated:NO];
        [self.pickerView selectRow:month-1 inComponent:1 animated:NO];
        [self.pickerView selectRow:day-1 inComponent:2 animated:NO];
        [self.pickerView selectRow:hour inComponent:3 animated:NO];
        [self.pickerView selectRow:minute inComponent:4 animated:NO];
        
        [self pickerView:self.pickerView didSelectRow:year-self.startYear inComponent:0];
        [self pickerView:self.pickerView didSelectRow:month-1 inComponent:1];
        [self pickerView:self.pickerView didSelectRow:day-1 inComponent:2];
        [self pickerView:self.pickerView didSelectRow:hour inComponent:3];
        [self pickerView:self.pickerView didSelectRow:minuteRow inComponent:4];
        
        if (_minuteTimeInterval > 1) {
            _string =[NSString stringWithFormat:@"%ld-%.2ld-%.2ld %.2ld:%.2ld", self.selectedYear, self.selectedMonth, self.selectedDay, self.selectedHour, self.selectedMinute];
        }
    }
    else if (self.pickerViewMode == FJSDatePickerModeDate) {
        [self.pickerView selectRow:year-self.startYear inComponent:0 animated:NO];
        [self.pickerView selectRow:month-1 inComponent:1 animated:NO];
        [self.pickerView selectRow:day-1 inComponent:2 animated:NO];
        
        [self pickerView:self.pickerView didSelectRow:year-self.startYear inComponent:0];
        [self pickerView:self.pickerView didSelectRow:month-1 inComponent:1];
        [self pickerView:self.pickerView didSelectRow:day-1 inComponent:2];
        
        _string =[NSString stringWithFormat:@"%ld-%.2ld-%.2ld", self.selectedYear, self.selectedMonth, self.selectedDay];
    }
    else if (self.pickerViewMode == FJSDatePickerModeDateWithoutDay) {
        [self.pickerView selectRow:year-self.startYear inComponent:0 animated:NO];
        [self.pickerView selectRow:month-1 inComponent:1 animated:NO];
        
        _string =[NSString stringWithFormat:@"%ld-%.2ld", self.selectedYear, self.selectedMonth];
    }
    else if (self.pickerViewMode == FJSDatePickerModeTime) {
        [self.pickerView selectRow:hour inComponent:0 animated:NO];
        [self.pickerView selectRow:minute inComponent:1 animated:NO];
        
        [self pickerView:self.pickerView didSelectRow:hour inComponent:0];
        [self pickerView:self.pickerView didSelectRow:minute inComponent:1];
        
        _string = [NSString stringWithFormat:@"%.2ld:00", self.selectedHour];
    }
    
    [self.pickerView reloadAllComponents];
}

#pragma mark - UIPickerViewDataSource
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    if (self.pickerViewMode == FJSDatePickerModeDateTime) {
        return 5;
    }
    else if (self.pickerViewMode == FJSDatePickerModeDate) {
        return 3;
    }
    else if (self.pickerViewMode == FJSDatePickerModeDateWithoutDay) {
        return 2;
    }
    else if (self.pickerViewMode == FJSDatePickerModeTime) {
        return 2;
    }
    return 0;
}


//确定每一列返回的东西
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (self.pickerViewMode == FJSDatePickerModeDateTime) {
        switch (component) {
            case 0:
            {
                return self.yearRange;
            }
                
            case 1:
            {
                return 12;
            }
                
            case 2:
            {
                return self.dayRange;
            }
                
            case 3:
            {
                return 24;
            }
                
            case 4:
            {
                return 6;
            }
                
                
            default:
                break;
        }
    }
    else if (self.pickerViewMode == FJSDatePickerModeDate) {
        switch (component) {
            case 0:
            {
                return self.yearRange;
            }
                
            case 1:
            {
                return 12;
            }
                
            case 2:
            {
                return self.dayRange;
            }
                
                
            default:
                break;
        }
    }
    else if (self.pickerViewMode == FJSDatePickerModeDateWithoutDay) {
        switch (component) {
                
            case 0:
            {
                return self.yearRange;
            }
                
            case 1:
            {
                return 12;
            }
                
                
            default:
                break;
        }
    }
    else if (self.pickerViewMode == FJSDatePickerModeTime) {
        switch (component) {
                
            case 0:
            {
                return 24;
            }
                
            case 1:
            {
                return 60;
            }
                
            default:
                break;
        }
    }
    
    return 0;
}

#pragma mark - UIPickerViewDelegate
- (UIView*)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view
{
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(SCREEN_WIDTH*component/6.0, 0,SCREEN_WIDTH/6.0, 30)];
    label.font = [UIFont systemFontOfSize:15.0];
    label.tag = component*100+row;
    label.textAlignment = NSTextAlignmentCenter;
    if (self.pickerViewMode == FJSDatePickerModeDateTime) {
        switch (component) {
            case 0:
            {
                label.text = [NSString stringWithFormat:@"%ld年",(long)(self.startYear + row)];
            }
                break;
            case 1:
            {
                label.text = [NSString stringWithFormat:@"%ld月",(long)row+1];
            }
                break;
            case 2:
            {
                
                label.text = [NSString stringWithFormat:@"%ld日",(long)row+1];
            }
                break;
            case 3:
            {
                label.textAlignment = NSTextAlignmentRight;
                label.text = [NSString stringWithFormat:@"%ld",(long)row];
            }
                break;
            case 4:
            {
                label.textAlignment = NSTextAlignmentRight;
                label.text = [NSString stringWithFormat:@"%02ld",(long)row*_minuteTimeInterval];
            }
                break;
            case 5:
            {
                label.textAlignment = NSTextAlignmentRight;
                label.text = [NSString stringWithFormat:@"%ld",(long)row];
            }
                break;
                
            default:
                break;
        }
    }
    else if (self.pickerViewMode == FJSDatePickerModeDate) {
        switch (component) {
            case 0:
            {
                label.text = [NSString stringWithFormat:@"%ld年",(long)(self.startYear + row)];
            }
                break;
            case 1:
            {
                label.text = [NSString stringWithFormat:@"%ld月",(long)row+1];
            }
                break;
            case 2:
            {
                label.text = [NSString stringWithFormat:@"%ld日",(long)row+1];
            }
                break;
                
            default:
                break;
        }
    }
    else if (self.pickerViewMode == FJSDatePickerModeDateWithoutDay) {
        switch (component) {
            case 0:
            {
                label.text = [NSString stringWithFormat:@"%ld年",(long)(self.startYear + row)];
            }
                break;
            case 1:
            {
                label.text = [NSString stringWithFormat:@"%ld月",(long)row+1];
            }
                break;
                
            default:
                break;
        }
    }
    else if (self.pickerViewMode == FJSDatePickerModeTime) {
        switch (component) {
            case 0:
            {
                label.textAlignment = NSTextAlignmentRight;
                label.text = [NSString stringWithFormat:@"%ld时",(long)row];
            }
                break;
            case 1:
            {
                label.textAlignment = NSTextAlignmentRight;
                label.text = [NSString stringWithFormat:@"%ld分",(long)row];
            }
                break;
                
            default:
                break;
        }
    }
    
    return label;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView widthForComponent:(NSInteger)component
{
    if (self.pickerViewMode == FJSDatePickerModeDateTime) {
        return ([UIScreen mainScreen].bounds.size.width-40)/5;
    }
    else if (self.pickerViewMode == FJSDatePickerModeDate) {
        return ([UIScreen mainScreen].bounds.size.width-40)/3;
    }
    else if (self.pickerViewMode == FJSDatePickerModeDateWithoutDay) {
        return ([UIScreen mainScreen].bounds.size.width-40)/2;
    }
    else if (self.pickerViewMode == FJSDatePickerModeTime) {
        return ([UIScreen mainScreen].bounds.size.width-40)/2;
    }
    return 0;
}

- (CGFloat)pickerView:(UIPickerView *)pickerView rowHeightForComponent:(NSInteger)component
{
    return 30;
}

// 监听picker的滑动
- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component
{
    if (self.pickerViewMode == FJSDatePickerModeDateTime) {
        switch (component) {
            case 0:
            {
                self.selectedYear = self.startYear + row;
                self.dayRange = [self isAllDay:self.selectedYear andMonth:self.selectedMonth];
                [self.pickerView reloadComponent:2];
                [self.pickerView reloadComponent:4];
            }
                break;
            case 1:
            {
                self.selectedMonth = row+1;
                self.dayRange = [self isAllDay:self.selectedYear andMonth:self.selectedMonth];
                
                //31日变30日或者28日
                BOOL isSelectedDayChange = self.selectedDay > self.dayRange;
                
                [self.pickerView reloadComponent:2];
                [self.pickerView reloadComponent:4];
                
                if (isSelectedDayChange) {
                    [self.pickerView selectRow:self.dayRange-1 inComponent:2 animated:NO];
                    [self pickerView:self.pickerView didSelectRow:self.dayRange-1 inComponent:2];
                }
            }
                break;
            case 2:
            {
                self.selectedDay = row+1;
                [self.pickerView reloadComponent:4];
            }
                break;
            case 3:
            {
                self.selectedHour = row;
                [self.pickerView reloadComponent:4];
            }
                break;
            case 4:
            {
                self.selectedMinute = row*_minuteTimeInterval;
            }
                break;
                
            default:
                break;
        }
        
        _string =[NSString stringWithFormat:@"%ld-%.2ld-%.2ld %.2ld:%.2ld", self.selectedYear, self.selectedMonth, self.selectedDay, self.selectedHour, self.selectedMinute];
    }
    else if (self.pickerViewMode == FJSDatePickerModeDate) {
        switch (component) {
            case 0:
            {
                self.selectedYear = self.startYear + row;
                self.dayRange = [self isAllDay:self.selectedYear andMonth:self.selectedMonth];
                [self.pickerView reloadComponent:2];
            }
                break;
            case 1:
            {
                self.selectedMonth = row+1;
                self.dayRange = [self isAllDay:self.selectedYear andMonth:self.selectedMonth];
                [self.pickerView reloadComponent:2];
            }
                break;
            case 2:
            {
                self.selectedDay = row+1;
            }
                break;
                
            default:
                break;
        }
        
        _string =[NSString stringWithFormat:@"%ld-%.2ld-%.2ld", self.selectedYear, self.selectedMonth, self.selectedDay];
    }
    else if (self.pickerViewMode == FJSDatePickerModeDateWithoutDay) {
        switch (component) {
            case 0:
            {
                self.selectedYear = self.startYear + row;
                self.dayRange = [self isAllDay:self.selectedYear andMonth:self.selectedMonth];
            }
                break;
            case 1:
            {
                self.selectedMonth = row+1;
                self.dayRange = [self isAllDay:self.selectedYear andMonth:self.selectedMonth];
            }
                break;
                
            default:
                break;
        }
        
        _string =[NSString stringWithFormat:@"%ld-%.2ld", self.selectedYear, self.selectedMonth];
    }
    else if (self.pickerViewMode == FJSDatePickerModeTime) {
        switch (component) {
            case 0:
            {
                self.selectedHour = row;
            }
                break;
            case 1:
            {
                self.selectedMinute = row;
            }
                break;
                
            default:
                break;
        }
        
        _string = [NSString stringWithFormat:@"%.2ld:%.2ld", self.selectedHour, self.selectedMinute];
    }
}



#pragma mark - Show & hidden
- (void)show
{
    [[UIApplication sharedApplication].keyWindow addSubview:self];
    [self setCurrentDate:[NSDate date]];
    self.frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT);
    [UIView animateWithDuration:0.25f animations:^{
        self.alpha = 1;
        _contentView.frame = CGRectMake(0, SCREEN_HEIGHT-245, SCREEN_WIDTH, 245);
        
    } completion:^(BOOL finished) {
        
    }];
}

- (void)dismiss
{
    [UIView animateWithDuration:0.2f animations:^{
        self.alpha = 0;
        _contentView.frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 245);
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
    
}

#pragma mark - Action
- (void)cancelButtonClick
{
    //优先使用block
    if (self.cancleBlock) {
        self.cancleBlock();
    } else {
        if (self.delegate != nil && [self.delegate respondsToSelector:@selector(didClickCancelDateTimePickerView)]) {
            [self.delegate didClickCancelDateTimePickerView];
        }
    }
    [self dismiss];
}

- (void)configButtonClick
{
    //优先使用block
    if (self.confirmBlock) {
        self.confirmBlock(self.string);
    } else {
        if (self.delegate != nil && [self.delegate respondsToSelector:@selector(didClickFinishDateTimePickerView:)]) {
            [self.delegate didClickFinishDateTimePickerView:_string];
        }
    }
    [self dismiss];
}

- (NSInteger)isAllDay:(NSInteger)year andMonth:(NSInteger)month
{
    int day=0;
    switch(month)
    {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
            day=31;
            break;
        case 4:
        case 6:
        case 9:
        case 11:
            day=30;
            break;
        case 2:
        {
            if(((year%4==0)&&(year%100!=0))||(year%400==0))
            {
                day=29;
                break;
            }
            else
            {
                day=28;
                break;
            }
        }
        default:
            break;
    }
    return day;
}


- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self];
    
    if (!CGRectContainsPoint(self.contentView.frame, point)) {
        [self dismiss];
    }
}

@end
