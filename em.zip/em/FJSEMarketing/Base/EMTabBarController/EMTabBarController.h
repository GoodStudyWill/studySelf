//
//  EMTabBarController.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/11.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EMTabBarController : UITabBarController

@end
