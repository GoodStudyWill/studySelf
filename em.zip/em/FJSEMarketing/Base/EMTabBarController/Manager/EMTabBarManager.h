//
//  EMTabBarManager.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/11/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface EMTabBarManager : NSObject<UITabBarControllerDelegate>

+ (EMTabBarManager *)sharedManager;

+ (void)releaseManager;

@end
