//
//  EMTabBarManager.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/11/10.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMTabBarManager.h"
#import "EMMortgageViewController.h"

@implementation EMTabBarManager

static EMTabBarManager *manager = nil;

+ (EMTabBarManager *)sharedManager
{
    
    @synchronized([EMTabBarManager class])
    {
        if(!manager)
            manager = [[EMTabBarManager alloc] init];
    }
    return manager;
}

+ (void)releaseManager
{
    manager = nil;
}

//防止tabbarItem双击
- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController
{
    if (tabBarController.selectedViewController == viewController) {
        return NO;
    }
    return YES;
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController
{
    if ([viewController isKindOfClass:[UINavigationController class]]) {
        UINavigationController *navigationController = (UINavigationController *)viewController;
        UIViewController *childVC = navigationController.topViewController;
        if ([childVC isKindOfClass:[EMMortgageViewController class]]) {
            EMMortgageViewController *mortgageViewController = (EMMortgageViewController *)childVC;
            [mortgageViewController login];
        }
        
    }
}

@end
