//
//  EMTabBarController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/11.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMTabBarController.h"
#import "EMHomePageViewController.h"
#import "EMScheduleMainViewController.h"
#import "EMUndoneViewController.h"
#import "EMAgencyViewController.h"
#import "FJSWebViewController.h"
#import "EMMortgageViewController.h"
#import "EMTabBarManager.h"

@interface EMTabBarController ()

@end

@implementation EMTabBarController

#pragma mark - Life cycle
+ (void)initialize
{
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSFontAttributeName] = [UIFont systemFontOfSize:12];
    attrs[NSForegroundColorAttributeName] = UIColorFromHex(0x999999);
    
    NSMutableDictionary *selectedAtts = [NSMutableDictionary dictionary];
    selectedAtts[NSFontAttributeName] = [UIFont systemFontOfSize:12];
    selectedAtts[NSForegroundColorAttributeName] = UIColorFromHex(0x00a0ea);
    
    UITabBar *tabBar = [UITabBar appearance];
    [tabBar setTintColor:UIColorFromHex(0x00a0ea)];
    [tabBar setBackgroundImage:[UIImage new]];
    [tabBar setShadowImage:[UIImage new]];
    tabBar.translucent = NO;
    
    UITabBarItem *item = [UITabBarItem appearance];
    [item setTitleTextAttributes:attrs forState:UIControlStateNormal];
    [item setTitleTextAttributes:selectedAtts forState:UIControlStateSelected];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [EMTabBarManager releaseManager];
    self.delegate = [EMTabBarManager sharedManager];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self setupAllChildViewController];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
//    self.tabBar.translucent = NO;
//    self.selectedIndex = 1;
}

#pragma mark - Setup child viewController
- (void)setupAllChildViewController
{
    EMHomePageViewController *homePageViewController = [[EMHomePageViewController alloc] initWithNibName:@"EMHomePageViewController" bundle:nil];
    [self setupChildVCWithVC:homePageViewController title:@"首页" image:@"icon_home_nor" selectedImage:@"icon_home_sel"];
    
    EMScheduleMainViewController *scheduleViewController = [[EMScheduleMainViewController alloc] init];
    scheduleViewController.title = @"我的计划";
    [self setupChildVCWithVC:scheduleViewController title:@"计划" image:@"icon_plan_nor" selectedImage:@"icon_plan_sel"];
    
    EMAgencyViewController *agencyViewController = [[EMAgencyViewController alloc] init];
    agencyViewController.title = @"我的中介";
    [self setupChildVCWithVC:agencyViewController title:@"中介" image:@"icon_medi_nor" selectedImage:@"icon_medi_sel"];
    
    EMUndoneViewController *reportViewController = [[EMUndoneViewController alloc] init];
    reportViewController.title = @"我的报表";
    reportViewController.image = [UIImage imageNamed:@"img_form"];
    [self setupChildVCWithVC:reportViewController title:@"报表" image:@"icon_form_sel" selectedImage:@"icon_form_sel"];
    
    EMMortgageViewController *mortgageViewController = [[EMMortgageViewController alloc] init];
    mortgageViewController.title = @"我的进件";
    [self setupChildVCWithVC:mortgageViewController title:@"进件" image:@"icon_jinjian_nor" selectedImage:@"icon_jinjian_sel"];
}

- (void)setupChildVCWithVC:(UIViewController *)vc title:(NSString *)title image:(NSString *)image selectedImage:(NSString *)selectedImage
{
    vc.tabBarItem.title = title;
    vc.tabBarItem.image = [UIImage imageNamed:image];
    vc.tabBarItem.selectedImage = [UIImage imageNamed:selectedImage];
    UINavigationController *navViewController = [[UINavigationController alloc] initWithRootViewController:vc];
    navViewController.navigationBar.barTintColor = UIColorFromHex(0x00a0ea);
    navViewController.navigationBar.translucent = NO;
//    navViewController.navigationBar.barStyle = UIBarStyleBlack;
//    vc.title = title;
    [self addChildViewController:navViewController];
}

@end
