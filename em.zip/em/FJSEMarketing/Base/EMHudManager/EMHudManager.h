//
//  EMHudManager.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/18.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MBProgressHUD/MBProgressHUD.h>

static NSUInteger const kHUDTimeInterval = 1.0f;

typedef NS_ENUM(NSUInteger, EMHUDShowType) {
    EMHUDShowTypeSuccess,
    EMHUDShowTypeFailed,
    EMHUDShowTypeWarning,
};

@interface EMHudManager : NSObject

+ (void)showHudWithTitle:(NSString *)title
                  detail:(NSString *)detail
                    type:(EMHUDShowType)type
         completionBlock:(MBProgressHUDCompletionBlock)completionBlock;

+ (void)showHudWithTitle:(NSString *)title
                  detail:(NSString *)detail
                    type:(EMHUDShowType)type
                    time:(NSTimeInterval)time
         completionBlock:(MBProgressHUDCompletionBlock)completionBlock;

+ (void)showLoading;

+ (void)showLoadingWithText:(NSString *)text;

+ (void)showLoadingWithText:(NSString *)text inView:(UIView *)view;

+ (void)showText:(NSString *)text;

+ (void)showText:(NSString *)text inView:(UIView *)view;

+ (void)hideLoading;

+ (void)hideLoadingForView:(UIView *)view;

@end
