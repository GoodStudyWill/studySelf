//
//  EMHudManager.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/7/18.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMHudManager.h"

@implementation EMHudManager

+ (void)showHudWithTitle:(NSString *)title
                  detail:(NSString *)detail
                    type:(EMHUDShowType)type
         completionBlock:(MBProgressHUDCompletionBlock)completionBlock
{
    [self showHudWithTitle:title detail:detail type:type time:kHUDTimeInterval completionBlock:completionBlock];
}

+ (void)showHudWithTitle:(NSString *)title
                  detail:(NSString *)detail
                    type:(EMHUDShowType)type
                    time:(NSTimeInterval)time
         completionBlock:(MBProgressHUDCompletionBlock)completionBlock
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:[UIApplication sharedApplication].keyWindow animated:YES];
    hud.mode = MBProgressHUDModeCustomView;

    hud.bezelView.backgroundColor = [UIColor whiteColor];
    hud.minSize = CGSizeMake(310, 143);
    hud.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
    
    NSString *imageName = nil;
    switch (type) {
        case EMHUDShowTypeSuccess:
        {
            imageName = @"icon_success";
        }
            break;
            
        case EMHUDShowTypeFailed:
        {
            imageName = @"icon_fail";
        }
            break;
            
        case EMHUDShowTypeWarning:
        {
            imageName = @"icon_Q";
        }
            break;
    }
    
    hud.customView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
    
    hud.label.text = title;
    hud.label.font = [UIFont boldSystemFontOfSize:18];
    hud.label.textColor = UIColorFromHex(0x666666);
    
    if (!detail || detail.length == 0) {
        hud.detailsLabel.text = nil;
    } else {
        NSString *lineBreak = @"\n";
        NSMutableAttributedString *detailStr = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@%@", lineBreak, detail]];
        [detailStr addAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:15],
                                   NSForegroundColorAttributeName : UIColorFromHex(0x666666),
                                   }
                           range:NSMakeRange(lineBreak.length, detailStr.length-lineBreak.length)];
        [detailStr addAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:6],
                                   NSForegroundColorAttributeName : UIColorFromHex(0x666666),
                                   }
                           range:NSMakeRange(0, lineBreak.length)];
        hud.detailsLabel.attributedText = detailStr;
    }
    
    hud.removeFromSuperViewOnHide = YES;
    [hud hideAnimated:YES afterDelay:time];
    [hud setCompletionBlock:completionBlock];
}

+ (void)showLoadingWithText:(NSString *)text inView:(UIView *)view
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    hud.graceTime = 0.8f;
    
    hud.mode = MBProgressHUDModeIndeterminate;
    if (text) {
        hud.label.text = text;
    }
    
    [hud hideAnimated:YES afterDelay:45];
    hud.removeFromSuperViewOnHide = YES;
}

+ (void)showLoading
{
    [self showLoadingWithText:nil];
}

+ (void)showLoadingWithText:(NSString *)text
{
    [self showLoadingWithText:text inView:[UIApplication sharedApplication].keyWindow];
}

+ (void)hideLoading
{
    [self hideLoadingForView:[UIApplication sharedApplication].keyWindow];
}

+ (void)hideLoadingForView:(UIView *)view
{
    [MBProgressHUD hideHUDForView:view animated:YES];
}

+ (void)showText:(NSString *)text
{
    [self showText:text inView:[UIApplication sharedApplication].keyWindow];
}

+ (void)showText:(NSString *)text inView:(UIView *)view
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:view animated:YES];
    
    hud.mode = MBProgressHUDModeText;
    hud.bezelView.backgroundColor = [UIColor blackColor];
    hud.detailsLabel.textColor = [UIColor whiteColor];
    hud.detailsLabel.font = [UIFont systemFontOfSize:16];
    if (text) {
        hud.detailsLabel.text = text;
    }
    
    hud.removeFromSuperViewOnHide = YES;
    [hud hideAnimated:YES afterDelay:2.0];
}

@end
