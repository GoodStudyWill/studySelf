//
//  FJSWebViewController+BussinessCommon.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/11/28.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSWebViewController.h"

@interface FJSWebViewController (BussinessCommon)

- (void)loadingBegin;

- (void)loadingFinish;

@end
