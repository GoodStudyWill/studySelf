//
//  FJSWebViewController.h
//  PADolphinCove
//
//  Created by xuyq on 2017/5/10.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FJSJavaScriptBridge.h"
#import "FJSBaseHandler.h"
#import <WebKit/WebKit.h>

@class WKWebView;
@class EMScheduleModel;

@protocol FJSWebViewControllerDelegate <NSObject>

@optional
- (void)callOnBackJSStringWithParams:(NSDictionary *)params;

- (void)callBackRefreshSchedules:(NSString *)date;

@end

@interface FJSWebViewController : UIViewController <FJSJavaScriptBridgeDelegate, FJSWebService>

@property (nonatomic, strong) WKWebView *webView;

@property (nonatomic, weak) id<FJSWebViewControllerDelegate> delegate;

@property (nonatomic, strong) NSMutableDictionary *moduleHandlers;

@property (nonatomic, copy) NSString *moduleName;

@property (nonatomic, copy) NSString *urlString;

//从消息弹框跳转过来
@property (nonatomic, assign) BOOL comeFromPush;

- (instancetype)initWithUrlString:(NSString *)urlString;

/**
 加载urlString页面，自动识别在线还是本地，本地的还需要指定moduleName
 */
- (void)loadPage;

- (void)refresh;

- (void)addModuleHandlers;

- (void)addModuleHandler:(id)handler;

- (void)showLeftBarButtonItemWithImage:(NSString *)imageName;

@end
