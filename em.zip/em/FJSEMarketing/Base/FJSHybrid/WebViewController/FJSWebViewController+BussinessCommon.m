//
//  FJSWebViewController+BussinessCommon.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/11/28.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSWebViewController+BussinessCommon.h"

@implementation FJSWebViewController (BussinessCommon)

- (void)loadingBegin
{
    [EMHudManager hideLoadingForView:self.webView];
    [EMHudManager showLoadingWithText:nil inView:self.webView];

}

- (void)loadingFinish
{
    [EMHudManager hideLoadingForView:self.webView];
}

@end

