//
//  FJSNoInputAccessoryViewHelper.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/7.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSNoInputAccessoryViewHelper.h"
#import <objc/runtime.h>
#import <WebKit/WebKit.h>

@implementation FJSNoInputAccessoryViewHelper

- (id)inputAccessoryView {
    return nil;
}

- (void)removeInputAccessoryViewFromWKWebView:(WKWebView *)webView
{
    UIView *targetView;
    
    for (UIView *view in webView.scrollView.subviews) {
        if([[view.class description] hasPrefix:@"WKContent"]) {
            targetView = view;
        }
    }
    
    if (!targetView) {
        return;
    }
    
    NSString *noInputAccessoryViewClassName = [NSString stringWithFormat:@"%@_NoInputAccessoryView", targetView.class.superclass];
    Class newClass = NSClassFromString(noInputAccessoryViewClassName);
    
    if(newClass == nil) {
        newClass = objc_allocateClassPair(targetView.class, [noInputAccessoryViewClassName cStringUsingEncoding:NSASCIIStringEncoding], 0);
        if(!newClass) {
            return;
        }
        
        Method method = class_getInstanceMethod([FJSNoInputAccessoryViewHelper class], @selector(inputAccessoryView));
        
        class_addMethod(newClass, @selector(inputAccessoryView), method_getImplementation(method), method_getTypeEncoding(method));
        
        objc_registerClassPair(newClass);
    }
    
    object_setClass(targetView, newClass);
}

@end
