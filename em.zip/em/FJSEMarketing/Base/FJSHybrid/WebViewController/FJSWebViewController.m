//
//  FJSWebViewController.m
//  PADolphinCove
//
//  Created by xuyq on 2017/5/10.
//  Copyright © 2017年 PingAn. All rights reserved.
//

#import <QuickLook/QuickLook.h>
#import "FJSWebViewController.h"
#import "FJSModuleHandler.h"
#import "NSDictionary+FJSJavaScript.h"
#import "WKWebView+FJSJavaScript.h"
#import "EMAppConfig.h"
#import "FJSDatePicker.h"
#import "FJSPickerView.h"
#import "FJSAddressPicker.h"
#import "FJSNoInputAccessoryViewHelper.h"
#import "UIBarButtonItem+FJSUIKit.h"
#import "EMUndoneScheduleViewController.h"

@interface FJSWebViewController ()<QLPreviewControllerDelegate, QLPreviewControllerDataSource, WKNavigationDelegate, FJSWebViewControllerDelegate, FJSBusinessCommonDelegate, FJSBusinessJumpDelegate, FJSHttpPluginDelegate, FJSPickerHandlerDelegate, FJSHeaderHandlerDelegate, FJSContractHandlerDelegate, EMScheduleHandlerDelegate, FJSCommonHandlerDelegate, FJSMortgageHandlerDelegate>

@property (nonatomic, strong) FJSJavaScriptBridge *jsBridge;

@property (nonatomic, strong) NSMutableDictionary *eventStrategyMap;

//setHeader接口使用
@property (nonatomic, copy) NSString *leftBtnCallback;
@property (nonatomic, copy) NSString *rightBtnCallBack;

@property (nonatomic, strong) NSURL *fileURL;

@property (nonatomic, strong) UINavigationController *previewNaviController;

@end

@implementation FJSWebViewController

#pragma mark - LifeCycle
- (instancetype)initWithUrlString:(NSString *)urlString
{
    self = [super init];
    if (self) {
        self.urlString = urlString;
        self.comeFromPush = NO;
    }
    return self;
}

- (void)loadView
{
    [super loadView];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self addModuleHandlers];
    [self.view addSubview:self.webView];
    [self setupUserAgent];
    [self loadPage];
    
    
//    FJSNoInputAccessoryViewHelper *helper = [FJSNoInputAccessoryViewHelper new];
//    [helper removeInputAccessoryViewFromWKWebView:self.webView];
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    FJSLog(@"self.webview.url=>%@", self.webView.URL);
    [self.navigationController.navigationBar setBackgroundImage:[UIImage new] forBarPosition:UIBarPositionAny barMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:[UIImage new]];
    if (!self.webView.URL) {
        [self loadPage];
    }
}

- (void)dealloc
{
    if (_jsBridge) {
        [_jsBridge removeScriptMessageHandlers];
    }
    FJSLog(@"");
}

#pragma mark - Load page
- (void)loadPage
{
    [EMHudManager showLoadingWithText:nil inView:self.webView];
    NSURL *url = [NSURL URLWithString:self.urlString];
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    [self.webView loadRequest:request];
}

- (void)refresh
{
    [self.webView fjs_evaluateRefresh];
}

- (void)setupUserAgent
{
    //默认不设置模块名，如果有模块名，userAgent加上模块名和环境
    if (self.moduleName.length == 0) {
        return;
    }
    
    __weak FJSWebViewController *weakSelf = self;
    [self.webView evaluateJavaScript:@"navigator.userAgent" completionHandler:^(id result, NSError *error) {
        NSString *userAgent = result;
        userAgent = [userAgent stringByAppendingString:[NSString stringWithFormat:@" opmgt/%@", [EMAppConfig sharedInstance].userAgentSSEnv]];
        weakSelf.webView.customUserAgent = userAgent;
    }];
}

#pragma mark - Handlers
- (void)addModuleHandlers
{
//    FJSBusinessCommonHandler *businessCommonHandler = [FJSBusinessCommonHandler new];
//    businessCommonHandler.delegate = self;
//    [self addModuleHandler:businessCommonHandler];
//
    FJSBusinessJumpHandler *businessJumpHandler = [FJSBusinessJumpHandler new];
    businessJumpHandler.delegate = self;
    [self addModuleHandler:businessJumpHandler];

    FJSHttpPluginHandler *httpPluginHandler = [FJSHttpPluginHandler new];
    httpPluginHandler.delegate = self;
    [self addModuleHandler:httpPluginHandler];

    FJSPickerHandler *pickerHandler = [FJSPickerHandler new];
    pickerHandler.delegate = self;
    [self addModuleHandler:pickerHandler];

    FJSHeaderHandler *headerHandler = [FJSHeaderHandler new];
    headerHandler.delegate = self;
    [self addModuleHandler:headerHandler];

    EMScheduleHandler *scheduleHandler = [EMScheduleHandler new];
    scheduleHandler.delegate = self;
    [self addModuleHandler:scheduleHandler];

    FJSContractHandler *contractHanlder = [FJSContractHandler new];
    contractHanlder.delegate = self;
    [self addModuleHandler:contractHanlder];

    FJSCommonHandler *commonHandler = [FJSCommonHandler new];
    commonHandler.delegate = self;
    [self addModuleHandler:commonHandler];

    FJSMortgageHandler *mortgageHandler = [FJSMortgageHandler new];
    mortgageHandler.delegate = self;
    [self addModuleHandler:mortgageHandler];
    
    //------------
    Class handlerCls = NSClassFromString(@"FJSBusinessCommonHandler");
    id handler = [[handlerCls alloc] init];
    if ([handler isKindOfClass:[FJSBaseHandler class]]) {
        FJSBaseHandler *oneHandler = (FJSBaseHandler *)handler;
        oneHandler.webService = self;
        [self addModuleHandler:oneHandler];
    }
    
}
//-------------------------
- (void)addModuleHandler:(id)handler
{
    [self.moduleHandlers setObject:handler forKey:NSStringFromClass([handler class])];
    if ([handler isKindOfClass:[FJSBaseHandler class]]) {
        FJSBaseHandler *oneHandler = (FJSBaseHandler *)handler;
        oneHandler.webService = self;
        if (oneHandler.eventMap && oneHandler.eventMap.count > 0) {
            for (NSString *key in oneHandler.eventMap.allKeys) {
                NSString *selStr = oneHandler.eventMap[key];
                SEL sel = NSSelectorFromString(selStr);
                NSInvocation *invocation = [self invocationWithSelector:sel];
                [self.eventStrategyMap setObject:invocation forKey:key];
            }
        }
    }
}

#pragma mark - Set header
-(void)showLeftBarButtonItemWithImage:(NSString *)imageName
{
    [self showLeftBarButtonItemWithTitle:nil buttonImage:imageName];
}

-(void)showLeftBarButtonItemWithTitle:(NSString *)title buttonImage:(NSString *)imageName
{
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem showLeftBarButtonItemWithTitle:title orButtonImage:imageName target:self selector:@selector(clickLeftBarButton:)];
}

-(void)showRightBarButtonItemWithTitle:(NSString *)title orButtonImage:(NSString *)imageName titleColor:(UIColor *)titleColor
{
    self.navigationItem.rightBarButtonItem = [UIBarButtonItem showRightBarButtonItemWithTitle:title orButtonImage:imageName titleColor:titleColor target:self selector:@selector(clickRightBarButton:)];
}

- (void)clickLeftBarButton:(id)sender
{
    if(self.leftBtnCallback.length > 0)
    {
        NSMutableDictionary *callbackDict = [NSMutableDictionary new];
        [callbackDict setObject:self.leftBtnCallback forKey:@"callback"];
        [callbackDict setObject:@{} forKey:@"params"];
        [self.webView fjs_callBackEvaluateJavaScriptString:callbackDict];
    }
    else
    {
        if (self.delegate && [self.delegate respondsToSelector:@selector(callOnBackJSStringWithParams:)]) {
            NSMutableDictionary *onBackParams = [NSMutableDictionary dictionary];
            [onBackParams setObject:self.urlString forKey:@"url"];
            [self.delegate callOnBackJSStringWithParams:onBackParams];
        }
        if (self.navigationController.viewControllers.count > 1)
        {
            [self.navigationController popViewControllerAnimated:YES];
        }
        else
        {
            [self.navigationController dismissViewControllerAnimated:YES completion:nil];
        }
    }
}

- (void)clickRightBarButton:(id)sender
{
    if(self.rightBtnCallBack.length > 0)
    {
        NSMutableDictionary *callbackDict = [NSMutableDictionary new];
        [callbackDict setObject:self.rightBtnCallBack forKey:@"callback"];
        [callbackDict setObject:@{} forKey:@"params"];
        [self.webView fjs_callBackEvaluateJavaScriptString:callbackDict];
    }
    else
    {
        
    }
}

#pragma mark - Handle onback JS
- (void)handleOnBackJSStringWithParams:(NSDictionary *)params
{
    if (self.delegate && [self.delegate isKindOfClass:[FJSWebViewController class]] && [self.delegate respondsToSelector:@selector(callOnBackJSStringWithParams:)]) {
        FJSLog(@"%@", self);
        FJSWebViewController *vc = (FJSWebViewController *)self.delegate;
        NSString *urlString = vc.urlString;
        NSDictionary *data = params[@"data"];
        if (data && [data isKindOfClass:[NSDictionary class]]) {
            urlString = [NSString stringWithFormat:@"%@?", vc.urlString];
            for (NSString *key in data.allKeys) {
                NSString *value = data[key];
                urlString = [urlString stringByAppendingString:[NSString stringWithFormat:@"%@=%@&", key, value]];
            }
            urlString = [urlString stringByAppendingString:[NSString stringWithFormat:@"type=%@", params[@"type"]]];
        } else {
            urlString = [urlString stringByAppendingString:[NSString stringWithFormat:@"?type=%@", params[@"type"]]];
        }
        
        NSMutableDictionary *onBackParams = [NSMutableDictionary dictionaryWithDictionary:params];
        [onBackParams setObject:urlString forKey:@"url"];
        [self.delegate callOnBackJSStringWithParams:onBackParams];
    }
}

#pragma mark - FJSWebViewControllerDelegate
- (void)callOnBackJSStringWithParams:(NSDictionary *)params
{
    [self.webView fjs_onBackEvaluateJavaScriptString:params];
}

#pragma mark - FJSBusinessCommonDelegate
- (void)handler:(FJSBusinessCommonHandler *)handler callTip:(NSString *)text
{
    [EMHudManager showText:text];
}

- (void)handler:(FJSBusinessCommonHandler *)handler callCallBackJSWithParams:(NSDictionary *)params
{
    [EMHudManager hideLoadingForView:self.webView];
    [self.webView fjs_callBackEvaluateJavaScriptString:params];
}

//- (void)loadingBegin:(FJSBusinessCommonHandler *)handler
//{
//    [EMHudManager hideLoadingForView:self.webView];
//    [EMHudManager showLoadingWithText:nil inView:self.webView];
//}

//- (void)loadingBegin
//{
//    [EMHudManager hideLoadingForView:self.webView];
//    [EMHudManager showLoadingWithText:nil inView:self.webView];
//
//}
//
//- (void)loadingFinish
//{
//    [EMHudManager hideLoadingForView:self.webView];
//}


#pragma mark - FJSBusinessJumpDelegate
- (void)handler:(FJSBusinessJumpHandler *)handler callForwardToNewPageWithParams:(NSDictionary *)params
{
    NSString *url = params[@"url"];
    NSString *title = params[@"title"];
    NSString *moduleName = params[@"moduleName"];
    if (!moduleName)
    {
        moduleName = self.moduleName;
    }
    
    if (!url.length)
    {
        NSLog(@"error. url is blank");
        return;
    }
    
    FJSWebViewController *newPageViewController = [[FJSWebViewController alloc]initWithUrlString:url];
    newPageViewController.moduleName = moduleName;
    newPageViewController.title = title;
    newPageViewController.hidesBottomBarWhenPushed = YES;
    newPageViewController.delegate = self;
    [newPageViewController showLeftBarButtonItemWithImage:@"icon_back"];
    [self.navigationController pushViewController:newPageViewController animated:YES];
    
    [self.webView fjs_callBackEvaluateJavaScriptString:params];
}

- (void)handler:(FJSBusinessJumpHandler *)handler callForwardInCurPageWithParams:(NSDictionary *)params
{
    NSString *url = params[@"url"];
    
    //#warning 暂时没有定义moduleName字段
    
    if (!url.length)
    {
        FJSLog(@"error. url is blank");
        return;
    }
    
    //停止当前页面加载
    [EMHudManager hideLoadingForView:self.webView];
    [self.webView stopLoading];
    
    //设置新页面参数
    self.urlString = url;
    
    //加载页面
    [self loadPage];
    
    [self.webView fjs_callBackEvaluateJavaScriptString:params];
}

- (void)handler:(FJSBusinessJumpHandler *)handler callBackJSStringWithParams:(NSDictionary *)params
{
    NSString *urlStr = [[EMAppConfig sharedInstance] completeH5URLForPath:params[@"url"]];
    FJSWebViewController *viewController = nil;
    for (UIViewController *aViewController in self.navigationController.viewControllers) {
        if (![aViewController isKindOfClass:[FJSWebViewController class]]) {
            break;
        }
        
        FJSWebViewController *aWebViewController = (FJSWebViewController *)aViewController;
        if ([aWebViewController.urlString isEqualToString:urlStr]) {
            viewController = aWebViewController;
            break;
        }
    }
    
    [self handleOnBackJSStringWithParams:params];
    if (viewController) {
        [self.navigationController popToViewController:viewController animated:YES];
    } else {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark - FJSCommonHandlerDelegate
- (void)handler:(FJSCommonHandler *)handler callBackToRootJSStringWithParams:(NSDictionary *)params
{
    [self handleOnBackJSStringWithParams:params];
    //如果有待反馈页面，返回到待反馈页面
    for (UIViewController *viewController in self.navigationController.childViewControllers) {
        if ([viewController isKindOfClass:[EMUndoneScheduleViewController class]]) {
            [self.navigationController popToViewController:viewController animated:YES];
            return;
        }
    }
    
    if (self.comeFromPush) {
        [self.navigationController popViewControllerAnimated:YES];
    } else {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
}
 
#pragma mark - FJSHttpPluginDelegate
- (void)handler:(FJSHttpPluginHandler *)handler callHttpSuccess:(NSDictionary *)params
{
    [EMHudManager hideLoadingForView:self.webView];
    [self.webView fjs_callBackEvaluateJavaScriptString:params];
}

- (void)handler:(FJSHttpPluginHandler *)handler callHttpFailed:(NSDictionary *)params
{
    [EMHudManager hideLoadingForView:self.webView];
    if (params) {
        [self.webView fjs_callBackEvaluateJavaScriptString:params];
    }
}

#pragma mark - FJSPickerHandlerDelegate
///显示时间选择器
- (void)handler:(FJSPickerHandler *)handler callShowPickerViewInMode:(FJSDatePickerMode)mode withParams:(NSDictionary *)params
{
    NSString *title = params[@"title"];
    NSString *callBack = params[@"callback"];
    NSMutableDictionary *callBackDict = [NSMutableDictionary dictionary];
    [callBackDict setObject:callBack forKey:@"callback"];
    
    __weak FJSWebViewController *weakSelf = self;
    FJSDatePicker *pickerView = nil;
    if (mode == FJSDatePickerModeDateTime) {
        pickerView = [FJSDatePicker datePickerInDateTimeWithTitle:title minuteTimeInterval:10 confirmBlock:^(NSString *date) {
            FJSLog(@"date => %@", date);
            [weakSelf callBackEvaluateParams:callBackDict date:date success:YES];
        } cancleBlock:^{
            FJSLog(@"cancle");
        }];
    } else {
        pickerView = [FJSDatePicker datePickerWithTitle:title mode:mode confirmBlock:^(NSString *date) {
            FJSLog(@"date => %@", date);
            [weakSelf callBackEvaluateParams:callBackDict date:date success:YES];
        } cancleBlock:^{
            FJSLog(@"cancle");
        }];
    }
    
    [pickerView show];
}

///显示地址选择器
- (void)handler:(FJSPickerHandler *)handler callAddressPickerWithParams:(NSDictionary *)params
{
    NSString *title = params[@"title"];
    NSString *callBack = params[@"callback"];
    NSMutableDictionary *callBackDict = [NSMutableDictionary dictionary];
    [callBackDict setObject:callBack forKey:@"callback"];
    
    __weak FJSWebViewController *weakSelf = self;
    FJSAddressPicker *pickerView = [FJSAddressPicker addressPickerWithTitle:title confirmBlock:^(NSDictionary *addressDict) {
        FJSLog(@"address => %@", addressDict);
        [weakSelf callBackEvaluateParams:callBackDict data:addressDict msg:@"" success:YES];
    } cancleBlock:^{
    }];
    [pickerView show];
    
}

///显示单轮选择器
- (void)handler:(FJSPickerHandler *)handler callSinglePickerWithParams:(NSDictionary *)params
{
    NSString *title = params[@"title"];
    NSString *callBack = params[@"callback"];
    NSMutableDictionary *callBackDict = [NSMutableDictionary dictionary];
    [callBackDict setObject:callBack forKey:@"callback"];
    
    NSArray *data = params[@"data"];
    __weak FJSWebViewController *weakSelf = self;
    FJSPickerView *pickerView = [FJSPickerView pickerViewWithData:data title:title confirmBlock:^(NSInteger index, NSString *selectedString) {
        FJSLog(@"index => %ld, str => %@", index, selectedString);
        NSDictionary *selectedDict= data[index];
        NSMutableDictionary *dataDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:selectedDict[@"k"], @"c1", nil];
        [weakSelf callBackEvaluateParams:callBackDict data:dataDict msg:selectedString success:YES];
    } cancleBlock:^{
    }];
    [pickerView show];
}

///回调时间选择器结果给H5
- (void)callBackEvaluateParams:(NSMutableDictionary *)params date:(NSString *)date success:(BOOL)isSuccess
{
    NSMutableDictionary *dataDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:date, @"date", nil];
    [self callBackEvaluateParams:params data:dataDict msg:date success:isSuccess];
}

///回调选择器结果给H5
- (void)callBackEvaluateParams:(NSMutableDictionary *)params data:(NSDictionary *)data msg:(NSString *)msg success:(BOOL)isSuccess
{
    NSString *codeStr = isSuccess ? @"1" : @"0";
    
    NSMutableDictionary *callBackParams = [NSMutableDictionary dictionary];
    [callBackParams setObject:codeStr forKey:@"code"];
    [callBackParams setObject:data forKey:@"data"];
    [callBackParams setObject:msg forKey:@"msg"];
    
    [params setObject:callBackParams forKey:@"params"];
    
    [self.webView fjs_callBackEvaluateJavaScriptString:params];
}

#pragma mark - FJSHeaderHandlerDelegate
- (void)handler:(FJSHeaderHandler *)handler callBackJSHeaderWithParams:(NSDictionary *)params
{
    NSString *title = params[@"title"];
    NSString *isBack = params[@"isBack"];
    NSString *leftCallback = params[@"leftCallback"];
    NSString *rightText = params[@"rightText"];
    NSString *rightIcon = params[@"rightIcon"];
    NSString *rightCallback = params[@"rightCallback"];
    
    if (title)
    {
        self.title = title;
    }
    
    if (leftCallback) {
        self.leftBtnCallback = leftCallback;
    }
    
    if (rightCallback) {
        self.rightBtnCallBack = rightCallback;
    }
    
    if (([isBack isKindOfClass:[NSNumber class]] && [isBack boolValue]) || ([isBack isKindOfClass:[NSString class]] && [isBack isEqualToString:@"true"]))
    {
        [self showLeftBarButtonItemWithImage:@"icon_back"];
    }
    else
    {
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithCustomView:[UIView new]];
    }
    
    if (rightIcon && rightIcon.length > 0) {
        [self showRightBarButtonItemWithTitle:rightText orButtonImage:rightIcon titleColor:nil];
    }
    else if (rightText && rightText.length > 0) {
        UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:rightText
                                                                      style:UIBarButtonItemStyleDone
                                                                     target:self
                                                                     action:@selector(clickRightBarButton:)];
        [rightItem setTitleTextAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:14]} forState:UIControlStateNormal];
        self.navigationItem.rightBarButtonItem = rightItem;
    }
    else {
        self.navigationItem.rightBarButtonItem = nil;
    }
}

- (void)handler:(FJSHeaderHandler *)handler callBackJSHeaderRightWithParams:(NSDictionary *)params
{
    NSString *rightText = params[@"rightText"];
    NSString *rightIcon = params[@"rightIcon"];
    if (rightIcon && rightIcon.length > 0) {
        [self showRightBarButtonItemWithTitle:rightText orButtonImage:rightIcon titleColor:nil];
    }
    else if (rightText && rightText.length > 0) {
        UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:rightText
                                                                      style:UIBarButtonItemStyleDone
                                                                     target:self
                                                                     action:@selector(clickRightBarButton:)];
        [rightItem setTitleTextAttributes:@{NSFontAttributeName : [UIFont systemFontOfSize:14]} forState:UIControlStateNormal];
        self.navigationItem.rightBarButtonItem = rightItem;
    }
}

#pragma mark - FJSContractHandlerDelegate
- (void)handler:(FJSContractHandler *)handler callPreviewAttachment:(NSURL *)fileURL
{
    if ([QLPreviewController canPreviewItem:(id<QLPreviewItem>)fileURL]) {
        self.fileURL = fileURL;
        QLPreviewController *qlViewController = [[QLPreviewController alloc] init];
        qlViewController.view.frame = CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height - 64);
        qlViewController.delegate = self;
        qlViewController.dataSource = self;
        qlViewController.navigationController.navigationBar.userInteractionEnabled = YES;
        qlViewController.view.userInteractionEnabled = YES;
        qlViewController.navigationController.navigationBar.barTintColor = UIColorFromHex(0x00a0ea);
        
        self.previewNaviController = [[UINavigationController alloc] initWithRootViewController:qlViewController];
        self.previewNaviController.navigationBar.barTintColor = UIColorFromHex(0x00a0ea);
        [self.previewNaviController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
        UIBarButtonItem *backBtn = [UIBarButtonItem showLeftBarButtonItemWithTitle:nil orButtonImage:@"icon_back" target:self selector:@selector(previewControllerBackAction:)];
        qlViewController.navigationItem.leftBarButtonItem = backBtn;
        
        [EMHudManager hideLoadingForView:self.view];
        if (SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(@"10")) {
            [self presentViewController:self.previewNaviController animated:YES completion:nil];
        } else {
            [self.navigationController pushViewController:qlViewController animated:YES];
        }
    }
}

- (void)previewControllerBackAction:(id)sender
{
    [self.previewNaviController dismissViewControllerAnimated:YES completion:nil];
    self.previewNaviController = nil;
}

#pragma mark - EMScheduleHandler
- (void)handler:(EMScheduleHandler *)handler callBackLeader:(NSDictionary *)params
{
    [self.webView fjs_callBackEvaluateJavaScriptString:params];
}

- (void)refreshSchedules:(NSString *)date
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(callBackRefreshSchedules:)]) {
        [self.delegate callBackRefreshSchedules:date];
    }
}

#pragma mark - FJSMortgageHandlerDelegate
- (void)handler:(FJSMortgageHandler *)handler getPhoto:(NSDictionary *)params
{
    [self.webView fjs_callBackEvaluateJavaScriptString:params];
}

#pragma mark - QLPreviewController 代理方法
- (NSInteger)numberOfPreviewItemsInPreviewController:(QLPreviewController *)controller
{
    return 1;
}

- (id<QLPreviewItem>)previewController:(QLPreviewController *)controller previewItemAtIndex:(NSInteger)index{
    return self.fileURL;
}

#pragma mark - WKNavigationDelegate
- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation
{
    [EMHudManager hideLoadingForView:self.webView];
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error
{
    [EMHudManager hideLoadingForView:self.webView];
}

- (void)webViewWebContentProcessDidTerminate:(WKWebView *)webView
{
    [webView reload];
}
//-------------------------
#pragma mark - Strategy
- (void)handleEventWithName:(NSString *)eventName userInfo:(NSDictionary *)userInfo
{
    NSInvocation *invocation = self.eventStrategyMap[eventName];
    if (userInfo && userInfo.count > 0) {
        [invocation setArgument:&userInfo atIndex:2];
    }
    [invocation invoke];
}

//--------------------
- (NSInvocation *)invocationWithSelector:(SEL)sel
{
    NSMethodSignature *signature = [[self class] instanceMethodSignatureForSelector:sel];
    if (!signature) {
        return [[NSInvocation alloc] init];
    }
    
    NSInvocation *invocation = [NSInvocation invocationWithMethodSignature:signature];
    invocation.target = self;
    invocation.selector = sel;
    
    return invocation;
}

#pragma mark - Setter
- (void)setUrlString:(NSString *)urlString
{
    if ([urlString hasPrefix:@"http"] || [urlString hasPrefix:@"https"]) {
        _urlString = urlString;
    } else {
        _urlString = [[EMAppConfig sharedInstance] completeH5URLForPath:urlString];
    }
}

#pragma mark - Getter
- (WKWebView *)webView
{
    if (!_webView)
    {
        //WKWebView配置
        WKWebViewConfiguration *configuration = self.jsBridge.configuration;
        
        CGRect frame = CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 64);
        
        _webView = [[WKWebView alloc] initWithFrame:frame configuration:configuration];
        _webView.UIDelegate = self.jsBridge;
        _webView.navigationDelegate = self;
        _webView.scrollView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    }
    return _webView;
}

- (FJSJavaScriptBridge *)jsBridge
{
    if (!_jsBridge)
    {
        _jsBridge = [[FJSJavaScriptBridge alloc] init];
        _jsBridge.viewController = self;
    }
    return _jsBridge;
}

- (NSMutableDictionary *)moduleHandlers
{
    if (!_moduleHandlers)
    {
        _moduleHandlers = [NSMutableDictionary dictionary];
    }
    return _moduleHandlers;
}

- (NSMutableDictionary *)eventStrategyMap
{
    if (!_eventStrategyMap) {
        _eventStrategyMap = [NSMutableDictionary dictionary];
    }
    return _eventStrategyMap;
}

@end
