//
//  FJSJavaScriptBridge.h
//  FJSWebDemo
//
//  Created by xuyq on 2017/1/16.
//  Copyright © 2017年 xuyq. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <WebKit/WebKit.h>

@protocol FJSJavaScriptBridgeDelegate <NSObject>

@required
- (NSMutableDictionary *)moduleHandlers;

@end

@interface FJSJavaScriptBridge : NSObject<WKNavigationDelegate, WKUIDelegate>

@property (nonatomic, strong) WKWebViewConfiguration *configuration;
@property (nonatomic, weak) UIViewController<FJSJavaScriptBridgeDelegate> *viewController;

/**
 移除所有的ScriptMessageHandlers
 要在FJSJavaScriptBridge释放前调用本方法，不然FJSJavaScriptBridge会无法释放
 */
- (void)removeScriptMessageHandlers;

@end
