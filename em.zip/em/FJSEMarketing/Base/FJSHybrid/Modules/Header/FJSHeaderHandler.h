//
//  FJSFJSHeader.h
//  FJSWebDemo
//
//  Created by twistar on 2017/1/20.
//  Copyright © 2017年 xuyq. All rights reserved.
//

#import <Foundation/Foundation.h>


@class FJSHeaderHandler;

@protocol FJSHeaderHandlerDelegate <NSObject>

@optional
- (void)handler:(FJSHeaderHandler *)handler callBackJSHeaderWithParams:(NSDictionary *)params;

- (void)handler:(FJSHeaderHandler *)handler callBackJSHeaderRightWithParams:(NSDictionary *)params;

- (void)handler:(FJSHeaderHandler *)handler callBackJSStatusBarSwitchWithParams:(NSDictionary *)params;

@end

@interface FJSHeaderHandler : NSObject

@property (nonatomic, weak) id<FJSHeaderHandlerDelegate> delegate;
/**
 设置头部信息
 window.webkit.messageHandlers.Header.postMessage({"method":"setHeader","params":{"title": "头部标题","isBack": true,"leftCallback": "设置左边回调","rightText": "右边文案","rightIcon": "右边图标","rightCallback": "设置右边回调","data": "扩展数据"}})
 
 @param params  @{title: 头部标题 ,isBack: 是否有返回图标 ,leftCallback: 设置左边回调 ,rightText: 右边文案 ,rightIcon: 右边图标 ,rightCallback: 设置右边回调 ,data: 扩展数据}
 */
- (void)setHeader:(NSDictionary *)params;

- (void)setHeaderRight:(NSDictionary *)params;

- (void)statusBarSwitch:(NSDictionary *)params;

@end
