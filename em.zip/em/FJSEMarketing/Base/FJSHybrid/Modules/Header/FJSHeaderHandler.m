//
//  FJSFJSHeader.m
//  FJSWebDemo
//
//  Created by twistar on 2017/1/20.
//  Copyright © 2017年 xuyq. All rights reserved.
//

#import "FJSHeaderHandler.h"

@implementation FJSHeaderHandler

// @param params  @{title: 头部标题 ,isBack: 是否有返回图标 ,leftCallback: 设置左边回调 ,rightText: 右边文案 ,rightIcon: 右边图标 ,rightCallback: 设置右边回调 ,data: 扩展数据}
- (void)setHeader:(NSDictionary *)params
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callBackJSHeaderWithParams:)]) {
        [self.delegate handler:self callBackJSHeaderWithParams:params];
    }
}

- (void)statusBarSwitch:(NSDictionary *)params
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callBackJSStatusBarSwitchWithParams:)]) {
        [self.delegate handler:self callBackJSStatusBarSwitchWithParams:params];
    }
}

- (void)setHeaderRight:(NSDictionary *)params
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callBackJSHeaderRightWithParams:)]) {
        [self.delegate handler:self callBackJSHeaderRightWithParams:params];
    }
}

@end
