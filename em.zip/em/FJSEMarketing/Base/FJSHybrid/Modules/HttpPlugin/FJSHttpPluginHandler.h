//
//  FJSHttpPluginHandler.h
//  FJSWebDemo
//
//  Created by xuyq on 2017/1/19.
//  Copyright © 2017年 xuyq. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FJSHttpPluginHandler;

@protocol FJSHttpPluginDelegate <NSObject>

- (void)handler:(FJSHttpPluginHandler *)handler callHttpSuccess:(NSDictionary *)params;

- (void)handler:(FJSHttpPluginHandler *)handler callHttpFailed:(NSDictionary *)params;

@end

@interface FJSHttpPluginHandler : NSObject

@property (nonatomic, weak) id<FJSHttpPluginDelegate> delegate;

/**
 request
 
 options
 {
 url:http请求地址
 header:http请求头
 type: 请求方式，默认get
 data: json对象，请求入参
 success: 请求成功回调方法
 error: 请求失败回调方法
 }
 
  window.webkit.messageHandlers.HttpPlugin.postMessage({"method":"request","params":{"url":"http://www.fixsub.com", "header" : "", "type" : "get", "data" : "", "success" : "success", "error" : "error"}})
 */

- (void)request:(NSDictionary *)params;

@end
