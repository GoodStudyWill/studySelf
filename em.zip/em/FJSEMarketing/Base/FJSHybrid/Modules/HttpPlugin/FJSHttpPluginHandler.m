//
//  FJSHttpPluginHandler.m
//  FJSWebDemo
//
//  Created by xuyq on 2017/1/19.
//  Copyright © 2017年 xuyq. All rights reserved.
//

#import <FJSNetworking/FJSNetworking.h>
#import "FJSHttpPluginHandler.h"
#import "UIApplication+FJSExtension.h"
#import "FJSAlertView.h"
#import "EMLoginViewController.h"
#import "EMGesturePasswordViewController.h"
#import "EMUserManager.h"
#import "EMNotificationCenter.h"
#import "EMNetworkHelper.h"

@interface FJSHttpRequestApi : FJSApi

@property (nonatomic, copy) NSString *url;

@property (nonatomic, copy) NSDictionary *headers;

@property (nonatomic, copy) NSDictionary *params;

@property (nonatomic, copy) NSString *type;

@property (nonatomic, copy) NSString *successCallBack;

@property (nonatomic, copy) NSString *errorCallBack;
//flag，1是加密，0是不加密
@property (nonatomic, copy) NSString *flag;

@end

@implementation FJSHttpRequestApi

- (NSString *)requestUrl
{
    return self.url;
}

- (id)requestArgument
{
    return self.params;
}

- (FJSRequestMethod)requestMethod
{
    if ([[self.type lowercaseString] isEqualToString:@"post"]) {
        return FJSRequestMethodPOST;
    }else{
        return FJSRequestMethodGET;
    }
}

- (FJSRequestSerializerType)requestSerializerType
{
    return FJSRequestSerializerTypeJSON;
}

- (BOOL)encryptRequest
{
    return self.flag.boolValue;
}

@end

@interface FJSHttpPluginHandler ()<FJSRequestDelegate>

@property (nonatomic, assign) BOOL showFailedAlert;

@end

@implementation FJSHttpPluginHandler

- (instancetype)init
{
    self = [super init];
    if (self) {
        _showFailedAlert = NO;
    }
    return self;
}

-(void)request:(NSDictionary *)params{
    NSString *url = params[@"url"];
    NSString *headers = params[@"header"];
    NSString *type = params[@"type"];
    NSString *data = params[@"data"];
    NSString *successCallBack = params[@"success"];
    NSString *errorCallBack = params[@"error"];
    NSString *flag = params[@"flag"];
    
    FJSHttpRequestApi *request = [[FJSHttpRequestApi alloc]init];
    request.delegate = self;
//    request.headers = headers;
    request.successCallBack = successCallBack;
    request.errorCallBack = errorCallBack;
    request.type = type;
    request.flag = flag;
    NSDictionary *paramDict = nil;
    if (request.requestMethod == FJSRequestMethodPOST) {
        if (data.length) {
            NSError *error;
            NSData *jsonData = [data dataUsingEncoding:NSUTF8StringEncoding];
            paramDict = [NSJSONSerialization JSONObjectWithData:jsonData
                                                                     options:NSJSONReadingMutableContainers
                                                                       error:&error];
            
        }
    }else{
        if (data.length){
            //            token值为空的问题
            /* 暂时不检查Token
            NSArray *arr = [data componentsSeparatedByString:@"&"];
            for (NSString *str in arr) {
                if ([str hasPrefix:@"token="] && str.length < 7) {
                    [self fjs_callBackFail:request.errorCallBack params:@{}];
                    return;
                }
            }
            */
            if ([url rangeOfString:@"?"].location == NSNotFound){
                url = [url stringByAppendingString:@"?"];
            }else if (![url hasSuffix:@"&"]){
                url = [url stringByAppendingString:@"&"];
            }
            url = [url stringByAppendingString:data];
        }
        //get 请求 对 + 号的处理
        url = [url stringByReplacingOccurrencesOfString:@"+" withString:@"%2B"];
    }
    request.url = url;
    //添加请求头
    if (![headers isEqualToString:@""] && headers != nil ) {
        NSData *data = [headers dataUsingEncoding:NSUTF8StringEncoding];
        NSDictionary *headersDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableLeaves error:nil];
        request.headers = headersDic;
    }
    request.params = paramDict;
    NSLog(@"url = %@, paramDict = %@", url, paramDict);
    [request start];
}

- (void)apiRequestDidSuccess:(__kindof FJSHttpRequestApi *)request
{
    FJSLog(@"apiRequestDidSuccess response => %@", request.responseString);
    NSDictionary *responseDict = request.responseObject;
    NSInteger flag = [responseDict[@"flag"] integerValue];
    NSString *msg = responseDict[@"msg"];
    
    if (flag == 1 || flag == 11) {
        [self fjs_callBackSuccess:request.successCallBack params:request.responseObject?:@{}];
    }
    else if(flag == 0 || flag == 9) {
        if (self.showFailedAlert) {
            //保证登录失败弹框唯一性
            return;
        }
        
        self.showFailedAlert = YES;
        
        [EMNetworkHelper tokenTimeOutWithMessage:msg];
    }
    else {
        [self fjs_callBackSuccess:request.successCallBack params:request.responseObject?:@{}];
    }
}

- (void)apiRequestDidFail:(__kindof FJSHttpRequestApi *)request
{
    FJSLog(@"apiRequestDidFail response => %@", request.responseString);
    
    if (request.response) {
        NSDictionary *params = @{@"errorCode" : [NSString stringWithFormat:@"%ld", request.error.code]};
        [self fjs_callBackFail:request.errorCallBack params:params];
    } else {
        if (_showFailedAlert) {
            //保证登录失败弹框唯一性
            return;
        }
        
        _showFailedAlert = YES;
        FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:@"提示" detail:@"网络连接异常" buttonTitle:@"确定" completionBlock:^{
            _showFailedAlert = NO;
        }];
        [alertView show];
        if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callHttpFailed:)]) {
            [self.delegate handler:self callHttpFailed:nil];
        }
    }
}

#pragma mark -
#pragma mark - private method callBack

- (void)fjs_callBackSuccess:(NSString *)callBack params:(NSDictionary *)params{
    NSMutableDictionary *callbackDict = [NSMutableDictionary new];
    [callbackDict setObject:params forKey:@"params"];
    [callbackDict setObject:callBack forKey:@"callback"];
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callHttpSuccess:)]) {
        [self.delegate handler:self callHttpSuccess:callbackDict];
    }
}

- (void)fjs_callBackFail:(NSString *)callBack params:(NSDictionary *)params{
    NSMutableDictionary *callbackDict = [NSMutableDictionary new];
    [callbackDict setObject:params forKey:@"params"];
    [callbackDict setObject:callBack forKey:@"callback"];
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callHttpFailed:)]) {
        [self.delegate handler:self callHttpFailed:callbackDict];
    }
}

@end
