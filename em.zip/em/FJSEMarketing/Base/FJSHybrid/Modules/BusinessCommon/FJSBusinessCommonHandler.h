//
//  FJSBusinessCommonHandler.h
//  FJSWebDemo
//
//  Created by xuyq on 2017/1/17.
//  Copyright © 2017年 xuyq. All rights reserved.
//

/*
 loadingBegin
 
 组件：BusinessCommon
 描述：显示加载动画
 入参：
 options
 {
 msg: 当不允许取消加载动画时 提示的信息
 }
 loadingFinish
 
 组件：BusinessCommon
 描述：关闭加载动画
 tip
 
 组件：BusinessCommon
 描述：Native toast弹窗提示
 入参：
 options
 {
 text: 提示文案
 }
 getDeviceId
 
 组件：BusinessCommon
 描述：设备ID，使用TalkingData的方式获取
 入参：
 {
 callback: 回调方法
 }
 getDeviceInfo
 
 组件：BusinessCommon
 描述：获取手机信息 如手机版本 厂商 MAC等
 入参：
 options
 {
 callback: 回调方法
 }
 log
 
 组件：BusinessCommon
 描述：本地打印日志
 入参：
 options
 {
 text: 日志内容
 }
 TDOnEven
 
 组件：BusinessCommon
 描述：记录TalkingData
 入参：
 options
 {
 eventId:模块ID
 eventLabel:
 jsonData:
 }
 */


#import "FJSBaseHandler.h"

@class FJSBusinessCommonHandler;

@protocol FJSBusinessCommonDelegate <NSObject>

@optional

- (void)handler:(FJSBusinessCommonHandler *)handler callTip:(NSString *)text;

- (void)handler:(FJSBusinessCommonHandler *)handler callCallBackJSWithParams:(NSDictionary *)params;

- (void)loadingBegin:(FJSBusinessCommonHandler *)handler;

- (void)loadingFinish:(FJSBusinessCommonHandler *)handler;

@end

@interface FJSBusinessCommonHandler : FJSBaseHandler

@property (nonatomic, weak) id<FJSBusinessCommonDelegate> delegate;

#pragma mark - H5 API

/**
 显示加载动画
 window.webkit.messageHandlers.BusinessCommon.postMessage({"method":"loadingBegin","params":{"text":"当不允许取消加载动画时 提示的信息"}})
 
 @param params @{ msg: @"当不允许取消加载动画时 提示的信息" }
 */
- (void)loadingBegin:(NSDictionary *)params;

/**
 关闭加载动画
 window.webkit.messageHandlers.BusinessCommon.postMessage({"method":"loadingFinish"})
 
 */
- (void)loadingFinish;
- (void)loadingFinish:(NSDictionary *)params;

/**
 Native toast弹窗提示
 window.webkit.messageHandlers.BusinessCommon.postMessage({"method":"tip","params":{"text":"abc"}})

 @param params @{text: @"提示文案"}
 */
- (void)tip:(NSDictionary *)params;

/**
 设备ID，使用TalkingData的方式获取
 window.webkit.messageHandlers.BusinessCommon.postMessage({"method":"getDeviceId","params":{"callback":"getDeviceId_0"}})

 @param params callback: 回调方法
 */
- (void)getDeviceId:(NSDictionary *)params;

/**
 获取手机信息 如手机版本 厂商 MAC等
 window.webkit.messageHandlers.BusinessCommon.postMessage({"method":"getDeviceInfo","params":{"callback":"getDeviceInfo_0"}})
 
 @param params callback: 回调方法
 */
- (void)getDeviceInfo:(NSDictionary *)params;

/**
 本地打印日志
 window.webkit.messageHandlers.BusinessCommon.postMessage({"method":"log","params":{"text":"本地打印日志"}})
 
 @param params text: 日志内容
 */
- (void)log:(NSDictionary *)params;

/**
 记录TalkingData

 @param params @{ eventId:模块ID eventLabel:事件名 jsonData:Json数据 }
 */
- (void)TDOnEven:(NSDictionary *)params;

/**
 RSA加密或者解密
 window.webkit.messageHandlers.BusinessCommon.postMessage({"method":"rsaByNative","params":{"param":"","type":"1","callback":"rsaByNative_0"}})
 
 @param params param:从传递给Native的参数 type：1加密，2解密 callback:回调
 */
- (void)rsaByNative:(NSDictionary *)params;

- (void)showDialog:(NSDictionary *)params;

- (void)showScheduleSubmit:(NSDictionary *)params;


@end
