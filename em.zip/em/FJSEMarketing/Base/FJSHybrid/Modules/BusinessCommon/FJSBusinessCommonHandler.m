//
//  FJSBusinessCommonHandler.m
//  FJSWebDemo
//
//  Created by xuyq on 2017/1/17.
//  Copyright © 2017年 xuyq. All rights reserved.
//

#import "FJSBusinessCommonHandler.h"
#import "EMAppConfig.h"
#import "NSDictionary+FJSJavaScript.h"
#import "NSString+FJSExtension.h"
#import "FJSAlertView.h"
#import "EMNetworkHelper.h"
#import "EMOperateScheduleApi.h"
#import "EMScheduleAlertView.h"
#import "EMScheduleModel.h"
#import "EMNotificationCenter.h"

@interface FJSBusinessCommonHandler ()<FJSRequestDelegate>

@end

@implementation FJSBusinessCommonHandler

#pragma mark - Life Cycle
- (void)dealloc
{
    FJSLog();
}
    
- (NSDictionary *)eventMap
{
    return @{
             @"loadingBegin" : @"loadingBegin",
             @"loadingFinish" : @"loadingFinish",
             };
}

#pragma mark - API
/**
 显示加载动画
 
 @param params @{ msg: 当不允许取消加载动画时 提示的信息 }
 */
- (void)loadingBegin:(NSDictionary *)params
{
//    if (self.delegate && [self.delegate respondsToSelector:@selector(loadingBegin:)]) {
//        [self.delegate loadingBegin:self];
//    }
    
    [self webServiceHandleEventWithName:@"loadingBegin" userInfo:nil];
}


- (void)webServiceHandleEventWithName:(NSString *)name userInfo:(NSDictionary *)userInfo
{
    if (self.webService && [self.webService respondsToSelector:@selector(handleEventWithName:userInfo:)]) {
        [self.webService handleEventWithName:name userInfo:userInfo];
    }
}
/**
 关闭加载动画
 */
- (void)loadingFinish
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(loadingFinish:)]) {
        [self.delegate loadingFinish:self];
    }
}

- (void)loadingFinish:(NSDictionary *)params
{
//    if (self.delegate && [self.delegate respondsToSelector:@selector(loadingFinish:)]) {
//        [self.delegate loadingFinish:self];
//    }
    if (self.webService && [self.webService respondsToSelector:@selector(handleEventWithName:userInfo:)]) {
       [self.webService handleEventWithName:@"loadingFinish" userInfo:params];
    }
}

/**
 Native toast弹窗提示
 
 @param params @{ text: 提示文案 }
 */
- (void)tip:(NSDictionary *)params
{
    FJSLog(@"tip=>%@", params);
    
    id text = params[@"text"];
    if ([text isKindOfClass:[NSDictionary class]]) {
        text = [NSString stringWithFormat:@"%@", params[@"text"]];
    }
    
//    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callTip:)]) {
//        [self.delegate handler:self callTip:text];
//    }
}

/**
 设备ID，使用TalkingData的方式获取
 
 @param params callback: 回调方法
 */
- (void)getDeviceId:(NSDictionary *)params
{
    NSDictionary *callBackParams = @{@"DeviceId" : @"386453dcad2d534dbb04361d146104d47"};
    NSMutableDictionary *callBackDic = [params mutableCopy];
    [callBackDic setObject:callBackParams forKey:@"params"];
    
    if ([self.delegate respondsToSelector:@selector(handler:callCallBackJSWithParams:)]) {
        [self.delegate handler:self callCallBackJSWithParams:callBackDic];
    }
}

/**
 获取手机信息 如手机版本 厂商 MAC等
 
 @param params callback: 回调方法
 */
- (void)getDeviceInfo:(NSDictionary *)params
{
    NSString * deviceName = [[UIDevice currentDevice] name]; // 设备名称
    NSString * deviceSystemName = [[UIDevice currentDevice] systemName]; // 系统名称
    NSString * deviceVersion = [[UIDevice currentDevice] systemVersion]; // 系统版本号
    NSString * deviceModel = [[UIDevice currentDevice] model];  // 设备模式
    NSString * deviceUUID = [[UIDevice currentDevice] identifierForVendor].UUIDString;
    NSDictionary * callBackParams = @{@"name"       : deviceName,
                                      @"systemName" : deviceSystemName,
                                      @"version"    : deviceVersion,
                                      @"model"      : deviceModel,
                                      @"UUID"       : deviceUUID};
    NSMutableDictionary *callBackDic = [params mutableCopy];
    [callBackDic setObject:callBackParams forKey:@"params"];
    
    if ([self.delegate respondsToSelector:@selector(handler:callCallBackJSWithParams:)]) {
        [self.delegate handler:self callCallBackJSWithParams:callBackDic];
    }
}

/**
 本地打印日志
 
 @param params text: 日志内容
 */
- (void)log:(NSDictionary *)params
{
    FJSLog(@"%@", params[@"text"]);
}

/**
 记录TalkingData
 
 @param params @{ eventId:模块ID eventLabel:事件名 jsonData:Json数据 }
 */
- (void)TDOnEven:(NSDictionary *)params
{
//    NSDictionary *dic = [params[@"jsonData"] uxy_JSONObject];
//    [TalkingData trackEvent:params[@"eventId"] label:params[@"eventLabel"] parameters:dic];
}

- (void)rsaByNative:(NSDictionary *)params
{
    NSString *param = params[@"param"];
    NSString *type = params[@"type"];
    NSDictionary *paramDict = [param fjs_JSONDictionary];
    
    //type:1加密，2解密
    NSMutableDictionary *dataDic = [NSMutableDictionary dictionary];
    if ([type isEqualToString:@"1"]) {
        for (NSString *key in paramDict.allKeys) {
            NSString *ret = [[paramDict objectForKey:key] fjs_RSAEncrypt];
            [dataDic setObject:ret forKey:key];
        }
    } else if ([type isEqualToString:@"2"]) {
        
    }
    
    NSDictionary *callBackDict = [params mutableCopy];
    [callBackDict setValue:dataDic forKey:@"params"];
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callCallBackJSWithParams:)]) {
        [self.delegate handler:self callCallBackJSWithParams:callBackDict];
    }
}

- (void)showDialog:(NSDictionary *)params
{
    NSString *leftTitle = params[@"cancle"];
    NSString *rightTitle = params[@"sure"];
    NSString *context = params[@"context"];
    NSString *title = params[@"title"];
    NSString *leftCallBack = params[@"cancleCallback"];
    NSString *rightCallBack = params[@"sureCallback"];
    NSString *type = params[@"type"];
    
    FJSAlertView *alertView = nil;
    __weak FJSBusinessCommonHandler *weakSelf = self;
    if ([type isEqualToString:@"two"]) {
        alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:title detail:context leftTitle:leftTitle rightTitle:rightTitle leftButtonBlock:^{
            NSMutableDictionary *callBackDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:leftCallBack, @"callback", nil];
            if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(handler:callCallBackJSWithParams:)]) {
                [weakSelf.delegate handler:weakSelf callCallBackJSWithParams:callBackDict];
            }
        } rightButtonBlock:^{
            NSMutableDictionary *callBackDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:rightCallBack, @"callback", nil];
            if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(handler:callCallBackJSWithParams:)]) {
                [weakSelf.delegate handler:weakSelf callCallBackJSWithParams:callBackDict];
            }
        }];
    } else {
        alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeWarning title:title detail:context buttonTitle:rightTitle completionBlock:^{
            NSMutableDictionary *callBackDict = [NSMutableDictionary dictionaryWithObjectsAndKeys:rightCallBack, @"callback", nil];
            if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(handler:callCallBackJSWithParams:)]) {
                [weakSelf.delegate handler:weakSelf callCallBackJSWithParams:callBackDict];
            }
        }];
    }
    
    [alertView show];
}

- (void)tokenTimeOut:(NSDictionary *)params
{
    NSString *msg = params[@"msg"];
    
    [EMNetworkHelper tokenTimeOutWithMessage:msg];
    
}

- (void)showScheduleSubmit:(NSDictionary *)params
{
    NSString *scheduleID = params[@"scheduleId"];
    NSString *type = params[@"operateType"];
    NSString *scheduleRemark = params[@"remark"];
    NSString *callback = params[@"callback"];
    
    __weak typeof(&*self) weakSelf = self;
    EMScheduleAlertView *alertView = [EMScheduleAlertView alertViewWithOperateType:type remark:scheduleRemark completionBlock:^(NSString *operateType, NSString *remark, NSString *status) {
        EMOperateScheduleApi *api = [[EMOperateScheduleApi alloc] initWithScheduleID:scheduleID operateType:operateType status:status remark:remark];
        api.callback = callback;
        api.delegate = weakSelf;
        [api start];
    }];
    [alertView show];
}

#pragma mark - FJSRequestDelegate
- (void)apiRequestDidSuccess:(__kindof FJSBaseApi *)request
{
    FJSLog(@"EMOperateScheduleApi=>%@", request.responseJSONObject);
    FJSLog(@"msg=>%@", request.responseJSONObject[@"msg"]);
    NSString *flag = request.responseJSONObject[@"flag"];
    if ([flag isEqualToString:@"1"]) {
        EMOperateScheduleApi *api = (EMOperateScheduleApi *)request;
        EMScheduleModel *schedule = [EMScheduleModel retrieveByPrimaryKey:api.scheduleID];
        if (schedule) {
            schedule.status = api.status;
            schedule.remark = api.remark;
            [schedule createOrUpdate];
            [[EMNotificationCenter sharedInstance] setOrUpdateLocalNotificationWithSchedule:schedule];
            dispatch_async(dispatch_get_main_queue(), ^{
                [[NSNotificationCenter defaultCenter] postNotificationName:@"refreshSchedule" object:schedule.date];
            });
        }
        
        if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callCallBackJSWithParams:)]) {
            NSDictionary *callBackParams = @{@"callback" : [api.callback copy]};
            [self.delegate handler:self callCallBackJSWithParams:callBackParams];
        }
    } else {
        NSString *msg = request.responseJSONObject[@"msg"];
        [EMHudManager showText:msg];
    }
}

- (void)apiRequestDidFail:(__kindof FJSBaseApi *)request
{
    [EMHudManager showText:@"网络连接异常"];
}

@end
