//
//  FJSBaseHandler.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/11/28.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSBaseHandler.h"

@implementation FJSBaseHandler

- (NSDictionary *)eventMap
{
    return @{};
}

@end
