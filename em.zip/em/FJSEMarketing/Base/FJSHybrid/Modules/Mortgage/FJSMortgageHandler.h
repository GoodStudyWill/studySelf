//
//  FJSMortgageHandler.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/10/1.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FJSMortgageHandler;

@protocol FJSMortgageHandlerDelegate <NSObject>

@optional

- (void)handler:(FJSMortgageHandler *)handler getPhoto:(NSDictionary *)params;

@end

@interface FJSMortgageHandler : NSObject

@property (nonatomic, weak) id<FJSMortgageHandlerDelegate> delegate;

/**
 Native APP的token延期

 @param params params
 */
- (void)appTokenOvertime:(NSDictionary *)params;

/**
 获取图片

 @param params  params
 */
- (void)getPhoto:(NSDictionary *)params;


@end
