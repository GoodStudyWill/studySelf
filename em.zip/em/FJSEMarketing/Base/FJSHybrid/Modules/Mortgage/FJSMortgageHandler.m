//
//  FJSMortgageHandler.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/10/1.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <AssetsLibrary/AssetsLibrary.h>
#import "FJSMortgageHandler.h"
#import "EMTokenOvertimeApi.h"
#import "UIApplication+FJSExtension.h"
#import "UIImage+FJSExtension.h"
#import "RITLPhotos.h"
#import "FJSAlertView.h"

@interface FJSMortgageHandler ()<UIImagePickerControllerDelegate, UINavigationControllerDelegate>

@property (nonatomic, copy) NSString *count;

@property (nonatomic, copy) NSString *callback;

@end

@implementation FJSMortgageHandler

- (void)appTokenOvertime:(NSDictionary *)params
{
    EMTokenOvertimeApi *tokenOvertimeApi = [EMTokenOvertimeApi new];
    [tokenOvertimeApi start];
}

- (void)getPhoto:(NSDictionary *)params
{
    self.count = params[@"count"];
    self.callback = params[@"callback"];
    
    __weak typeof (self) weakSelf = self;
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
        
    }];
    UIAlertAction *takePhotoAction = [UIAlertAction actionWithTitle:@"拍照" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        FJSLog(@"takePhoto...");
        __strong typeof(self) strongSelf = weakSelf;
        [strongSelf handleTakePhotoAction];
    }];
    UIAlertAction *photoLibraryAction = [UIAlertAction actionWithTitle:@"在相册中选择" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        FJSLog(@"photoLibrary...");
        __strong typeof(self) strongSelf = weakSelf;
        [strongSelf handlePhotoLibraryAction];
    }];
    
    [alertController addAction:cancelAction];
    [alertController addAction:takePhotoAction];
    [alertController addAction:photoLibraryAction];
    
    [[UIApplication fjs_currentViewController] presentViewController:alertController animated:YES completion:^{
        
    }];
    
}

- (void)handleTakePhotoAction
{
    //判断是否有摄像头
    BOOL isHasCamera = [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera];
    if (!isHasCamera) {
        FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeFailed title:@"打开相机失败" detail:@"未找到拍照设备"  buttonTitle:@"确定" completionBlock:^{
            
        }];
        [alertView show];
        return;
    }
    
    //判断相机权限
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeVideo];
    BOOL notSupportCamera = authStatus == AVAuthorizationStatusDenied ||authStatus == AVAuthorizationStatusRestricted;
    if (notSupportCamera) {
        FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeFailed title:@"打开相机失败" detail:@"请点击<确定>按钮前往系统设置打开相机权限" leftTitle:@"取消" rightTitle:@"确定" leftButtonBlock:nil rightButtonBlock:^{
            NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
            if ([[UIApplication sharedApplication] canOpenURL:url]) {
                [[UIApplication sharedApplication] openURL:url];
            }
        }];
        [alertView show];
        return;
    }
    
    UIImagePickerController *pickerController = [UIImagePickerController new];
    pickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
    pickerController.delegate = self;
    [[UIApplication fjs_currentViewController] presentViewController:pickerController animated:YES completion:nil];
}

- (void)handlePhotoLibraryAction
{
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    BOOL notSupportPhotoLibrary = status == PHAuthorizationStatusRestricted || status == PHAuthorizationStatusDenied;
    if (notSupportPhotoLibrary) {
        FJSAlertView *alertView = [[FJSAlertView alloc] initWithType:FJSAlertViewTypeFailed title:@"打开相册失败" detail:@"请点击<确定>按钮前往系统设置打开照片权限" leftTitle:@"取消" rightTitle:@"确定" leftButtonBlock:nil rightButtonBlock:^{
            NSURL *url = [NSURL URLWithString:UIApplicationOpenSettingsURLString];
            if ([[UIApplication sharedApplication] canOpenURL:url]) {
                [[UIApplication sharedApplication] openURL:url];
            }
        }];
        [alertView show];
        return;
    }
    
    RITLPhotoNavigationViewModel *viewModel = [RITLPhotoNavigationViewModel new];
    viewModel.maxNumberOfSelectedPhoto = self.count.integerValue;

    __weak typeof (self) weakSelf = self;
    viewModel.RITLBridgeGetImageBlock = ^(NSArray<UIImage *> * images) {
        NSMutableDictionary *callBackDict = [NSMutableDictionary dictionary];
        NSString *callBackStr = [weakSelf.callback copy];
        [callBackDict setObject:callBackStr forKey:@"callback"];
        weakSelf.callback = nil;
        weakSelf.count = nil;

        NSString *codeStr = @"1";
        NSString *msg = @"成功";
        NSMutableArray *imageDataArray = [NSMutableArray arrayWithCapacity:images.count];
        for (UIImage *image in images) {
            NSData *imageData = UIImageJPEGRepresentation(image, 0.8);
            NSString *encodeImageData = [imageData base64EncodedStringWithOptions:0];
            NSString *imageDataStr = [NSString stringWithFormat:@"data:image/jpeg;base64,%@", encodeImageData];
            imageData = nil;
            encodeImageData = nil;

            NSInteger time = [[NSDate date] timeIntervalSince1970];
            NSDictionary *imageDict =  @{
                                         @"imgBase64" : imageDataStr,
                                         @"imgName"   : [NSString stringWithFormat:@"PJL%ld.jpg", time],
                                         };
            [imageDataArray addObject:imageDict];
        }

        NSMutableDictionary *callBackParams = [NSMutableDictionary dictionary];
        [callBackParams setObject:codeStr forKey:@"code"];
        [callBackParams setObject:@{@"image" : imageDataArray} forKey:@"data"];
        [callBackParams setObject:msg forKey:@"msg"];

        [callBackDict setObject:callBackParams forKey:@"params"];
        if (weakSelf.delegate && [weakSelf.delegate respondsToSelector:@selector(handler:getPhoto:)]) {
            [weakSelf.delegate handler:weakSelf getPhoto:callBackDict];
        }
    };
    
    RITLPhotoNavigationViewController * viewController = [RITLPhotoNavigationViewController photosViewModelInstance:viewModel];
    
    [[UIApplication fjs_currentViewController] presentViewController:viewController animated:true completion:^{}];
}

- (CGFloat)qualityForImageSize:(NSUInteger)size
{
    CGFloat quality = 1;
    if (size > 50000) {
        if (size < 100000 && size > 50000) {
            quality = 0.9;
        } else if (size < 500000 && size > 100000) {
            quality = 0.8;
        } else if (size < 1000000 && size > 500000) {
            quality = 0.7;
        } else if (size < 2000000 && size > 1000000) {
            quality = 0.5;
        } else if (size < 5000000 && size > 2000000) {
            quality = 0.25;
        } else {
            quality = 0.15;
        }
    }
    return quality;
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    __block UIImage *image = info[UIImagePickerControllerEditedImage];
    if (!image) {
        image = info[UIImagePickerControllerOriginalImage];
    }
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSData *imageData = UIImageJPEGRepresentation(image, 0.4);
            NSString *encodeImageData = [imageData base64EncodedStringWithOptions:0];
            NSString *imageDataStr = [NSString stringWithFormat:@"data:image/jpeg;base64,%@", encodeImageData];
            image = nil;
            
            NSMutableDictionary *callBackDict = [NSMutableDictionary dictionary];
            NSString *callBackStr = [self.callback copy];
            [callBackDict setObject:callBackStr forKey:@"callback"];
            self.callback = nil;
            
            NSString *codeStr = @"1";
            NSString *msg = @"成功";
            NSInteger time = [[NSDate date] timeIntervalSince1970];
            NSArray *imageDataArray = @[@{
                                       @"imgBase64" : imageDataStr,
                                       @"imgName"   : [NSString stringWithFormat:@"PJL%ld.jpg", time],
                                       }];
            
            NSMutableDictionary *callBackParams = [NSMutableDictionary dictionary];
            [callBackParams setObject:codeStr forKey:@"code"];
            [callBackParams setObject:@{@"image" : imageDataArray} forKey:@"data"];
            [callBackParams setObject:msg forKey:@"msg"];
            
            [callBackDict setObject:callBackParams forKey:@"params"];
            dispatch_async(dispatch_get_main_queue(), ^{
                if (self.delegate && [self.delegate respondsToSelector:@selector(handler:getPhoto:)]) {
                    [self.delegate handler:self getPhoto:callBackDict];
                }
            });
        });
        
        [[UIApplication fjs_currentViewController] dismissViewControllerAnimated:YES completion:nil];
        
    }
}

@end
