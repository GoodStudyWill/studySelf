//
//  FJSBusinessJumpHandler.h
//  FJSWebDemo
//
//  Created by xuyq on 2017/1/17.
//  Copyright © 2017年 xuyq. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FJSBusinessJumpHandler;

@protocol FJSBusinessJumpDelegate <NSObject>

@optional

- (void)handler:(FJSBusinessJumpHandler *)handler callForwardToNewPageWithParams:(NSDictionary *)params;

- (void)handler:(FJSBusinessJumpHandler *)handler callForwardInCurPageWithParams:(NSDictionary *)params;

- (void)handler:(FJSBusinessJumpHandler *)handler callForwardModuleWithParams:(NSDictionary *)params;

- (void)handler:(FJSBusinessJumpHandler *)handler callBackJSStringWithParams:(NSDictionary *)params;

@end

@interface FJSBusinessJumpHandler : NSObject

@property (nonatomic, weak) id<FJSBusinessJumpDelegate> delegate;


/**
 window.webkit.messageHandlers.BusinessJump.postMessage({"method":"forwardToNewPage","params":{"url":"index.html#/my","callback":"callback"}})
 
 @param params 参数
 */
- (void)forwardToNewPage:(NSDictionary *)params;


/**
 window.webkit.messageHandlers.BusinessJump.postMessage({"method":"forwardInCurPage","params":{"url":"https://www.baidu.com/","title":"abc","callback":"callback"}})
 
 @param params 参数
 */
- (void)forwardInCurPage:(NSDictionary *)params;

/**
 window.webkit.messageHandlers.BusinessJump.postMessage({"method":"forwardModule","params":{"url":"index.html","moduleName":"home","callback":"forwardModule_2","data":""}})
 
 @param params 参数
 */
- (void)forwardModule:(NSDictionary *)params;

/**
 window.webkit.messageHandlers.BusinessJump.postMessage({"method":"back","params":{"url":"https://www.baidu.com/","data":{"text":"abc"},"callback":"callback"}})

 @param params 参数
 */
- (void)back:(NSDictionary *)params;

@end
