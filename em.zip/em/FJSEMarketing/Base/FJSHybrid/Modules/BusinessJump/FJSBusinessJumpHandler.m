//
//  FJSBusinessJumpHandler.m
//  FJSWebDemo
//
//  Created by xuyq on 2017/1/17.
//  Copyright © 2017年 xuyq. All rights reserved.
//

#import "FJSBusinessJumpHandler.h"

@implementation FJSBusinessJumpHandler

#pragma mark - Life Cycle
- (void)dealloc
{
    NSLog(@"%@ dealloc...", self.class);
}

#pragma mark - API
- (void)forwardToNewPage:(NSDictionary *)params
{
    if ([self.delegate respondsToSelector:@selector(handler:callForwardToNewPageWithParams:)]) {
        [self.delegate handler:self callForwardToNewPageWithParams:params];
    }
}

- (void)forwardInCurPage:(NSDictionary *)params{
    if ([self.delegate respondsToSelector:@selector(handler:callForwardInCurPageWithParams:)]) {
        [self.delegate handler:self callForwardInCurPageWithParams:params];
    }
}

- (void)forwardModule:(NSDictionary *)params{
    if ([self.delegate respondsToSelector:@selector(handler:callForwardModuleWithParams:)]) {
        [self.delegate handler:self callForwardModuleWithParams:params];
    }
}

- (void)back:(NSDictionary *)params
{
    if ([self.delegate respondsToSelector:@selector(handler:callBackJSStringWithParams:)]) {
        [self.delegate handler:self callBackJSStringWithParams:params];
    }
}

@end
