//
//  FJSCommonHandler.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/14.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSCommonHandler.h"

@implementation FJSCommonHandler

- (void)setPlanOnBack:(NSDictionary *)params
{
    if ([self.delegate respondsToSelector:@selector(handler:callBackToRootJSStringWithParams:)]) {
        [self.delegate handler:self callBackToRootJSStringWithParams:params];
    }
}

@end
