//
//  FJSCommonHandler.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/14.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FJSCommonHandler;

@protocol FJSCommonHandlerDelegate <NSObject>

- (void)handler:(FJSCommonHandler *)handler callBackToRootJSStringWithParams:(NSDictionary *)params;

@end

@interface FJSCommonHandler : NSObject

@property (nonatomic, weak) id<FJSCommonHandlerDelegate> delegate;

- (void)setPlanOnBack:(NSDictionary *)params;

@end
