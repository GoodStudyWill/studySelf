//
//  FJSPickerHandler.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/3.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FJSDatePicker.h"

@class FJSPickerHandler;

@protocol FJSPickerHandlerDelegate <NSObject>

- (void)handler:(FJSPickerHandler *)handler callShowPickerViewInMode:(FJSDatePickerMode)mode withParams:(NSDictionary *)params;

- (void)handler:(FJSPickerHandler *)handler callAddressPickerWithParams:(NSDictionary *)params;

- (void)handler:(FJSPickerHandler *)handler callSinglePickerWithParams:(NSDictionary *)params;

@end

@interface FJSPickerHandler : NSObject

@property (nonatomic, weak) id<FJSPickerHandlerDelegate> delegate;


#pragma mark - TimePicker

/**
 时间选择器选择器，返回格式为“yyyy-MM-dd"

 @param params title 选择器标题, callback 回调方法
 */
- (void)showDatePicker:(NSDictionary *)params;

/**
 时间选择器选择器，返回格式为“yyyy-MM"
 
 @param params title 选择器标题, callback 回调方法
 */
- (void)showyyyyMM:(NSDictionary *)params;

/**
 时间选择器选择器，返回格式为“yyyy-MM-dd HH:mm"

 @param params title 选择器标题, callback 回调方法
 */
- (void)showyyyyMMddHHmm:(NSDictionary *)params;

#pragma mark - AddressPicker
- (void)showAreaView:(NSDictionary *)params;

#pragma mark - GeneralPicker

- (void)showSinglePicker:(NSDictionary *)params;


@end
