//
//  FJSPickerHandler.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/3.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSPickerHandler.h"
#import "FJSDatePicker.h"

@interface FJSPickerHandler ()<FJSDatePickerDelegate>

@end

@implementation FJSPickerHandler

- (void)showDatePicker:(NSDictionary *)params
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callShowPickerViewInMode:withParams:)]) {
        [self.delegate handler:self callShowPickerViewInMode:FJSDatePickerModeDate withParams:params];
    }
}

- (void)showyyyyMM:(NSDictionary *)params
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callShowPickerViewInMode:withParams:)]) {
        [self.delegate handler:self callShowPickerViewInMode:FJSDatePickerModeDateWithoutDay withParams:params];
    }
}

- (void)showyyyyMMddHHmm:(NSDictionary *)params
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callShowPickerViewInMode:withParams:)]) {
        [self.delegate handler:self callShowPickerViewInMode:FJSDatePickerModeDateTime withParams:params];
    }
}

- (void)showAreaView:(NSDictionary *)params
{
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callAddressPickerWithParams:)]) {
        [self.delegate handler:self callAddressPickerWithParams:params];
    }
}

- (void)showSinglePicker:(NSDictionary *)params
{
//    NSArray *data = params[@"data"];
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callSinglePickerWithParams:)]) {
        [self.delegate handler:self callSinglePickerWithParams:params];
    }
}

@end
