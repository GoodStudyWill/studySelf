//
//  FJSBaseHandler.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/11/28.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol FJSWebService <NSObject>

@required

- (void)handleEventWithName:(NSString *)eventName userInfo:(NSDictionary *)userInfo;

@end

@interface FJSBaseHandler : NSObject

@property (nonatomic, strong, readonly) NSDictionary *eventMap;

@property (nonatomic, weak) id<FJSWebService> webService;

- (NSDictionary *)eventMap;

@end
