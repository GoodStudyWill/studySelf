//
//  FJSContractHandler.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/7.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "FJSContractHandler.h"
#import "EMFileDownloadApi.h"

@interface FJSContractHandler ()<FJSRequestDelegate>

@property (nonatomic, copy) NSString *fileName;

@end

@implementation FJSContractHandler

- (void)download:(NSDictionary *)params
{
    NSString *fileID = params[@"fileId"];
    self.fileName = params[@"fileName"];
    
    [EMHudManager showLoadingWithText:@"" inView:[UIApplication sharedApplication].keyWindow];
    EMFileDownloadApi *api = [[EMFileDownloadApi alloc] initWithFileID:fileID fileName:self.fileName];
    api.delegate = self;
    [api start];
}

#pragma mark - Handle download
- (void)handleFileDownload:(NSData *)data
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory,NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *path = [NSString stringWithFormat:@"%@/%@", documentsDirectory, self.fileName];
    NSError *error;
    BOOL written = [data writeToFile:path options:0 error:&error];
    if (!written)
    {
        FJSLog(@"Write failed: %@", [error localizedDescription]);
    }
    FJSLog(@"Write success!");
    
    [EMHudManager hideLoadingForView:[UIApplication sharedApplication].keyWindow];
    NSURL *fileURL = [NSURL fileURLWithPath:path];
    if (self.delegate && [self.delegate respondsToSelector:@selector(handler:callPreviewAttachment:)]) {
        [self.delegate handler:self callPreviewAttachment:fileURL];
    }
}

#pragma mark - FJSRequestDelegate
- (void)apiRequestDidSuccess:(__kindof FJSBaseApi *)request
{
    [self handleFileDownload:request.responseData];
}

- (void)apiRequestDidFail:(__kindof FJSBaseApi *)request
{
    [self handleFileDownload:request.responseData];
}

@end
