//
//  FJSContractHandler.h
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/7.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FJSContractHandler;

@protocol FJSContractHandlerDelegate <NSObject>

- (void)handler:(FJSContractHandler *)handler callPreviewAttachment:(NSURL *)fileURL;

@end

@interface FJSContractHandler : NSObject

@property (nonatomic, weak) id<FJSContractHandlerDelegate> delegate;

- (void)download:(NSDictionary *)params;

@end
