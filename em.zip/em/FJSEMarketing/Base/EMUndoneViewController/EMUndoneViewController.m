//
//  EMUndoneViewController.m
//  FJSEMarketing
//
//  Created by xuyq on 2017/8/8.
//  Copyright © 2017年 pingan. All rights reserved.
//

#import "EMUndoneViewController.h"
#import "FJSAlertView.h"

@interface EMUndoneViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation EMUndoneViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.imageView.image = self.image;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName : [UIColor whiteColor]}];
    
}

@end
