#iOS自动化打包构建模板示例
#Version: 1.0.0
#author:  xuzhiwen050(徐志文)
#发布日期: 2014年9月
#脚本用途：iOS APP自动化打包

### Avalible [3.6.2, ?]

#==============================================脚本变更记录=====================================
#2015.11.24
#增加iloan本地包打包支持

#2015.10.26
#配合工程架构，调整H5静态资源压缩包在工程的路径

#2015.09.30
#新增对H5静态资源包打进客户端工程脚本支持

#2015.06.27
#百度地图key已根据app id写死在代码中，脚本中的已无用

#2015.06.28
#新增自动部署到tomcat web容器功能

#====================常见需转义符=================
# 1、/
# 2、""

#====================传参========================
#以下参数是需要暴露在Jenkins上供打包人员按项目需要配置

#====工程配置参数======
#客户端版本号，此参数将替换工程原来的版本号
T_VERSION=$1
#工程名称
PROJ_NAME=$2
#环境，配置此参数的前提是工程已按特定代码规范写（如int、stg、prd或0、1、2等）
CLIENT_ENV=$3
#程序显示名称选项，取值范围（DEFAULT,TYPE_TIMESTAP）
APP_DISPLAYNAME_TYPE=$4
#是否使用本地资源包开关，取值范围{0:不使用；1:使用}
IS_USED_LOCAL_WEBPAGE_RESOURCE=$9

#====编译配置参数======
#编译目标
TARGET=$5
#编译使用的BaseSDK
SDK=$6
#最低支持的iOS系统版本
IPHONEOS_DEPLOYMENT_TARGET=$7
#Debug或者Release
CONFIGURATION=$8
#SCHEME name
SCHEME=${10}
#build 路径
SYMROOT=${11}
#workspace name
WS=${12}
#拼装H5资源压缩包拷贝到客户端的from-to列表
H5_ZIP_FROM_TO_LIST=${13}
#H5资源模板
H5_VERSION_LIST=${14}
#百度地图sdk ak
BAIDUMAP_AK=${15}
#版本日期
Version_Date=${16}
#APP强升开关
APP_FORCE_UPDATE=${17}
#H5强升开关=${18}
HTML_FORCE_UPDATE=${18}
#是否开启oclint
Open_OCLint=${19}
#蒲公英UserKey
PGYER_USER_KEY=${20}
#蒲公英ApiKey
PGYER_API_KEY=${21}


echo "T_VERSION=${T_VERSION},PROJ_NAME=${PROJ_NAME},CLIENT_ENV=${CLIENT_ENV},TARGET=${TARGET},SDK=${SDK},IPHONEOS_DEPLOYMENT_TARGET=${IPHONEOS_DEPLOYMENT_TARGET},CONFIGURATION=${CONFIGURATION},IS_USED_LOCAL_WEBPAGE_RESOURCE=${IS_USED_LOCAL_WEBPAGE_RESOURCE},Version_Date=${Version_Date},APP_FORCE_UPDATE=${APP_FORCE_UPDATE},HTML_FORCE_UPDATE=${HTML_FORCE_UPDATE},Open_OCLint=${Open_OCLint}"



#====================证书配置=====================

#App ID
BUNDLE_IDENTIFIER="com.pingan.fjsRO"

#描述文件名称枚举
PROVISONING_PROFILE="20b85e39-8733-4858-8249-9e75827dbf51"

#证书名称枚举
CODESIGN="iPhone Distribution: Ping An Insurance (Group) Company of China, LTD."

#====================基本固定配置==================
#构建工作空间路径
WORKSPACE=`pwd`

#工作空间
PROJ_BAK_NAME="tmp"
EXPORT_PROJ="exportProj" #工程导出（去除版本控制信息等）
PROJ_BASE=$WORKSPACE/$PROJ_NAME       #工程源码目录
PROJ_TMP_BASE=$WORKSPACE/$PROJ_BAK_NAME #工程源码备份

#归档目录
OUTPUT_DIRNAME="output"
OUTPUT_PATH=$WORKSPACE/$OUTPUT_DIRNAME #归档目录路径（归档ipa、DSYM、app）
OUTPUT_GIT_PATH=$HOME/iOS_RO_Pack #归档上传Git路径

#部署路径
DEPLOY_ROOT_PATH="${WORKSPACE}/iOS" #部署根目录
PLIST_PATH="${WORKSPACE}/iOS/app.plist"  #发布配置模板文件路径
DEPLOY_DOMAIN="http:\/\/10.180.159.250:8080\/${PROJ_BAK_NAME}\/iOS"

#H5静态资源包源路径
#H5_ZED_FROM=$WORKSPACE/ZED_H5_BAK/output/zed.zip
#H5_IPOS_FROM=$WORKSPACE/iPOS_H5_BAK/output/ipos.zip
#H5_ILOAN_FROM=$WORKSPACE/ILOAN_H5_BAK/output/iloan.zip
#H5_ACCOUNT_FROM=$WORKSPACE/PAEHome_H5_BAK/output/paehome.zip

#H5_HOME_FROM=$WORKSPACE/HOME_H5_BAK/output/home.zip #3.6.2废弃

#H5_RESOURCE_TO=$PROJ_TMP_BASE/PATest/Controller/HybridFile/HtmlFile #3.6.2废弃
#H5_ZED_TO=$PROJ_TMP_BASE/PAYiDai/BusinessModules/ZaiE/Resource
#H5_IPOS_TO=$PROJ_TMP_BASE/PAYiDai/BusinessModules/iPos/Resource
#H5_ILOAN_TO=$PROJ_TMP_BASE/PAYiDai/BusinessModules/iLoanRegular/Resource
#H5_ACCOUNT_TO=$PROJ_TMP_BASE/PAYiDai/Platform/PAHybrid/HtmlFile

#=========================================== 基础function ========================================
#获取buildNumber
#fn_source="/Users/Tiger/.jenkins/jobs/PALoan_ios/nextBuildNumber" #替换成天下通待匹配文件路径
#
#cat $fn_source | while read line
#do
#echo "content of line : ${line}"
#buildNumber=`expr ${line} - 1`
#echo "buildNumber=${buildNumber}"
#done

#获取时间戳
function getTime(){
echo `date +%Y``date +%m``date +%d``date +%H``date +%M``date +%S`;
}

#获取时间（格式：yyyy-mm-dd-hh-mm-ss）
function getTimeFormat(){
echo `date +%Y`-`date +%m`-`date +%d`-`date +%H`-`date +%M`-`date +%S`;
}
#获取短时间，格式：mmddhhmm
function getShortTime(){
echo `date +%m``date +%d``date +%H``date +%M`
}

#获取版本号
function getVersion(){
echo "v""$T_VERSION"
}

# 获取文件中字符匹配行号(偏移1)
function getMatchLineNumAddOne(){
fn=$1 #搜索文件名
myPattern=$2  #匹配字符串
tmpFn="tmp.sh" #缓存匹配行号临时文件

awk '/'${myPattern}'/{print NR}' $fn>$tmpFn
lineNum=`awk '//{print $1}' ${tmpFn}`
lineNum2=`expr ${lineNum} + 1`
rm -rf $tmpFn
echo $lineNum2
}

# 获取文件中字符匹配行号(偏移N)
function getMatchLineNumAddN(){
fn=$1 #搜索文件名
myPattern=$2  #匹配字符串
n=$3
tmpFn="tmp.sh" #缓存匹配行号临时文件

awk '/'${myPattern}'/{print NR}' $fn>$tmpFn
lineNum=`awk '//{print $1}' ${tmpFn}`
lineNum2=`expr ${lineNum} + $n`
rm -rf $tmpFn
echo $lineNum2
}

function getSSEnv(){
if [ "$CLIENT_ENV" == "prd" ];then
echo "0"
elif [ "$CLIENT_ENV" == "stg1" ];then
echo "1"
elif [ "$CLIENT_ENV" == "stg2" ];then
echo "2"
elif [ "$CLIENT_ENV" == "stg3" ];then
echo "3"
elif [ "$CLIENT_ENV" == "stg4" ];then
echo "4"
elif [ "$CLIENT_ENV" == "stg5" ];then
echo "5"
else
echo "1"  #默认测试环境
fi
}

#获取H5Env.json的需要设置的环境变量值
function getH5Env(){
if [ "$CLIENT_ENV" == "int" ];then
eval $1="int"
eval $2="int"
elif [ "$CLIENT_ENV" == "stg1" ];then
eval $1="stg1"
eval $2="stg1"
elif [ "$CLIENT_ENV" == "stg2" ];then
eval $1="stg2"
eval $2="stg2"
elif [ "$CLIENT_ENV" == "prd" ];then
eval $1="prd"
eval $2="prd"
elif [ "$CLIENT_ENV" == "SS_stg2_pafu_stg1" ];then
eval $1="stg2"
eval $2="stg1"
elif [ "$CLIENT_ENV" == "SS_stg1_pafu_stg2" ];then
eval $1="stg1"
eval $2="stg2"
elif [ "$CLIENT_ENV" == "SS_stg3_pafu_stg1" ];then
eval $1="stg3"
eval $2="stg1"
elif [ "$CLIENT_ENV" == "SS_stg3_pafu_stg2" ];then
eval $1="stg3"
eval $2="stg2"
elif [ "$CLIENT_ENV" == "SS_stg2_pafu_stg5" ];then
eval $1="stg2"
eval $2="stg5"
else
#默认测试环境
eval $1="stg1"
eval $2="stg1"
fi
}

# ============================================== 处理过程/函数 ==============================================

#========= 导出工程 ===============
function makeExportProject(){
cd $WORKSPACE
rm -rf $EXPORT_PROJ
cp -rf $PROJ_NAME $EXPORT_PROJ
cd $EXPORT_PROJ
find . -type d -name ".git" |xargs rm -rvf
}

#======== 创建工程备份 ============
function createProjectBak(){
cd $WORKSPACE
#删除旧工程备份
rm -rf $PROJ_BAK_NAME;

#创建工程新备份
echo "start copy project";
cp -rf $EXPORT_PROJ $PROJ_BAK_NAME;
echo "copy project success";
}

#======== 更新H5静态资源包 =========
function updateH5Resource(){

OLD_IFS="$IFS"
IFS="+"
arr=(${H5_ZIP_FROM_TO_LIST})
IFS="$OLD_IFS"

num=${#arr[@]}
echo "number of H5 zip list:${num}"

for((i=0;i<num;i++)){
echo "${arr[i]}"

OLD_IFS="$IFS"
IFS=":"
arr2=(${arr[i]})  #arr2只会有两个元素，分别为：静态资源压缩包源路径，静态资源压缩包目标路径
IFS="$OLD_IFS"
num2=${#arr2[@]}
echo "num2=${num2}"

h5_zip_from=${arr2[0]}
h5_zip_to=${arr2[1]}

echo "h5_zip_from:${h5_zip_from},h5_zip_to:${h5_zip_to}"
rm -rf ${h5_zip_to}
cp -rf ${h5_zip_from} ${h5_zip_to}
}

echo "update h5 resource done."

}

#function updateH5Resource(){
#rm -rf $H5_ZED_TO/zed.zip
#rm -rf $H5_IPOS_TO/ipos.zip
#rm -rf $H5_ACCOUNT_TO/paehome.zip
#
#if [ -f "${H5_ZED_FROM}" ];then
#cp -rf ${H5_ZED_FROM} ${H5_ZED_TO}
#else
#echo "warning:${H5_ZED_FROM} is not exist!"
#fi
#
#if [ -f "${H5_IPOS_FROM}" ];then
#cp -rf ${H5_IPOS_FROM} ${H5_IPOS_TO}
#else
#echo "warning:${H5_IPOS_FROM} is not exist!"
#fi
#
#if [ -f "${H5_ACCOUNT_FROM}" ];then
#cp -rf ${H5_ACCOUNT_FROM} ${H5_ACCOUNT_TO}
#else
#echo "warning:${H5_ACCOUNT_FROM} is not exist!"
#fi
#
#if [ -f "${H5_ILOAN_FROM}" ];then
#cp -rf ${H5_ILOAN_FROM} ${H5_ILOAN_TO}
#else
#echo "warning:${H5_ILOAN_FROM} is not exist!"
#fi
#
#echo "update h5 resource done."
#
#}


#=========替换关键字符==============

function replaceCharacter(){
echo "p_appDisplayName=$1,p_appId=$2,p_profile=$3,p_codeSign=$4,p_networkEnv=$5"

p_appDisplayName=$1
p_appId=$2
p_profile=$3
p_codeSign=$4
p_networkEnv=${CLIENT_ENV}

#修改appid，程序显示名称，程序版本号
fn="Info.plist"
cd $PROJ_TMP_BASE/$SCHEME

myPattern="CFBundleIdentifier"
lineNum_AppId=$(getMatchLineNumAddOne $fn $myPattern)
sed -i "" "${lineNum_AppId}s/<string>.*<\/string>/<string>${p_appId}<\/string>/g" $fn

myPattern="CFBundleShortVersionString"
lineNum=$(getMatchLineNumAddOne $fn $myPattern)
sed -i "" "${lineNum}s/<string>.*<\/string>/<string>${T_VERSION}<\/string>/g" $fn

myPattern="CFBundleVersion"
lineNum=$(getMatchLineNumAddOne $fn $myPattern)
sed -i "" "${lineNum}s/<string>.*<\/string>/<string>${T_VERSION}<\/string>/g" $fn

if [ "$APP_DISPLAYNAME_TYPE" == "TYPE_TIMESTAP" ];then
myPattern="CFBundleDisplayName"
lineNum=$(getMatchLineNumAddOne $fn $myPattern)
sed -i "" "${lineNum}s/<string>.*<\/string>/<string>${p_appDisplayName}<\/string>/g" $fn
fi

echo "print $fn start..."
cat $fn
echo "print $fn end."

#修改描述文件与签名
fn="project.pbxproj"
cd $PROJ_TMP_BASE/${PROJ_NAME}.xcodeproj
#sed -i "" "s/PROVISIONING_PROFILE = \".*\"/PROVISIONING_PROFILE = \"${p_profile}\"/g" $fn
#sed -i "" "s/\"PROVISIONING_PROFILE\[sdk=iphoneos\*]\" = \".*\"/\"PROVISIONING_PROFILE\[sdk=iphoneos\*]\" = \"${p_profile}\"/g" $fn
#sed -i "" "s/CODE_SIGN_IDENTITY = \".*\"/CODE_SIGN_IDENTITY = \"${p_codeSign}\"/g" $fn
#sed -i "" "s/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*]\" = \".*\"/\"CODE_SIGN_IDENTITY\[sdk=iphoneos\*]\" = \"${p_codeSign}\"/g" $fn

#修改PRODUCT_BUNDLE_IDENTIFIER [XCode 7工程新增]
sed -i "" "s/PRODUCT_BUNDLE_IDENTIFIER.*;/PRODUCT_BUNDLE_IDENTIFIER = ${p_appId};/g" $fn

echo "print $fn start..."
cat $fn
echo "print $fn end.ß"


##------ 从CI文件夹的project.pbxproj文件拷贝到tmp/Pods/Pods.xcodeproj 下面-------
#cd "$WORKSPACE/$PROJ_BAK_NAME/Pods/Pods.xcodeproj"
echo "___$WORKSPACE/$PROJ_BAK_NAME/Pods/Pods.xcodeproj"
#rm -f $fn
#mkdir -p "$WORKSPACE/$PROJ_BAK_NAME/Pods.xcodeproj"
#cp -f "$WORKSPACE/CI/project.pbxproj" "$WORKSPACE/$PROJ_BAK_NAME/Pods/Pods.xcodeproj/project.pbxproj"


#修改Native环境变量
#0 开发  1测试  2生产
fn="ROAppConfig.h"
cd $PROJ_TMP_BASE/$SCHEME/BusinessModules
sed -i "" "s/define SS_ENV.*/define SS_ENV $(getSSEnv)/g" $fn

echo "print $fn start..."
cat $fn
echo "print $fn end."

#修改H5环境变量
#fn="H5Env.json"
#getH5Env ssEnv pafEnv
#cd $PROJ_TMP_BASE/PAYiDai/Platform/APPConfig
#sed -i "" "s/ssEnv.*/ssEnv\":\"${ssEnv}\",\"pafEnv\":\"${pafEnv}\"}/g" $fn
#
#echo "print $fn start..."
#cat $fn
#echo "print $fn end."

#是否使用本地资源包开关，取值范围{0:不使用；1:使用}
fn="PAHybrid_Predefine.h"
cd $PROJ_TMP_BASE/$SCHEME/PAHybrid
sed -i "" "s/define __USED_LOCAL_WEBPAGE_RESOURCE__.*/define __USED_LOCAL_WEBPAGE_RESOURCE__  ${IS_USED_LOCAL_WEBPAGE_RESOURCE}/g" $fn

sed -i "" "s/define __APP_FORCE_UPDATE__.*/define __APP_FORCE_UPDATE__  ${APP_FORCE_UPDATE}/g" $fn

sed -i "" "s/define __HTML_FORCE_UPDATE__.*/define __HTML_FORCE_UPDATE__  ${HTML_FORCE_UPDATE}/g" $fn

echo "print $fn start..."
cat $fn
echo "print $fn end."

#H5资源版本号列表替换
fn="PAHybrid_Predefine.h"
cd $PROJ_TMP_BASE/$SCHEME/PAHybrid
sed -i "" "s/define __HtmlVersionDict__.*/define __HtmlVersionDict__  @{${H5_VERSION_LIST}}/g" $fn

echo "print $fn start..."
cat $fn
echo "print $fn end."

fn="PrefixHeader.pch"
cd $PROJ_TMP_BASE/$SCHEME
sed -i "" "s/define BAIDUSDKAK.*/define BAIDUSDKAK @\"${BAIDUMAP_AK}\"/g" $fn
echo "print $fn start..."
cat $fn
echo "print $fn end."

#更新代码最后提交时间
fn="NetworkClient.h"
cd $PROJ_TMP_BASE
cd ..
cd $SCHEME
pwd
codeTime=`git log -1 | grep "Date"`
cd $PROJ_TMP_BASE/$SCHEME/Core/NetWork
sed -i "" "s/define CODE_TIME.*/define CODE_TIME @\"${codeTime}\"/g" $fn

echo "print $fn start..."
cat $fn
echo "print $fn end."

#更新发版日期
fn="ROVersionConfig.h"
cd $PROJ_TMP_BASE/$SCHEME/Core/Model
sed -i "" "s/define VERSIONS_DATE.*/define VERSIONS_DATE @\"${Version_Date}\"/g" $fn

echo "print $fn start..."
cat $fn
echo "print $fn end."
}
#==================编译打包===================
#参数说明
#$1:产出目标ipa名称
#$2:打包配置，取值范围{Debug,Release}
function compile(){
echo "ipaName=$2,configuration=$1"

configuration=$1
ipaName=$2
appPath="${PROJ_TMP_BASE}/build/${configuration}-iphoneos/*.app"
ipaPathWithResigned="${PROJ_TMP_BASE}/${ipaName}"

cd $PROJ_TMP_BASE
echo "clean start..."
xcodebuild clean -configuration ${configuration} -target $TARGET
echo "clean end."
echo "compile start......"
echo "Open_OCLint=${Open_OCLint}"
if [ "$Open_OCLint" == "true" ];then
xcodebuild -configuration ${configuration} -sdk $SDK -workspace $WS -scheme $SCHEME IPHONEOS_DEPLOYMENT_TARGET=$IPHONEOS_DEPLOYMENT_TARGET SYMROOT=$SYMROOT | tee xcodebuild.log | xcpretty -r json-compilation-database
cp build/reports/compilation_db.json compile_commands.json
PRIORITY=10000
oclint-json-compilation-database -e Pods -- -max-priority-1 $PRIORITY -max-priority-2 $PRIORITY -max-priority-3 $PRIORITY -rc LONG_LINE=200 -report-type pmd -o report_result.xml
cp report_result.xml $OUTPUT_PATH/report_result.xml
else
xcodebuild -configuration ${configuration} -sdk $SDK -workspace $WS -scheme $SCHEME IPHONEOS_DEPLOYMENT_TARGET=$IPHONEOS_DEPLOYMENT_TARGET SYMROOT=$SYMROOT
fi
echo "compile end."
echo "xcrun start......"
xcrun -sdk iphoneos PackageApplication -v ${appPath} -o ${ipaPathWithResigned}
echo "xcrun end."
}

# ==================归档=======================
# 参数说明
# $1: 需要归档的ipa包长名称
# $2: 需要归档的ipa包短名称
# $3: 包类型归档目录名称
function saveFile(){
echo "configuration=$1,ipaPathWithResigned=$2,ipaShortName=$3,subDirName=$4"

configuration=$1
ipaPathWithResigned=$2
ipaShortName=$3
subDirName=$4

cd $OUTPUT_PATH
mkdir -pv $TIME_DIRNAME
cd $TIME_DIRNAME
mkdir $subDirName

#拷贝到时间戳归档目录
cp -rf "${PROJ_TMP_BASE}/$ipaPathWithResigned" "${OUTPUT_PATH}/$TIME_DIRNAME/$subDirName"
cp -rf ${PROJ_TMP_BASE}/build/${configuration}-iphoneos/*.app ${OUTPUT_PATH}/$TIME_DIRNAME/$subDirName
cp -rf ${PROJ_TMP_BASE}/build/${configuration}-iphoneos/*.app.dSYM ${OUTPUT_PATH}/$TIME_DIRNAME/$subDirName

#拷贝ipa包到git目录
cd $OUTPUT_GIT_PATH
mkdir -pv $TIME_DIRNAME
cd $TIME_DIRNAME
mkdir $subDirName
cp -rf "${PROJ_TMP_BASE}/$ipaPathWithResigned" "${OUTPUT_GIT_PATH}/$TIME_DIRNAME/$subDirName"

#将ipa包更新到git
cd $OUTPUT_GIT_PATH
git pull origin master
git add ./
git commit -m $(getTimeFormat)
git push origin master

#移动最新包到归档根目录
mv "${PROJ_TMP_BASE}/$ipaPathWithResigned" "${OUTPUT_PATH}/$ipaShortName"

cd $WORKSPACE
cp -rf "$PROJ_TMP_BASE" "$OUTPUT_PATH/$TIME_DIRNAME/$subDirName/source"

cd $OUTPUT_PATH/$TIME_DIRNAME/$subDirName
zip -r -T source.zip source
rm -rf source


#生成带plist的zip包
cd $OUTPUT_PATH/$TIME_DIRNAME
cp $WORKSPACE/CI/ro.plist $OUTPUT_PATH/$TIME_DIRNAME/ro.plist
#注意这里的地址，如果以后变了，一定要修改
hostname="https:\/\/fang-test.pingan.com.cn:20443"
if [ "$CLIENT_ENV" == "prd" ];then
hostname="https:\/\/fang.pingan.com.cn"
fi
appVersion=`echo $RO_VERSION | tr -d '.'`
sed -i "" "s/zlzHostName/${hostname}/g" ro.plist
sed -i "" "s/zlzStg/${CLIENT_RO}/g" ro.plist
sed -i "" "s/zlzAppVersion/${appVersion}/g" ro.plist
sed -i "" "s/zlzDotAppVersion/${RO_VERSION}/g" ro.plist

zipName="${CLIENT_ENV}_ios"
mkdir -pv "${OUTPUT_PATH}/${TIME_DIRNAME}/${zipName}/${CLIENT_ENV}/ios/${appVersion}"
echo "${zipName}/${CLIENT_ENV}/ios/${appVersion} created"
cp ro.plist $zipName/$CLIENT_ENV/ios/$appVersion/ro.plist
cp ${CLIENT_ENV}/$ipaPathWithResigned $zipName/$CLIENT_ENV/ios/$appVersion
mv $zipName/$CLIENT_ENV/ios/$appVersion/$ipaPathWithResigned $zipName/$CLIENT_ENV/ios/$appVersion/${SCHEME}_V${appVersion}.ipa
cd $zipName
zip -r -T ${zipName}.zip $CLIENT_ENV
mv "${OUTPUT_PATH}/${TIME_DIRNAME}/${zipName}/${zipName}.zip" "${OUTPUT_PATH}/${TIME_DIRNAME}/${zipName}_v${appVersion}.zip"
cd ..
rm -rf $zipName
rm -rf ro.plist
}

# ==============================部署==============================
#根据版本号、客户的环境在tomcat容器创建存放目标包目录，以及修改发布配置.plist文件(修改项：ipa url, bundle-identifier)
#参数说明：
#ipaShortName:需要归档的ipa包短名称
function deploy(){
echo "start deploy ${OUTPUT_PATH}/${ipaShortName} to ${DEPLOY_ROOT_PATH}/${T_VERSION}/${CLIENT_ENV}"

ipaShortName=$1
p_appId=$2
deploySubPath="${T_VERSION}/${CLIENT_ENV}"
deploySubPath_replace="${T_VERSION}\/${CLIENT_ENV}"
deployPath=${DEPLOY_ROOT_PATH}/${deploySubPath}

mkdir -pv $deployPath
rm -rf ${deployPath}/*.ipa
cp -rf "${OUTPUT_PATH}/${ipaShortName}" $deployPath

#cp -rf "${WORKSPACE}/${PROJ_BAK_NAME}/CI/iOS/app.plist" "${deployPath}/app.plist"

#cp -rf "${PLIST_PATH}" "${deployPath}/app.plist"

#fn="app.plist"
#cd $deployPath
#myPattern="<key>url"
#lineNum=$(getMatchLineNumAddOne $fn $myPattern)
#sed -i "" "${lineNum}s/<string>.*<\/string>/<string>${DEPLOY_DOMAIN}\/${deploySubPath_replace}\/${ipaShortName}<\/string>/g" $fn
#
#myPattern="<key>bundle-identifier"
#lineNum=$(getMatchLineNumAddOne $fn $myPattern)
#sed -i "" "${lineNum}s/<string>.*<\/string>/<string>${p_appId}<\/string>/g" $fn
#
#if [ ! -f "${DEPLOY_ROOT_PATH}/${T_VERSION}/${CLIENT_ENV}/${ipaShortName}" ];then
#echo "deploy success!"
#fi
}

# ==============================部署到蒲公英==============================
function deployToPgyer(){
echo "start deploy ${OUTPUT_PATH}/${ipaShortName} to pgyer.com"

ipaShortName=$1
PGYER_USER_KEY=$2
PGYER_API_KEY=$3
curl -F "file=@${OUTPUT_PATH}/${ipaShortName}" -F "uKey=${PGYER_USER_KEY}" -F "_api_key=${PGYER_API_KEY}" https://qiniu-storage.pgyer.com/apiv1/app/upload
}

#============================================= 开始构建 ===============================================

TIME_DIRNAME=$(getTimeFormat)

#删除上次构建临时备份工程目录
rm -rf ${WORKSPACE}/${PROJ_BAK_NAME}

#创建归档目录，若已存在，则不重复创建
cd $WORKSPACE
mkdir -pv $OUTPUT_PATH

#删除上次最新包
cd $OUTPUT_PATH
rm -rf *.ipa

#工程导出
makeExportProject

#创建工程备份
createProjectBak

#更新H5静态资源
updateH5Resource

#关键字符替换
channel=${CLIENT_ENV}

if [ "$APP_DISPLAYNAME_TYPE" == "TYPE_TIMESTAP" ];then
p_appDisplayName=$(getShortTime)${channel}
else
p_appDisplayName=
fi

p_appId=${BUNDLE_IDENTIFIER}
p_profile=${PROVISONING_PROFILE}
p_codeSign=${CODESIGN}

dirName=${channel}
ipaName=${TARGET}-${channel}-$(getVersion)-$(getTime).ipa;
ipaShortName=${TARGET}${channel}.ipa

replaceCharacter "${p_appDisplayName}" "${p_appId}" "${p_profile}" "${p_codeSign}"
#传带有空格到参数需要用双引号括起来

#编译与打包
compile ${CONFIGURATION} $ipaName

#归档
saveFile ${CONFIGURATION} $ipaName $ipaShortName $dirName

#部署到tomcat web容器
#deploy $ipaShortName $p_appId

#部署到蒲公英
deployToPgyer $ipaShortName ${PGYER_USER_KEY} ${PGYER_API_KEY}
