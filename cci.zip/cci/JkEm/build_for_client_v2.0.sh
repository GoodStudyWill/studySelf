#脚本使用说明：
#传参格式：source_root_dirname1:source_zip_filename1+source_root_dirname2:source_zip_filename2
#传参说明：H5静态资源包根目录名称:压缩包名称

#===========================外部传参======================================

#H5打包环境，取值范围{TEST,TEST2,TEST3,PRODUCTION}
H5_ENV="PRODUCTION"

H5_ZIP_LIST=$1

#===========================开始构建======================================

WORKSPACE=`pwd`

echo "H5 zip list:${H5_ZIP_LIST}"

OLD_IFS="$IFS"
IFS="+"
arr=(${H5_ZIP_LIST})
IFS="$OLD_IFS"

num=${#arr[@]}
echo "number of H5 zip list:${num}"


#获取短时间，格式：mmddhhmm
function getShortTime(){
echo `date +%m``date +%d``date +%H``date +%M`
}

for((i=0;i<num;i++)){
echo "${arr[i]}"

OLD_IFS="$IFS"
IFS=":"
arr2=(${arr[i]})  #arr2只会有两个元素，分别为：静态资源根目录名称、静态资源压缩包名称
IFS="$OLD_IFS"
num2=${#arr2[@]}
echo "num2=${num2}"

source_root_dirname=${arr2[0]}
source_zip_filename=${arr2[1]}
source_bak_name=${source_root_dirname}"_BAK"
source_root_path=${WORKSPACE}/${source_root_dirname}
source_bak_path=${WORKSPACE}/${source_bak_name}

echo "source_root_dirname:${source_root_dirname},source_zip_filename:${source_zip_filename}"

echo "delete ${WORKSPACE}/${source_bak_name} ..."
rm -rf ${source_bak_path}
cp -rf ${source_root_path} ${source_bak_path}
rm -rf ${source_bak_path}/output/*.zip
cd ${source_bak_path}
node /usr/local/lib/node_modules/gulp-cli/bin/gulp.js build -e $H5_ENV
cp -rf ${source_bak_path}/output/*.zip ${source_bak_path}/output/${source_zip_filename}
cd $WORKSPACE

}

